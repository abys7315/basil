@echo off
echo ========================================================
echo   BASIL: Burst-Aware Semantic Intelligence for Li-Fi
echo   Starting all services (Backend + Frontend)...
echo ========================================================
echo.

set ROOT_DIR=%~dp0

echo [1/3] Launching FastAPI Backend on port 8000...
start "BASIL Backend Service" cmd /k "cd /d ""%ROOT_DIR%backend"" && python -m uvicorn app.main:app --host 127.0.0.1 --port 8000"

echo [2/3] Launching Vite Frontend on port 5173...
start "BASIL Frontend Service" cmd /k "cd /d ""%ROOT_DIR%desktop-app"" && npm run dev"

echo [3/3] Opening Browser...
timeout /t 3 /nobreak >nul
start http://localhost:5173

echo.
echo --------------------------------------------------------
echo Backend running at:  http://localhost:8000 (Docs: /docs)
echo Frontend running at: http://localhost:5173
echo.
echo Application is now open in your browser!
echo --------------------------------------------------------
pause
