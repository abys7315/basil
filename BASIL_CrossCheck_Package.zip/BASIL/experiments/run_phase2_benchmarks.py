import asyncio
import json
import math
import os
import sys
from pathlib import Path
from typing import Dict, List, Any

# Ensure backend is on python path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "backend"))
from app.simulation.runner import SimulationRunner

SEEDS = [42, 101, 2024, 777, 9999]
SCHEDULERS = ["FIFO", "RoundRobin", "StrictPriority", "BASIL_PSA"]

SCENARIOS = {
    "normal_traffic": {
        "description": "Uniform baseline traffic across 4 devices",
        "num_devices": 4,
        "simulation_time": 2.0,
        "data_rate": 10.0,
        "traffic_mode": "normal",
        "normal_rate": 100.0,
        "burst_rate": 100.0,
        "burst_ratio": 0.0,
        "ap_power": 100.0,
    },
    "sudden_bursts": {
        "description": "Sudden periodic traffic bursts across 4 devices",
        "num_devices": 4,
        "simulation_time": 2.0,
        "data_rate": 10.0,
        "traffic_mode": "burst",
        "normal_rate": 80.0,
        "burst_rate": 400.0,
        "burst_ratio": 0.3,
        "ap_power": 100.0,
    },
    "high_device_density": {
        "description": "16 concurrent devices testing scale and scheduling fairness",
        "num_devices": 16,
        "simulation_time": 2.0,
        "data_rate": 10.0,
        "traffic_mode": "burst",
        "normal_rate": 30.0,
        "burst_rate": 120.0,
        "burst_ratio": 0.25,
        "ap_power": 100.0,
    },
    "mixed_semantic_traffic": {
        "description": "Mixed traffic classes with varied semantic priorities and deadlines",
        "num_devices": 4,
        "simulation_time": 2.0,
        "data_rate": 10.0,
        "traffic_mode": "burst",
        "normal_rate": 80.0,
        "burst_rate": 350.0,
        "burst_ratio": 0.35,
        "ap_power": 100.0,
    },
    "degraded_optical_channel": {
        "description": "Severely degraded optical SNR / higher PER on distant devices",
        "num_devices": 4,
        "simulation_time": 2.0,
        "data_rate": 10.0,
        "traffic_mode": "burst",
        "normal_rate": 80.0,
        "burst_rate": 350.0,
        "burst_ratio": 0.3,
        "ap_power": 25.0, # Low AP optical transmit power causes high PER
    },
    "sustained_emergency_traffic": {
        "description": "Sustained high-priority traffic to assess anti-starvation of best-effort devices",
        "num_devices": 4,
        "simulation_time": 2.0,
        "data_rate": 10.0,
        "traffic_mode": "burst",
        "normal_rate": 120.0,
        "burst_rate": 500.0,
        "burst_ratio": 0.5,
        "ap_power": 100.0,
    },
}

ABLATIONS = {
    "BASIL_PSA (Full)": {},
    "No Burst Prediction": {"ablation_no_prediction": 1.0},
    "No Semantic Importance": {"ablation_no_semantic": 1.0},
    "No Channel Awareness": {"ablation_no_channel": 1.0},
    "No Fairness Adjustment": {"ablation_no_fairness": 1.0},
}

def calc_stats(values: List[float]) -> Dict[str, float]:
    n = len(values)
    if n == 0:
        return {"mean": 0.0, "std": 0.0, "ci95": 0.0, "min": 0.0, "max": 0.0}
    mean = sum(values) / n
    if n > 1:
        var = sum((x - mean) ** 2 for x in values) / (n - 1)
        std = math.sqrt(var)
        ci95 = 1.96 * (std / math.sqrt(n))
    else:
        std = 0.0
        ci95 = 0.0
    return {
        "mean": round(mean, 4),
        "std": round(std, 4),
        "ci95": round(ci95, 4),
        "min": round(min(values), 4),
        "max": round(max(values), 4),
    }

async def run_evaluation():
    runner = SimulationRunner()
    raw_results = {}
    summary = {}

    print(f"=== Starting Phase 2 Scenario Evaluation (6 scenarios x 4 schedulers x {len(SEEDS)} seeds) ===")

    for sc_name, sc_cfg in SCENARIOS.items():
        print(f"\n--- Scenario: {sc_name} ({sc_cfg['description']}) ---")
        raw_results[sc_name] = {}
        summary[sc_name] = {}

        for sched in SCHEDULERS:
            raw_results[sc_name][sched] = []
            metrics = {
                "avg_latency_ms": [],
                "p95_latency_ms": [],
                "p99_latency_ms": [],
                "throughput_mbps": [],
                "pdr": [],
                "total_deadline_misses": [],
                "jain_fairness_index": [],
                "burst_prediction_mae": [],
                "burst_prediction_rmse": [],
                "sim_duration_s": [],
            }

            for seed in SEEDS:
                cfg = dict(sc_cfg)
                cfg["scheduler"] = sched
                cfg["seed"] = seed
                
                res = await runner.run(cfg, engine="ns3")
                raw_results[sc_name][sched].append(res)

                metrics["avg_latency_ms"].append(res.get("avg_latency_ms", 0.0))
                metrics["p95_latency_ms"].append(res.get("p95_latency_ms", 0.0))
                metrics["p99_latency_ms"].append(res.get("p99_latency_ms", 0.0))
                metrics["throughput_mbps"].append(res.get("throughput_mbps", 0.0))
                metrics["pdr"].append(res.get("pdr", 0.0))
                metrics["total_deadline_misses"].append(res.get("total_deadline_misses", 0))
                metrics["jain_fairness_index"].append(res.get("jain_fairness_index", 0.0))
                metrics["burst_prediction_mae"].append(res.get("burst_prediction_mae", 0.0))
                metrics["burst_prediction_rmse"].append(res.get("burst_prediction_rmse", 0.0))
                metrics["sim_duration_s"].append(res.get("simulation_duration_s", 0.0))

            sched_summary = {k: calc_stats(v) for k, v in metrics.items()}
            summary[sc_name][sched] = sched_summary
            print(f"  {sched:<15} Latency={sched_summary['avg_latency_ms']['mean']}ms (p95={sched_summary['p95_latency_ms']['mean']}) | Missed={sched_summary['total_deadline_misses']['mean']} | Fairness={sched_summary['jain_fairness_index']['mean']} | PDR={sched_summary['pdr']['mean']}")

    out_file = Path(__file__).resolve().parent / "phase2_evaluation_results.json"
    with open(out_file, "w") as f:
        json.dump({"summary": summary, "raw": raw_results}, f, indent=2)
    print(f"\nSaved evaluation results to {out_file}")

    # Ablation Evaluation
    print("\n=== Starting Phase 2 Ablation Study (sudden_bursts) ===")
    ablation_raw = {}
    ablation_summary = {}
    base_cfg = SCENARIOS["sudden_bursts"]

    for ab_name, ab_flags in ABLATIONS.items():
        ablation_raw[ab_name] = []
        metrics = {
            "avg_latency_ms": [],
            "p95_latency_ms": [],
            "p99_latency_ms": [],
            "throughput_mbps": [],
            "pdr": [],
            "total_deadline_misses": [],
            "jain_fairness_index": [],
            "burst_prediction_mae": [],
            "burst_prediction_rmse": [],
        }

        for seed in SEEDS:
            cfg = dict(base_cfg)
            cfg["scheduler"] = "BASIL_PSA"
            cfg["seed"] = seed
            cfg.update(ab_flags)

            res = await runner.run(cfg, engine="ns3")
            ablation_raw[ab_name].append(res)

            metrics["avg_latency_ms"].append(res.get("avg_latency_ms", 0.0))
            metrics["p95_latency_ms"].append(res.get("p95_latency_ms", 0.0))
            metrics["p99_latency_ms"].append(res.get("p99_latency_ms", 0.0))
            metrics["throughput_mbps"].append(res.get("throughput_mbps", 0.0))
            metrics["pdr"].append(res.get("pdr", 0.0))
            metrics["total_deadline_misses"].append(res.get("total_deadline_misses", 0))
            metrics["jain_fairness_index"].append(res.get("jain_fairness_index", 0.0))
            metrics["burst_prediction_mae"].append(res.get("burst_prediction_mae", 0.0))
            metrics["burst_prediction_rmse"].append(res.get("burst_prediction_rmse", 0.0))

        ab_summ = {k: calc_stats(v) for k, v in metrics.items()}
        ablation_summary[ab_name] = ab_summ
        print(f"  {ab_name:<25} Latency={ab_summ['avg_latency_ms']['mean']}ms | p95={ab_summ['p95_latency_ms']['mean']} | Missed={ab_summ['total_deadline_misses']['mean']} | Fairness={ab_summ['jain_fairness_index']['mean']}")

    ab_file = Path(__file__).resolve().parent / "phase2_ablation_results.json"
    with open(ab_file, "w") as f:
        json.dump({"summary": ablation_summary, "raw": ablation_raw}, f, indent=2)
    print(f"\nSaved ablation results to {ab_file}")

if __name__ == "__main__":
    asyncio.run(run_evaluation())
