import json
from pathlib import Path

def generate_report():
    eval_file = Path(__file__).resolve().parent / "phase2_evaluation_results.json"
    abl_file = Path(__file__).resolve().parent / "phase2_ablation_results.json"

    with open(eval_file) as f:
        eval_data = json.load(f)["summary"]

    with open(abl_file) as f:
        abl_data = json.load(f)["summary"]

    lines = []
    lines.append("# BASIL Phase 2 – Comprehensive Research Evaluation & Ablation Results\n")
    lines.append("Evaluated using genuine ns-3.42 Li-Fi simulation engine across 5 random seeds (42, 101, 2024, 777, 9999).\n")
    lines.append("All metrics are reported as **Mean ± 95% Confidence Interval** ($1.96 \\cdot \\frac{\\sigma}{\\sqrt{N}}$).\n")

    for scenario, schedulers in eval_data.items():
        lines.append(f"\n### Scenario: `{scenario}`\n")
        lines.append("| Scheduler | Mean Latency (ms) | p95 Latency (ms) | p99 Latency (ms) | Throughput (Mbps) | PDR (%) | Deadline Misses | Jain Fairness |")
        lines.append("|---|---|---|---|---|---|---|---|")
        for sched, m in schedulers.items():
            lat = f"{m['avg_latency_ms']['mean']:.2f} ± {m['avg_latency_ms']['ci95']:.2f}"
            p95 = f"{m['p95_latency_ms']['mean']:.2f} ± {m['p95_latency_ms']['ci95']:.2f}"
            p99 = f"{m['p99_latency_ms']['mean']:.2f} ± {m['p99_latency_ms']['ci95']:.2f}"
            tput = f"{m['throughput_mbps']['mean']:.2f} ± {m['throughput_mbps']['ci95']:.2f}"
            pdr = f"{(m['pdr']['mean']*100):.1f}% ± {(m['pdr']['ci95']*100):.1f}%"
            misses = f"{m['total_deadline_misses']['mean']:.1f} ± {m['total_deadline_misses']['ci95']:.1f}"
            fairness = f"{m['jain_fairness_index']['mean']:.4f} ± {m['jain_fairness_index']['ci95']:.4f}"
            lines.append(f"| **{sched}** | {lat} | {p95} | {p99} | {tput} | {pdr} | {misses} | {fairness} |")

    lines.append("\n\n### BASIL-PSA Ablation Study (under `sudden_bursts`)\n")
    lines.append("| Configuration | Mean Latency (ms) | p95 Latency (ms) | p99 Latency (ms) | Throughput (Mbps) | Missed Deadlines | Jain Fairness |")
    lines.append("|---|---|---|---|---|---|---|")
    for cfg_name, m in abl_data.items():
        lat = f"{m['avg_latency_ms']['mean']:.2f} ± {m['avg_latency_ms']['ci95']:.2f}"
        p95 = f"{m['p95_latency_ms']['mean']:.2f} ± {m['p95_latency_ms']['ci95']:.2f}"
        p99 = f"{m['p99_latency_ms']['mean']:.2f} ± {m['p99_latency_ms']['ci95']:.2f}"
        tput = f"{m['throughput_mbps']['mean']:.2f} ± {m['throughput_mbps']['ci95']:.2f}"
        misses = f"{m['total_deadline_misses']['mean']:.1f} ± {m['total_deadline_misses']['ci95']:.1f}"
        fairness = f"{m['jain_fairness_index']['mean']:.4f} ± {m['jain_fairness_index']['ci95']:.4f}"
        lines.append(f"| **{cfg_name}** | {lat} | {p95} | {p99} | {tput} | {misses} | {fairness} |")

    out_md = Path(__file__).resolve().parent / "phase2_results_tables.md"
    with open(out_md, "w") as f:
        f.write("\n".join(lines))
    print(f"Generated {out_md}")

if __name__ == "__main__":
    generate_report()
