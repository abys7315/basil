import tempfile, json, subprocess, os, time, sys, math
import numpy as np

schedulers = ['FIFO', 'RoundRobin', 'StrictPriority', 'BASIL_PSA']
seeds = [42, 101, 2024, 777, 9999]

base_cfg = {
    'num_devices': 4,
    'simulation_time': 2.0,
    'data_rate': 15.0,
    'traffic_mode': 'burst',
    'burst_ratio': 0.35,
    'room_width': 5.0,
    'room_height': 3.0,
    'ap_power': 100.0,
    'half_angle': 60.0,
    'packet_size': 1024,
    'normal_rate': 80.0,
    'burst_rate': 400.0,
}

multi_seed_results = {s: [] for s in schedulers}

print('Running multi-seed experiment runs (5 seeds)...')
for seed in seeds:
    print(f'Seed {seed}:')
    for sched in schedulers:
        cfg = dict(base_cfg)
        cfg['scheduler'] = sched
        cfg['seed'] = seed
        
        with tempfile.NamedTemporaryFile('w', suffix='.json', delete=False) as f:
            json.dump(cfg, f)
            cfg_path = f.name
        
        wsl_path = '/mnt/c' + cfg_path.replace('\\', '/').replace('C:', '')
        cmd = ['wsl', '-d', 'Ubuntu', '--', 'bash', '-c', f'LD_LIBRARY_PATH=/opt/ns3/ns-allinone-3.42/ns-3.42/build/lib /opt/ns3/ns-allinone-3.42/ns-3.42/build/scratch/ns3.42-basil-ns3-sim {wsl_path}']
        
        t0 = time.time()
        res = subprocess.run(cmd, capture_output=True, text=True)
        wall_time = time.time() - t0
        try:
            os.unlink(cfg_path)
        except OSError:
            pass
            
        data = json.loads(res.stdout)
        data['seed'] = seed
        data['wall_runtime_s'] = wall_time
        multi_seed_results[sched].append(data)
        print(f'  {sched:15s} | PDR={data["pdr"]:.4f} | Latency={data["avg_latency_ms"]:.3f}ms | Misses={data["deadline_misses"]}')

# Compute mean and 95% confidence intervals
summary = {}
for sched, runs in multi_seed_results.items():
    latencies = [r['avg_latency_ms'] for r in runs]
    pdrs = [r['pdr'] for r in runs]
    tputs = [r['throughput_mbps'] for r in runs]
    fairnesses = [r['fairness_index'] for r in runs]
    misses = [r['deadline_misses'] for r in runs]
    runtimes = [r['wall_runtime_s'] for r in runs]
    
    n = len(runs)
    def stats(arr):
        mean = float(np.mean(arr))
        std = float(np.std(arr, ddof=1)) if n > 1 else 0.0
        ci95 = 1.96 * (std / math.sqrt(n)) if n > 1 else 0.0
        return {'mean': mean, 'std': std, 'ci95': ci95}
        
    summary[sched] = {
        'latency_ms': stats(latencies),
        'pdr': stats(pdrs),
        'throughput_mbps': stats(tputs),
        'fairness_index': stats(fairnesses),
        'deadline_misses': stats(misses),
        'wall_runtime_s': stats(runtimes)
    }

out_file = r'c:\Users\abys7\Downloads\BASIL-starter\BASIL\experiments\multi_seed_statistical_summary.json'
with open(out_file, 'w') as out_f:
    json.dump({'runs': multi_seed_results, 'summary': summary}, out_f, indent=2)

print('=== 5-Seed Statistical Summary (Mean +- 95% CI) ===')
for sched, s in summary.items():
    l = s['latency_ms']
    p = s['pdr']
    t = s['throughput_mbps']
    f = s['fairness_index']
    m = s['deadline_misses']
    print(f'{sched:<15s}: Latency={l["mean"]:.3f} +- {l["ci95"]:.3f}ms | PDR={p["mean"]:.4f} +- {p["ci95"]:.4f} | Tput={t["mean"]:.2f} +- {t["ci95"]:.2f}Mbps | Fairness={f["mean"]:.4f} +- {f["ci95"]:.4f} | Misses={m["mean"]:.1f} +- {m["ci95"]:.1f}')
print('Multi-seed validation saved to experiments/multi_seed_statistical_summary.json')
