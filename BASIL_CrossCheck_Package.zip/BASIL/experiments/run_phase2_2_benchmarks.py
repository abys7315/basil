import asyncio
import hashlib
import json
import math
import os
import sys
import uuid
from pathlib import Path
from typing import Dict, List, Any

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "backend"))
from app.simulation.runner import SimulationRunner

# 10 random seeds for rigorous statistical confidence
SEEDS = [42, 101, 2024, 777, 9999, 12345, 54321, 98765, 11111, 22222]
SCHEDULERS = ["FIFO", "RoundRobin", "StrictPriority", "BASIL_PSA"]

# Core Scenarios
SCENARIOS = {
    "normal_traffic": {
        "description": "Uniform baseline traffic across 4 devices",
        "num_devices": 4,
        "simulation_time": 2.0,
        "data_rate": 10.0,
        "traffic_mode": "normal",
        "normal_rate": 100.0,
        "burst_rate": 100.0,
        "burst_ratio": 0.0,
        "ap_power": 100.0,
        "coverage_mode": "radial",
    },
    "sudden_bursts": {
        "description": "Periodic traffic bursts across 4 devices",
        "num_devices": 4,
        "simulation_time": 2.0,
        "data_rate": 10.0,
        "traffic_mode": "burst",
        "normal_rate": 80.0,
        "burst_rate": 400.0,
        "burst_ratio": 0.30,
        "ap_power": 100.0,
        "coverage_mode": "radial",
    },
    "high_device_density": {
        "description": "16 concurrent devices testing scale, channel diversity, and queue buildup (radial coverage)",
        "num_devices": 16,
        "simulation_time": 2.0,
        "data_rate": 10.0,
        "traffic_mode": "burst",
        "normal_rate": 30.0,
        "burst_rate": 120.0,
        "burst_ratio": 0.25,
        "ap_power": 100.0,
        "coverage_mode": "radial",
    },
    "mixed_semantic_traffic": {
        "description": "Heterogeneous traffic classes with 4 priority tiers and varied deadlines",
        "num_devices": 4,
        "simulation_time": 2.0,
        "data_rate": 10.0,
        "traffic_mode": "burst",
        "normal_rate": 80.0,
        "burst_rate": 350.0,
        "burst_ratio": 0.35,
        "ap_power": 100.0,
        "coverage_mode": "radial",
    },
    "degraded_optical_channel": {
        "description": "Severe optical path attenuation (P_t = 25 mW) causing high PER on distant nodes",
        "num_devices": 4,
        "simulation_time": 2.0,
        "data_rate": 10.0,
        "traffic_mode": "burst",
        "normal_rate": 80.0,
        "burst_rate": 350.0,
        "burst_ratio": 0.30,
        "ap_power": 25.0,
        "coverage_mode": "radial",
    },
    "sustained_emergency_traffic": {
        "description": "Continuous high-priority emergency stream on Device 0 to assess best-effort starvation",
        "num_devices": 4,
        "simulation_time": 2.0,
        "data_rate": 10.0,
        "traffic_mode": "burst",
        "normal_rate": 120.0,
        "burst_rate": 500.0,
        "burst_ratio": 0.50,
        "ap_power": 100.0,
        "coverage_mode": "radial",
    },
    "dense_viable_coverage": {
        "description": "16 devices uniformly placed within viable optical coverage (d in [0.9m, 2.0m], PER < 0.02)",
        "num_devices": 16,
        "simulation_time": 2.0,
        "data_rate": 10.0,
        "traffic_mode": "burst",
        "normal_rate": 30.0,
        "burst_rate": 120.0,
        "burst_ratio": 0.25,
        "ap_power": 100.0,
        "coverage_mode": "viable",
    },
    "mixed_optical_coverage": {
        "description": "16 devices: 8 viable near LOS and 8 degraded edge nodes",
        "num_devices": 16,
        "simulation_time": 2.0,
        "data_rate": 10.0,
        "traffic_mode": "burst",
        "normal_rate": 30.0,
        "burst_rate": 120.0,
        "burst_ratio": 0.25,
        "ap_power": 100.0,
        "coverage_mode": "mixed",
    },
}

# Controlled Semantic Experiments
CONTROLLED_SCENARIOS = {
    "semantic_equal_deadlines": {
        "description": "Equal tight deadlines (20ms) across all 4 classes; only semantic importance varies (0.20 to 1.00)",
        "traffic_mode": "semantic_equal_deadlines",
        "num_devices": 4,
        "simulation_time": 2.0,
        "data_rate": 10.0,
        "normal_rate": 80.0,
        "burst_rate": 350.0,
        "burst_ratio": 0.35,
        "ap_power": 100.0,
    },
    "semantic_equal_importance": {
        "description": "Equal semantic importance (0.50) across all classes; deadlines vary (15ms, 25ms, 40ms, 80ms)",
        "traffic_mode": "semantic_equal_importance",
        "num_devices": 4,
        "simulation_time": 2.0,
        "data_rate": 10.0,
        "normal_rate": 80.0,
        "burst_rate": 350.0,
        "burst_ratio": 0.35,
        "ap_power": 100.0,
    },
    "semantic_conflict_urgency": {
        "description": "Direct conflict: low-importance (Class 0: 0.20) has tight 15ms deadline; high-importance (Class 3: 1.00) has loose 80ms deadline",
        "traffic_mode": "semantic_conflict_urgency",
        "num_devices": 4,
        "simulation_time": 2.0,
        "data_rate": 10.0,
        "normal_rate": 80.0,
        "burst_rate": 350.0,
        "burst_ratio": 0.35,
        "ap_power": 100.0,
    },
    "emergency_vs_bulk_overload": {
        "description": "Sustained overload: 80% bulk best-effort traffic competing with 20% critical emergency telemetry",
        "traffic_mode": "emergency_vs_bulk_overload",
        "num_devices": 4,
        "simulation_time": 2.0,
        "data_rate": 10.0,
        "normal_rate": 100.0,
        "burst_rate": 450.0,
        "burst_ratio": 0.40,
        "ap_power": 100.0,
    },
}

# Weight Sensitivity Configurations (sum to 1.000)
WEIGHT_CONFIGS = {
    "nominal": {"w_s": 0.20, "w_u": 0.25, "w_b": 0.15, "w_c": 0.15, "w_q": 0.15, "w_f": 0.10},
    "high_semantic": {"w_s": 0.40, "w_u": 0.15, "w_b": 0.15, "w_c": 0.10, "w_q": 0.10, "w_f": 0.10},
    "high_urgency": {"w_s": 0.15, "w_u": 0.40, "w_b": 0.15, "w_c": 0.10, "w_q": 0.10, "w_f": 0.10},
    "high_channel": {"w_s": 0.15, "w_u": 0.15, "w_b": 0.15, "w_c": 0.35, "w_q": 0.10, "w_f": 0.10},
    "balanced_equal": {"w_s": 0.1667, "w_u": 0.1667, "w_b": 0.1667, "w_c": 0.1667, "w_q": 0.1667, "w_f": 0.1665},
}

# Predictors
PREDICTORS = ["cusum", "ewma", "persistence", "static"]

# Ablations
ABLATIONS = {
    "BASIL_PSA (Full Model)": {},
    "No Burst Prediction": {"ablation_no_prediction": 1.0},
    "No Semantic Importance": {"ablation_no_semantic": 1.0},
    "No Channel Awareness": {"ablation_no_channel": 1.0},
    "No Fairness Adjustment": {"ablation_no_fairness": 1.0},
}

T_CRIT_95 = {
    5: 2.776,
    9: 2.262, # N=10, df=9
    10: 2.228,
}

def calc_stats(values: List[float], df: int = 9) -> Dict[str, float]:
    n = len(values)
    if n == 0:
        return {"mean": 0.0, "std": 0.0, "ci95": 0.0, "min": 0.0, "max": 0.0}
    mean = sum(values) / n
    if n > 1:
        var = sum((x - mean) ** 2 for x in values) / (n - 1)
        std = math.sqrt(var)
        t_val = T_CRIT_95.get(n - 1, 1.96)
        ci95 = t_val * (std / math.sqrt(n))
    else:
        std = 0.0
        ci95 = 0.0
    return {
        "mean": round(mean, 4),
        "std": round(std, 4),
        "ci95": round(ci95, 4),
        "min": round(min(values), 4),
        "max": round(max(values), 4),
    }

def calc_paired_difference(a_vals: List[float], b_vals: List[float]) -> Dict[str, float]:
    diffs = [a - b for a, b in zip(a_vals, b_vals)]
    return calc_stats(diffs, df=len(diffs)-1)

def compute_config_hash(cfg: dict) -> str:
    serialized = json.dumps(cfg, sort_keys=True)
    return hashlib.sha256(serialized.encode("utf-8")).hexdigest()[:12]

async def main():
    runner = SimulationRunner()
    manifest_records = []
    
    print("================================================================================")
    print("      BASIL Phase 2.2 — Algorithm Improvement and Research Differentiation      ")
    print("================================================================================")

    # -------------------------------------------------------------------------
    # 1. EVALUATION BENCHMARKS (Core Scenarios x 4 Schedulers x 10 Seeds)
    # -------------------------------------------------------------------------
    print(f"\n[PART 1] Running Evaluation Benchmarks ({len(SCENARIOS)} scenarios x {len(SCHEDULERS)} schedulers x {len(SEEDS)} seeds)...")
    raw_eval = {}
    summary_eval = {}
    paired_comparisons = {}
    strongest_baselines = {}

    for sc_name, sc_cfg in SCENARIOS.items():
        print(f"\n>> Scenario: {sc_name} ({sc_cfg['description']})")
        raw_eval[sc_name] = {}
        summary_eval[sc_name] = {}
        paired_comparisons[sc_name] = {}

        metrics_per_sched = {}

        for sched in SCHEDULERS:
            raw_eval[sc_name][sched] = []
            m = {
                "total_generated": [],
                "delivered_on_time": [],
                "delivered_late": [],
                "lost_channel": [],
                "dropped_queue": [],
                "pending_queue": [],
                "pdr": [],
                "channel_pdr": [],
                "avg_latency_ms": [],
                "p95_latency_ms": [],
                "p99_latency_ms": [],
                "throughput_mbps": [],
                "goodput_raw_mbps": [],
                "goodput_semantic_mbps": [],
                "total_deadline_misses": [],
                "deadline_success_rate": [],
                "jain_fairness_index": [],
                "burst_prediction_mae": [],
                "burst_prediction_rmse": [],
                "persistence_baseline_mae": [],
                "static_baseline_mae": [],
            }

            for seed in SEEDS:
                cfg = dict(sc_cfg)
                cfg["scheduler"] = sched
                cfg["seed"] = seed
                run_id = f"eval_{sc_name}_{sched}_s{seed}_{uuid.uuid4().hex[:6]}"
                cfg_hash = compute_config_hash(cfg)

                try:
                    res = await runner.run(cfg, engine="ns3")
                    raw_eval[sc_name][sched].append(res)
                    for key in m.keys():
                        m[key].append(res.get(key, 0.0))

                    manifest_records.append({
                        "run_id": run_id,
                        "experiment_group": "core_evaluation",
                        "scenario_id": sc_name,
                        "scheduler_id": sched,
                        "seed": seed,
                        "engine": "ns3",
                        "ns3_version": res.get("ns3_version", "3.42"),
                        "config_hash": cfg_hash,
                        "status": "SUCCESS",
                        "delivered_on_time": res.get("delivered_on_time", 0),
                        "delivered_late": res.get("delivered_late", 0),
                        "lost_channel": res.get("lost_channel", 0),
                        "dropped_queue": res.get("dropped_queue", 0),
                        "pending_queue": res.get("pending_queue", 0),
                        "pdr": res.get("pdr", 0.0),
                        "avg_latency_ms": res.get("avg_latency_ms", 0.0),
                        "goodput_semantic_mbps": res.get("goodput_semantic_mbps", 0.0),
                    })
                except Exception as ex:
                    print(f"Error on {run_id}: {ex}")
                    manifest_records.append({
                        "run_id": run_id,
                        "experiment_group": "core_evaluation",
                        "scenario_id": sc_name,
                        "scheduler_id": sched,
                        "seed": seed,
                        "engine": "ns3",
                        "ns3_version": "3.42",
                        "config_hash": cfg_hash,
                        "status": "FAILED",
                        "error": str(ex)
                    })

            metrics_per_sched[sched] = m
            summary_eval[sc_name][sched] = {k: calc_stats(v) for k, v in m.items()}
            s = summary_eval[sc_name][sched]
            print(f"  {sched:<15} Latency={s['avg_latency_ms']['mean']}ms | p95={s['p95_latency_ms']['mean']} | OnTime={s['delivered_on_time']['mean']} | Missed={s['total_deadline_misses']['mean']} | PDR={s['pdr']['mean']} | SemGoodput={s['goodput_semantic_mbps']['mean']} Mbps | Jain={s['jain_fairness_index']['mean']}")

        # Compute paired per-seed differences: BASIL_PSA vs FIFO, RoundRobin, StrictPriority
        basil_m = metrics_per_sched["BASIL_PSA"]
        for base in ["FIFO", "RoundRobin", "StrictPriority"]:
            paired_comparisons[sc_name][f"BASIL_vs_{base}"] = {}
            for key in ["avg_latency_ms", "p95_latency_ms", "goodput_semantic_mbps", "total_deadline_misses", "pdr", "jain_fairness_index"]:
                paired_comparisons[sc_name][f"BASIL_vs_{base}"][key] = calc_paired_difference(basil_m[key], metrics_per_sched[base][key])

        # Strongest baseline identification per metric
        # Best Latency: min mean
        baselines = ["FIFO", "RoundRobin", "StrictPriority"]
        best_lat_base = min(baselines, key=lambda b: summary_eval[sc_name][b]["avg_latency_ms"]["mean"])
        best_pdr_base = max(baselines, key=lambda b: summary_eval[sc_name][b]["pdr"]["mean"])
        best_sem_base = max(baselines, key=lambda b: summary_eval[sc_name][b]["goodput_semantic_mbps"]["mean"])
        best_fair_base = max(baselines, key=lambda b: summary_eval[sc_name][b]["jain_fairness_index"]["mean"])
        best_miss_base = min(baselines, key=lambda b: summary_eval[sc_name][b]["total_deadline_misses"]["mean"])

        strongest_baselines[sc_name] = {
            "lowest_latency": {
                "baseline": best_lat_base,
                "baseline_mean": summary_eval[sc_name][best_lat_base]["avg_latency_ms"]["mean"],
                "basil_mean": summary_eval[sc_name]["BASIL_PSA"]["avg_latency_ms"]["mean"],
                "paired_diff": paired_comparisons[sc_name][f"BASIL_vs_{best_lat_base}"]["avg_latency_ms"],
            },
            "highest_pdr": {
                "baseline": best_pdr_base,
                "baseline_mean": summary_eval[sc_name][best_pdr_base]["pdr"]["mean"],
                "basil_mean": summary_eval[sc_name]["BASIL_PSA"]["pdr"]["mean"],
                "paired_diff": paired_comparisons[sc_name][f"BASIL_vs_{best_pdr_base}"]["pdr"],
            },
            "highest_semantic_goodput": {
                "baseline": best_sem_base,
                "baseline_mean": summary_eval[sc_name][best_sem_base]["goodput_semantic_mbps"]["mean"],
                "basil_mean": summary_eval[sc_name]["BASIL_PSA"]["goodput_semantic_mbps"]["mean"],
                "paired_diff": paired_comparisons[sc_name][f"BASIL_vs_{best_sem_base}"]["goodput_semantic_mbps"],
            },
            "highest_fairness": {
                "baseline": best_fair_base,
                "baseline_mean": summary_eval[sc_name][best_fair_base]["jain_fairness_index"]["mean"],
                "basil_mean": summary_eval[sc_name]["BASIL_PSA"]["jain_fairness_index"]["mean"],
                "paired_diff": paired_comparisons[sc_name][f"BASIL_vs_{best_fair_base}"]["jain_fairness_index"],
            },
            "lowest_deadline_misses": {
                "baseline": best_miss_base,
                "baseline_mean": summary_eval[sc_name][best_miss_base]["total_deadline_misses"]["mean"],
                "basil_mean": summary_eval[sc_name]["BASIL_PSA"]["total_deadline_misses"]["mean"],
                "paired_diff": paired_comparisons[sc_name][f"BASIL_vs_{best_miss_base}"]["total_deadline_misses"],
            },
        }

    eval_out = Path(__file__).resolve().parent / "phase2_2_evaluation_results.json"
    with open(eval_out, "w") as f:
        json.dump({
            "summary": summary_eval,
            "paired_diff": paired_comparisons,
            "strongest_baselines": strongest_baselines,
            "raw": raw_eval
        }, f, indent=2)
    print(f"\n[DONE] Saved core evaluation results to {eval_out}")

    # -------------------------------------------------------------------------
    # 2. PREDICTOR ACCURACY & IMPACT BENCHMARK (CUSUM vs EWMA vs Persistence vs Static)
    # -------------------------------------------------------------------------
    print("\n[PART 2] Running Predictor Comparison Study (sudden_bursts x 4 Predictors x 10 Seeds)...")
    pred_raw = {}
    pred_summary = {}
    pred_base_cfg = SCENARIOS["sudden_bursts"]

    for pred in PREDICTORS:
        pred_raw[pred] = []
        m = {
            "burst_prediction_mae": [],
            "burst_prediction_rmse": [],
            "persistence_baseline_mae": [],
            "static_baseline_mae": [],
            "avg_latency_ms": [],
            "p95_latency_ms": [],
            "pdr": [],
            "goodput_semantic_mbps": [],
            "total_deadline_misses": [],
        }

        for seed in SEEDS:
            cfg = dict(pred_base_cfg)
            cfg["scheduler"] = "BASIL_PSA"
            cfg["predictor_type"] = pred
            cfg["seed"] = seed
            run_id = f"pred_{pred}_s{seed}_{uuid.uuid4().hex[:6]}"
            cfg_hash = compute_config_hash(cfg)

            res = await runner.run(cfg, engine="ns3")
            pred_raw[pred].append(res)
            for k in m.keys():
                m[k].append(res.get(k, 0.0))

            manifest_records.append({
                "run_id": run_id,
                "experiment_group": "predictor_comparison",
                "scenario_id": "sudden_bursts",
                "scheduler_id": f"BASIL_PSA_{pred}",
                "seed": seed,
                "engine": "ns3",
                "ns3_version": "3.42",
                "config_hash": cfg_hash,
                "status": "SUCCESS",
                "mae": res.get("burst_prediction_mae", 0.0),
                "rmse": res.get("burst_prediction_rmse", 0.0),
                "pdr": res.get("pdr", 0.0),
                "avg_latency_ms": res.get("avg_latency_ms", 0.0),
            })

        pred_summary[pred] = {k: calc_stats(v) for k, v in m.items()}
        s = pred_summary[pred]
        print(f"  Predictor: {pred:<12} MAE={s['burst_prediction_mae']['mean']:.3f} | RMSE={s['burst_prediction_rmse']['mean']:.3f} | Latency={s['avg_latency_ms']['mean']:.2f}ms | Missed={s['total_deadline_misses']['mean']:.1f} | SemGoodput={s['goodput_semantic_mbps']['mean']:.3f} Mbps")

    pred_out = Path(__file__).resolve().parent / "phase2_2_predictor_results.json"
    with open(pred_out, "w") as f:
        json.dump({"summary": pred_summary, "raw": pred_raw}, f, indent=2)
    print(f"[DONE] Saved predictor results to {pred_out}")

    # -------------------------------------------------------------------------
    # 3. CONTROLLED SEMANTIC-AWARE SCHEDULING EXPERIMENTS
    # -------------------------------------------------------------------------
    print("\n[PART 3] Running Controlled Semantic Experiments (4 scenarios x 4 schedulers x 10 seeds)...")
    ctrl_raw = {}
    ctrl_summary = {}

    for c_name, c_cfg in CONTROLLED_SCENARIOS.items():
        print(f"\n>> Controlled Scenario: {c_name} ({c_cfg['description']})")
        ctrl_raw[c_name] = {}
        ctrl_summary[c_name] = {}

        for sched in SCHEDULERS:
            ctrl_raw[c_name][sched] = []
            m = {
                "pdr": [],
                "avg_latency_ms": [],
                "goodput_semantic_mbps": [],
                "total_deadline_misses": [],
                "deadline_success_rate": [],
                "delivered_on_time": [],
                "delivered_late": [],
            }
            # Per-class metrics
            class_m = {c: {"delivered_on_time": [], "delivered_late": [], "deadline_misses": [], "latency_ms": []} for c in range(4)}

            for seed in SEEDS:
                cfg = dict(c_cfg)
                cfg["scheduler"] = sched
                cfg["seed"] = seed
                run_id = f"ctrl_{c_name}_{sched}_s{seed}_{uuid.uuid4().hex[:6]}"
                cfg_hash = compute_config_hash(cfg)

                res = await runner.run(cfg, engine="ns3")
                ctrl_raw[c_name][sched].append(res)
                for k in m.keys():
                    m[k].append(res.get(k, 0.0))

                # Extract per-class stats
                p_classes = res.get("per_class_stats", [])
                for pc in p_classes:
                    cid = pc.get("class_id", -1)
                    if cid in class_m:
                        class_m[cid]["delivered_on_time"].append(pc.get("delivered_on_time", 0))
                        class_m[cid]["delivered_late"].append(pc.get("delivered_late", 0))
                        class_m[cid]["deadline_misses"].append(pc.get("deadline_misses", 0))
                        class_m[cid]["latency_ms"].append(pc.get("avg_latency_ms", 0.0))

                manifest_records.append({
                    "run_id": run_id,
                    "experiment_group": "controlled_semantic",
                    "scenario_id": c_name,
                    "scheduler_id": sched,
                    "seed": seed,
                    "engine": "ns3",
                    "ns3_version": "3.42",
                    "config_hash": cfg_hash,
                    "status": "SUCCESS",
                    "pdr": res.get("pdr", 0.0),
                    "goodput_semantic_mbps": res.get("goodput_semantic_mbps", 0.0),
                    "deadline_misses": res.get("total_deadline_misses", 0),
                })

            ctrl_summary[c_name][sched] = {
                "overall": {k: calc_stats(v) for k, v in m.items()},
                "per_class": {c: {ck: calc_stats(cv) for ck, cv in class_m[c].items()} for c in range(4)}
            }
            s = ctrl_summary[c_name][sched]["overall"]
            print(f"  {sched:<15} SemGoodput={s['goodput_semantic_mbps']['mean']:.3f} Mbps | OnTime={s['delivered_on_time']['mean']:.1f} | Late={s['delivered_late']['mean']:.1f} | Missed={s['total_deadline_misses']['mean']:.1f} | DSR={s['deadline_success_rate']['mean']*100:.1f}%")

    ctrl_out = Path(__file__).resolve().parent / "phase2_2_controlled_results.json"
    with open(ctrl_out, "w") as f:
        json.dump({"summary": ctrl_summary, "raw": ctrl_raw}, f, indent=2)
    print(f"[DONE] Saved controlled semantic results to {ctrl_out}")

    # -------------------------------------------------------------------------
    # 4. WEIGHT SENSITIVITY STUDY (5 Configurations x 10 Seeds)
    # -------------------------------------------------------------------------
    print("\n[PART 4] Running Weight Sensitivity Study (mixed_semantic_traffic x 5 Configs x 10 Seeds)...")
    weights_raw = {}
    weights_summary = {}
    w_base_cfg = SCENARIOS["mixed_semantic_traffic"]

    for w_name, w_weights in WEIGHT_CONFIGS.items():
        weights_raw[w_name] = []
        m = {
            "avg_latency_ms": [],
            "p95_latency_ms": [],
            "goodput_semantic_mbps": [],
            "pdr": [],
            "total_deadline_misses": [],
            "deadline_success_rate": [],
            "jain_fairness_index": [],
        }

        for seed in SEEDS:
            cfg = dict(w_base_cfg)
            cfg["scheduler"] = "BASIL_PSA"
            cfg["seed"] = seed
            cfg.update(w_weights)
            run_id = f"weight_{w_name}_s{seed}_{uuid.uuid4().hex[:6]}"
            cfg_hash = compute_config_hash(cfg)

            res = await runner.run(cfg, engine="ns3")
            weights_raw[w_name].append(res)
            for k in m.keys():
                m[k].append(res.get(k, 0.0))

            manifest_records.append({
                "run_id": run_id,
                "experiment_group": "weight_sensitivity",
                "scenario_id": "mixed_semantic_traffic",
                "scheduler_id": f"BASIL_PSA_{w_name}",
                "seed": seed,
                "engine": "ns3",
                "ns3_version": "3.42",
                "config_hash": cfg_hash,
                "status": "SUCCESS",
                "goodput_semantic_mbps": res.get("goodput_semantic_mbps", 0.0),
                "deadline_misses": res.get("total_deadline_misses", 0),
                "jain_fairness_index": res.get("jain_fairness_index", 0.0),
            })

        weights_summary[w_name] = {k: calc_stats(v) for k, v in m.items()}
        s = weights_summary[w_name]
        print(f"  Weights: {w_name:<16} SemGoodput={s['goodput_semantic_mbps']['mean']:.3f} Mbps | Latency={s['avg_latency_ms']['mean']:.2f}ms | Missed={s['total_deadline_misses']['mean']:.1f} | Jain={s['jain_fairness_index']['mean']:.3f}")

    weights_out = Path(__file__).resolve().parent / "phase2_2_weights_results.json"
    with open(weights_out, "w") as f:
        json.dump({"summary": weights_summary, "raw": weights_raw}, f, indent=2)
    print(f"[DONE] Saved weight sensitivity results to {weights_out}")

    # -------------------------------------------------------------------------
    # 5. ABLATION STUDY (5 Ablations x 2 Scenarios x 10 Seeds)
    # -------------------------------------------------------------------------
    print("\n[PART 5] Running Ablation Study (2 Scenarios x 5 Ablations x 10 Seeds)...")
    ablation_raw = {}
    ablation_summary = {}

    for sc_name in ["mixed_semantic_traffic", "sudden_bursts"]:
        ablation_raw[sc_name] = {}
        ablation_summary[sc_name] = {}
        sc_cfg = SCENARIOS[sc_name]
        print(f"\n>> Ablations for Scenario: {sc_name}")

        for ab_name, ab_flags in ABLATIONS.items():
            ablation_raw[sc_name][ab_name] = []
            m = {
                "avg_latency_ms": [],
                "p95_latency_ms": [],
                "goodput_semantic_mbps": [],
                "pdr": [],
                "total_deadline_misses": [],
                "deadline_success_rate": [],
                "jain_fairness_index": [],
            }

            for seed in SEEDS:
                cfg = dict(sc_cfg)
                cfg["scheduler"] = "BASIL_PSA"
                cfg["seed"] = seed
                cfg.update(ab_flags)
                run_id = f"abl_{sc_name}_{ab_name}_s{seed}_{uuid.uuid4().hex[:6]}"
                cfg_hash = compute_config_hash(cfg)

                res = await runner.run(cfg, engine="ns3")
                ablation_raw[sc_name][ab_name].append(res)
                for k in m.keys():
                    m[k].append(res.get(k, 0.0))

                manifest_records.append({
                    "run_id": run_id,
                    "experiment_group": "ablation_study",
                    "scenario_id": sc_name,
                    "scheduler_id": ab_name,
                    "seed": seed,
                    "engine": "ns3",
                    "ns3_version": "3.42",
                    "config_hash": cfg_hash,
                    "status": "SUCCESS",
                    "goodput_semantic_mbps": res.get("goodput_semantic_mbps", 0.0),
                    "deadline_misses": res.get("total_deadline_misses", 0),
                })

            ablation_summary[sc_name][ab_name] = {k: calc_stats(v) for k, v in m.items()}
            s = ablation_summary[sc_name][ab_name]
            print(f"  {ab_name:<25} Latency={s['avg_latency_ms']['mean']:.2f}ms | SemGoodput={s['goodput_semantic_mbps']['mean']:.3f} Mbps | Missed={s['total_deadline_misses']['mean']:.1f} | Jain={s['jain_fairness_index']['mean']:.3f}")

    abl_out = Path(__file__).resolve().parent / "phase2_2_ablation_results.json"
    with open(abl_out, "w") as f:
        json.dump({"summary": ablation_summary, "raw": ablation_raw}, f, indent=2)
    print(f"[DONE] Saved ablation results to {abl_out}")

    # -------------------------------------------------------------------------
    # 6. EXPERIMENT MANIFEST GENERATION
    # -------------------------------------------------------------------------
    manifest_out = Path(__file__).resolve().parent / "phase2_2_experiment_manifest.json"
    with open(manifest_out, "w") as f:
        json.dump({
            "total_runs": len(manifest_records),
            "successful_runs": sum(1 for r in manifest_records if r["status"] == "SUCCESS"),
            "failed_runs": sum(1 for r in manifest_records if r["status"] == "FAILED"),
            "engine": "ns3",
            "ns3_version": "3.42",
            "runs": manifest_records
        }, f, indent=2)
    print(f"\n================================================================================")
    print(f"[SUCCESS] Reconciled {len(manifest_records)} runs into manifest: {manifest_out}")
    print(f"================================================================================")

if __name__ == "__main__":
    asyncio.run(main())
