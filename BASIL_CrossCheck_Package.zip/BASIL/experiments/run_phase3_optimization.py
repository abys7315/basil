import asyncio
import json
import logging
import math
import sys
import time
from pathlib import Path
from typing import Dict, List, Any
import numpy as np

# Add backend to path
sys.path.insert(0, str(Path(__file__).parent.parent / "backend"))
from app.simulation.runner import SimulationRunner

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("Phase3Benchmark")

SCHEDULERS = ["FIFO", "RoundRobin", "StrictPriority", "BASIL_PSA", "BASIL_OPT"]

SCENARIOS = {
    "normal_traffic": {
        "num_devices": 4,
        "simulation_time": 1.0,
        "data_rate": 15.0,
        "traffic_mode": "normal",
        "burst_ratio": 0.0,
        "room_width": 5.0,
        "room_height": 3.0,
        "ap_power": 100.0,
        "half_angle": 60.0,
        "packet_size": 1024,
        "normal_rate": 100.0,
        "burst_rate": 100.0,
    },
    "sudden_bursts": {
        "num_devices": 4,
        "simulation_time": 1.0,
        "data_rate": 15.0,
        "traffic_mode": "burst",
        "burst_ratio": 0.35,
        "room_width": 5.0,
        "room_height": 3.0,
        "ap_power": 100.0,
        "half_angle": 60.0,
        "packet_size": 1024,
        "normal_rate": 80.0,
        "burst_rate": 400.0,
    },
    "mixed_semantic_traffic": {
        "num_devices": 4,
        "simulation_time": 1.0,
        "data_rate": 15.0,
        "traffic_mode": "burst",
        "burst_ratio": 0.25,
        "room_width": 5.0,
        "room_height": 3.0,
        "ap_power": 100.0,
        "half_angle": 60.0,
        "packet_size": 1024,
        "normal_rate": 90.0,
        "burst_rate": 350.0,
    },
    "dense_viable_coverage": {
        "num_devices": 4,
        "simulation_time": 1.0,
        "data_rate": 15.0,
        "traffic_mode": "burst",
        "burst_ratio": 0.30,
        "room_width": 6.0,
        "room_height": 3.0,
        "ap_power": 60.0,  # Lower power creates realistic optical channel PER gradient
        "half_angle": 60.0,
        "packet_size": 1024,
        "normal_rate": 80.0,
        "burst_rate": 350.0,
    },
}

SEEDS = [42, 43, 44, 45, 46]

async def run_benchmark():
    runner = SimulationRunner()
    raw_runs = []
    summary_by_scenario = {}

    total_runs = len(SCENARIOS) * len(SEEDS) * len(SCHEDULERS)
    current_run = 0
    start_total_time = time.time()

    logger.info("Starting Phase 3 Multi-Scenario BASIL-OPT Optimization Benchmarks (%d total runs)", total_runs)

    for sc_name, base_cfg in SCENARIOS.items():
        summary_by_scenario[sc_name] = {}
        for sched in SCHEDULERS:
            summary_by_scenario[sc_name][sched] = {
                "semantic_goodput_mbps": [],
                "throughput_mbps": [],
                "avg_latency_ms": [],
                "p95_latency_ms": [],
                "deadline_misses": [],
                "pdr": [],
                "jain_fairness": [],
                "execution_time_s": [],
                "mip_gap": [],
            }

        for seed in SEEDS:
            logger.info("--- Scenario: %s | Seed: %d ---", sc_name, seed)
            
            # Trace cache from the physical ns-3 run for this seed
            seed_trace = []
            seed_dev_stats = []
            seed_base_res = {}

            # Run all schedulers for this seed
            seed_results = {}
            for sched in SCHEDULERS:
                current_run += 1
                cfg = dict(base_cfg)
                cfg["scheduler"] = sched
                cfg["seed"] = seed
                
                t0 = time.time()
                try:
                    if sched == "BASIL_OPT":
                        from app.algorithms.basil_opt import BasilOptSolver
                        solver = BasilOptSolver(time_limit_s=30.0, mip_rel_gap=0.001)
                        dev_per = [d.get("per", 0.0) for d in seed_dev_stats]
                        res = solver.solve_slotted(
                            packets=seed_trace,
                            num_devices=int(base_cfg.get("num_devices", len(seed_dev_stats) or 4)),
                            simulation_time_s=float(base_cfg.get("simulation_time", 1.0)),
                            data_rate_mbps=float(base_cfg.get("data_rate", 15.0)),
                            packet_size_bytes=int(base_cfg.get("packet_size", 1024)),
                            device_per=dev_per,
                        )
                        res["per_device_stats"] = seed_dev_stats
                        res["per_class_stats"] = seed_base_res.get("per_class_stats", [])
                        res["time_series"] = seed_base_res.get("time_series", [])
                        wall_time = time.time() - t0
                    else:
                        if sched == "FIFO":
                            cfg["export_trace"] = 1.0
                        res = await runner.run(cfg, engine="ns3")
                        wall_time = time.time() - t0
                        if sched == "FIFO":
                            seed_trace = res.get("packet_trace", [])
                            seed_dev_stats = res.get("per_device_stats", [])
                            seed_base_res = res
                except Exception as e:
                    logger.error("Error running %s %s seed %d: %s", sc_name, sched, seed, e)
                    continue

                # Extract key metrics
                sem_goodput = res.get("goodput_semantic_mbps", 0.0)
                raw_goodput = res.get("throughput_mbps", res.get("goodput_raw_mbps", 0.0))
                avg_lat = res.get("avg_latency_ms", 0.0)
                p95_lat = res.get("p95_latency_ms", 0.0)
                misses = res.get("total_deadline_misses", 0)
                pdr = res.get("packet_delivery_ratio", res.get("pdr", 0.0))
                jain = res.get("jain_fairness_index", res.get("fairness_index", 0.0))
                solver_exec = res.get("execution_time_s", wall_time)
                mip_gap = res.get("mip_gap", 0.0)
                status = res.get("status", "Completed")

                run_entry = {
                    "scenario": sc_name,
                    "seed": seed,
                    "scheduler": sched,
                    "status": status,
                    "is_optimal": res.get("is_optimal", None),
                    "mip_gap": mip_gap,
                    "execution_time_s": solver_exec,
                    "wall_time_s": wall_time,
                    "goodput_semantic_mbps": sem_goodput,
                    "throughput_mbps": raw_goodput,
                    "avg_latency_ms": avg_lat,
                    "p95_latency_ms": p95_lat,
                    "total_deadline_misses": misses,
                    "pdr": pdr,
                    "jain_fairness_index": jain,
                    "total_packets_generated": res.get("total_packets_generated", 0),
                    "delivered_on_time": res.get("delivered_on_time", 0),
                    "delivered_late": res.get("delivered_late", 0),
                    "lost_channel": res.get("lost_channel", 0),
                    "dropped_queue": res.get("dropped_queue", 0),
                    "pending_queue": res.get("pending_queue", 0),
                }
                raw_runs.append(run_entry)
                seed_results[sched] = run_entry

                # Append to summary lists
                s_dict = summary_by_scenario[sc_name][sched]
                s_dict["semantic_goodput_mbps"].append(sem_goodput)
                s_dict["throughput_mbps"].append(raw_goodput)
                s_dict["avg_latency_ms"].append(avg_lat)
                s_dict["p95_latency_ms"].append(p95_lat)
                s_dict["deadline_misses"].append(misses)
                s_dict["pdr"].append(pdr)
                s_dict["jain_fairness"].append(jain)
                s_dict["execution_time_s"].append(solver_exec)
                s_dict["mip_gap"].append(mip_gap)

                logger.info(
                    "[%d/%d] %s | %s: SemGoodput=%.3f Mbps, Lat=%.2f ms, Misses=%d, PDR=%.1f%% (Exec=%.2fs)",
                    current_run,
                    total_runs,
                    sc_name,
                    sched,
                    sem_goodput,
                    avg_lat,
                    misses,
                    pdr * 100.0,
                    solver_exec,
                )

    # Compute statistical aggregations
    aggregated = {}
    for sc_name, sched_data in summary_by_scenario.items():
        aggregated[sc_name] = {}
        opt_mean_goodput = np.mean(sched_data["BASIL_OPT"]["semantic_goodput_mbps"]) if sched_data["BASIL_OPT"]["semantic_goodput_mbps"] else 1.0

        for sched, metrics in sched_data.items():
            sem_m = float(np.mean(metrics["semantic_goodput_mbps"]))
            sem_std = float(np.std(metrics["semantic_goodput_mbps"]))
            th_m = float(np.mean(metrics["throughput_mbps"]))
            lat_m = float(np.mean(metrics["avg_latency_ms"]))
            p95_m = float(np.mean(metrics["p95_latency_ms"]))
            miss_m = float(np.mean(metrics["deadline_misses"]))
            pdr_m = float(np.mean(metrics["pdr"]))
            jain_m = float(np.mean(metrics["jain_fairness"]))
            exec_m = float(np.mean(metrics["execution_time_s"]))

            # Gap to optimal
            if opt_mean_goodput > 0:
                opt_gap_pct = float(max(0.0, (opt_mean_goodput - sem_m) / opt_mean_goodput * 100.0))
                ratio_to_opt_pct = float((sem_m / opt_mean_goodput) * 100.0)
            else:
                opt_gap_pct = 0.0
                ratio_to_opt_pct = 100.0

            aggregated[sc_name][sched] = {
                "semantic_goodput_mean_mbps": round(sem_m, 4),
                "semantic_goodput_std_mbps": round(sem_std, 4),
                "throughput_mean_mbps": round(th_m, 4),
                "avg_latency_mean_ms": round(lat_m, 2),
                "p95_latency_mean_ms": round(p95_m, 2),
                "deadline_misses_mean": round(miss_m, 2),
                "pdr_mean": round(pdr_m, 4),
                "jain_fairness_mean": round(jain_m, 4),
                "execution_time_mean_s": round(exec_m, 4),
                "optimality_gap_pct": round(opt_gap_pct, 2),
                "ratio_to_optimal_pct": round(ratio_to_opt_pct, 2),
            }

    total_bench_time = time.time() - start_total_time
    output_payload = {
        "metadata": {
            "title": "BASIL Phase 3 — BASIL-OPT Offline Optimization Reference Benchmark",
            "date": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "total_runs": len(raw_runs),
            "total_bench_time_s": round(total_bench_time, 2),
            "solver": "HiGHS-1.16.0",
            "simulator": "ns-3.42 Li-Fi Hybrid Architecture",
            "scenarios": list(SCENARIOS.keys()),
            "schedulers": SCHEDULERS,
            "seeds": SEEDS,
        },
        "aggregated_results": aggregated,
        "runs": raw_runs,
    }

    out_file = Path(__file__).parent / "basil_opt_results.json"
    with open(out_file, "w") as f:
        json.dump(output_payload, f, indent=2)

    logger.info("Saved Phase 3 optimization results to %s", out_file)

    # Print summary table
    print("\n" + "=" * 105)
    print("BASIL PHASE 3: OFFLINE OPTIMALITY REFERENCE COMPARISON (Averaged over 5 seeds per scenario)")
    print("=" * 105)
    for sc_name, sched_dict in aggregated.items():
        print(f"\nScenario: {sc_name}")
        print(f"{'Scheduler':<16} | {'Sem Goodput':<15} | {'Ratio to OPT':<12} | {'Gap to OPT':<10} | {'Misses':<8} | {'Avg Lat':<10} | {'PDR':<7} | {'Fairness':<8} | {'Runtime'}")
        print("-" * 105)
        for sched in SCHEDULERS:
            d = sched_dict[sched]
            g_str = f"{d['semantic_goodput_mean_mbps']:.3f} +/- {d['semantic_goodput_std_mbps']:.3f}"
            r_str = f"{d['ratio_to_optimal_pct']:.1f}%"
            gap_str = f"{d['optimality_gap_pct']:.1f}%"
            m_str = f"{d['deadline_misses_mean']:.1f}"
            lat_str = f"{d['avg_latency_mean_ms']:.2f} ms"
            pdr_str = f"{d['pdr_mean']*100:.1f}%"
            j_str = f"{d['jain_fairness_mean']:.3f}"
            t_str = f"{d['execution_time_mean_s']:.3f}s"
            print(f"{sched:<16} | {g_str:<15} | {r_str:<12} | {gap_str:<10} | {m_str:<8} | {lat_str:<10} | {pdr_str:<7} | {j_str:<8} | {t_str}")

if __name__ == "__main__":
    asyncio.run(run_benchmark())
