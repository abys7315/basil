# BASIL Phase 2 – Comprehensive Research Evaluation & Ablation Results

Evaluated using genuine ns-3.42 Li-Fi simulation engine across 5 random seeds (42, 101, 2024, 777, 9999).

All metrics are reported as **Mean ± 95% Confidence Interval** ($1.96 \cdot \frac{\sigma}{\sqrt{N}}$).


### Scenario: `normal_traffic`

| Scheduler | Mean Latency (ms) | p95 Latency (ms) | p99 Latency (ms) | Throughput (Mbps) | PDR (%) | Deadline Misses | Jain Fairness |
|---|---|---|---|---|---|---|---|
| **FIFO** | 1.01 ± 0.02 | 1.79 ± 0.12 | 2.48 ± 0.20 | 2.95 ± 0.08 | 92.7% ± 0.7% | 0.0 ± 0.0 | 0.9830 ± 0.0068 |
| **RoundRobin** | 1.01 ± 0.02 | 1.83 ± 0.14 | 2.64 ± 0.21 | 2.95 ± 0.08 | 92.7% ± 0.7% | 0.0 ± 0.0 | 0.9830 ± 0.0068 |
| **StrictPriority** | 1.00 ± 0.02 | 1.73 ± 0.13 | 2.66 ± 0.31 | 2.95 ± 0.08 | 92.6% ± 0.6% | 0.0 ± 0.0 | 0.9827 ± 0.0069 |
| **BASIL_PSA** | 1.00 ± 0.02 | 1.74 ± 0.12 | 2.66 ± 0.31 | 2.95 ± 0.08 | 92.6% ± 0.6% | 0.0 ± 0.0 | 0.9827 ± 0.0069 |

### Scenario: `sudden_bursts`

| Scheduler | Mean Latency (ms) | p95 Latency (ms) | p99 Latency (ms) | Throughput (Mbps) | PDR (%) | Deadline Misses | Jain Fairness |
|---|---|---|---|---|---|---|---|
| **FIFO** | 15.48 ± 0.90 | 42.84 ± 3.09 | 52.19 ± 4.41 | 5.06 ± 0.09 | 92.7% ± 0.7% | 425.8 ± 59.4 | 0.9797 ± 0.0078 |
| **RoundRobin** | 15.35 ± 0.80 | 51.32 ± 3.83 | 69.58 ± 7.34 | 5.08 ± 0.09 | 92.9% ± 0.6% | 386.0 ± 35.2 | 0.9813 ± 0.0063 |
| **StrictPriority** | 15.45 ± 0.88 | 43.18 ± 3.12 | 52.37 ± 4.43 | 5.06 ± 0.10 | 92.5% ± 0.7% | 418.8 ± 60.4 | 0.9792 ± 0.0064 |
| **BASIL_PSA** | 15.13 ± 1.01 | 46.87 ± 3.76 | 64.62 ± 2.31 | 5.06 ± 0.10 | 92.5% ± 0.7% | 364.0 ± 48.4 | 0.9789 ± 0.0083 |

### Scenario: `high_device_density`

| Scheduler | Mean Latency (ms) | p95 Latency (ms) | p99 Latency (ms) | Throughput (Mbps) | PDR (%) | Deadline Misses | Jain Fairness |
|---|---|---|---|---|---|---|---|
| **FIFO** | 17.43 ± 1.34 | 56.02 ± 5.66 | 68.62 ± 8.87 | 1.47 ± 0.03 | 23.0% ± 0.5% | 119.8 ± 11.7 | 0.2440 ± 0.0025 |
| **RoundRobin** | 17.26 ± 2.69 | 65.92 ± 5.41 | 86.36 ± 4.53 | 1.47 ± 0.04 | 23.0% ± 0.4% | 100.4 ± 19.9 | 0.2438 ± 0.0026 |
| **StrictPriority** | 17.51 ± 1.45 | 58.98 ± 8.00 | 98.03 ± 11.78 | 1.46 ± 0.03 | 22.9% ± 0.4% | 112.6 ± 11.0 | 0.2432 ± 0.0022 |
| **BASIL_PSA** | 7.82 ± 0.71 | 31.43 ± 6.28 | 59.35 ± 8.49 | 1.47 ± 0.04 | 23.0% ± 0.4% | 18.4 ± 6.3 | 0.2439 ± 0.0031 |

### Scenario: `mixed_semantic_traffic`

| Scheduler | Mean Latency (ms) | p95 Latency (ms) | p99 Latency (ms) | Throughput (Mbps) | PDR (%) | Deadline Misses | Jain Fairness |
|---|---|---|---|---|---|---|---|
| **FIFO** | 9.62 ± 1.83 | 27.61 ± 3.20 | 35.45 ± 4.13 | 5.06 ± 0.09 | 92.6% ± 0.2% | 214.6 ± 76.1 | 0.9806 ± 0.0058 |
| **RoundRobin** | 9.57 ± 1.84 | 35.66 ± 6.20 | 51.74 ± 8.13 | 5.06 ± 0.10 | 92.7% ± 0.3% | 189.6 ± 59.8 | 0.9808 ± 0.0061 |
| **StrictPriority** | 9.66 ± 1.81 | 27.74 ± 2.74 | 35.17 ± 4.42 | 5.06 ± 0.10 | 92.7% ± 0.2% | 211.2 ± 74.8 | 0.9807 ± 0.0063 |
| **BASIL_PSA** | 9.46 ± 1.80 | 28.80 ± 4.52 | 43.97 ± 8.41 | 5.05 ± 0.08 | 92.5% ± 0.7% | 157.8 ± 61.7 | 0.9805 ± 0.0054 |

### Scenario: `degraded_optical_channel`

| Scheduler | Mean Latency (ms) | p95 Latency (ms) | p99 Latency (ms) | Throughput (Mbps) | PDR (%) | Deadline Misses | Jain Fairness |
|---|---|---|---|---|---|---|---|
| **FIFO** | 8.84 ± 1.21 | 27.45 ± 3.84 | 31.25 ± 3.13 | 1.27 ± 0.05 | 25.1% ± 1.2% | 38.8 ± 13.3 | 0.2500 ± 0.0000 |
| **RoundRobin** | 8.49 ± 2.96 | 29.46 ± 12.71 | 34.42 ± 12.63 | 1.27 ± 0.05 | 25.0% ± 1.2% | 45.8 ± 35.3 | 0.2500 ± 0.0000 |
| **StrictPriority** | 8.59 ± 1.35 | 26.68 ± 4.34 | 30.92 ± 3.37 | 1.27 ± 0.06 | 25.1% ± 1.2% | 37.4 ± 13.0 | 0.2500 ± 0.0000 |
| **BASIL_PSA** | 3.52 ± 0.59 | 14.02 ± 2.27 | 16.69 ± 2.32 | 1.27 ± 0.05 | 25.1% ± 1.2% | 1.6 ± 3.1 | 0.2500 ± 0.0000 |

### Scenario: `sustained_emergency_traffic`

| Scheduler | Mean Latency (ms) | p95 Latency (ms) | p99 Latency (ms) | Throughput (Mbps) | PDR (%) | Deadline Misses | Jain Fairness |
|---|---|---|---|---|---|---|---|
| **FIFO** | 82.54 ± 4.21 | 152.05 ± 4.17 | 168.74 ± 6.75 | 9.19 ± 0.08 | 92.3% ± 0.6% | 1914.4 ± 58.8 | 0.9810 ± 0.0066 |
| **RoundRobin** | 81.83 ± 4.23 | 167.13 ± 7.66 | 193.94 ± 6.85 | 9.15 ± 0.06 | 91.9% ± 0.8% | 1830.6 ± 53.1 | 0.9796 ± 0.0064 |
| **StrictPriority** | 80.22 ± 2.83 | 156.66 ± 3.64 | 345.47 ± 112.14 | 9.20 ± 0.08 | 92.4% ± 0.4% | 1777.8 ± 38.5 | 0.9785 ± 0.0081 |
| **BASIL_PSA** | 73.38 ± 3.36 | 240.82 ± 20.36 | 313.00 ± 34.89 | 9.15 ± 0.10 | 91.9% ± 0.6% | 1575.4 ± 89.2 | 0.9762 ± 0.0083 |


### BASIL-PSA Ablation Study (under `sudden_bursts`)

| Configuration | Mean Latency (ms) | p95 Latency (ms) | p99 Latency (ms) | Throughput (Mbps) | Missed Deadlines | Jain Fairness |
|---|---|---|---|---|---|---|
| **BASIL_PSA (Full)** | 15.13 ± 1.01 | 46.87 ± 3.76 | 64.62 ± 2.31 | 5.06 ± 0.10 | 364.0 ± 48.4 | 0.9789 ± 0.0083 |
| **No Burst Prediction** | 15.01 ± 0.91 | 44.80 ± 2.62 | 59.51 ± 4.38 | 5.05 ± 0.09 | 387.8 ± 53.3 | 0.9787 ± 0.0065 |
| **No Semantic Importance** | 15.11 ± 1.04 | 46.62 ± 3.93 | 64.37 ± 2.31 | 5.06 ± 0.10 | 363.6 ± 47.2 | 0.9792 ± 0.0078 |
| **No Channel Awareness** | 15.41 ± 0.99 | 46.89 ± 2.75 | 64.60 ± 5.35 | 5.04 ± 0.09 | 377.4 ± 41.5 | 0.9770 ± 0.0088 |
| **No Fairness Adjustment** | 15.02 ± 1.14 | 47.64 ± 4.35 | 71.67 ± 5.41 | 5.05 ± 0.11 | 344.4 ± 50.3 | 0.9784 ± 0.0075 |