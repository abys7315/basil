import json
import numpy as np

def reconcile_phase3_4():
    input_file = "BASIL/experiments/phase3_3_reconciled_benchmark_results.json"
    output_file = "BASIL/experiments/phase3_4_reconciled_benchmark_results.json"

    with open(input_file, "r") as f:
        data = json.load(f)

    runs = data.get("runs", [])
    updated_runs = []

    for r in runs:
        r_new = dict(r)
        sc = r["scenario"]
        sched = r["scheduler"]
        seed = r["seed"]
        gen = r.get("total_packets_generated", 0)

        # Power resolution
        ap_power_mw = 60.0 if sc == "dense_viable_coverage" else 100.0
        r_new["ap_power_unit"] = "mW"
        r_new["ap_power_mw"] = ap_power_mw
        r_new["ap_power_w"] = round(ap_power_mw * 1e-3, 4)

        # Canonical metric terminology
        sched_pkts = r.get("scheduled_packets_count", r.get("delivered_on_time", 0))
        sched_cov = round(sched_pkts / gen, 6) if gen > 0 else 0.0
        sched_cov_pct = round(sched_cov * 100.0, 4)

        exp_pdr = r.get("expected_pdr", 0.0)
        exp_pdr_pct = round(exp_pdr * 100.0, 4)

        realized_pdr = r.get("realized_pdr", r.get("pdr", 0.0))
        realized_pdr_pct = round(realized_pdr * 100.0, 4)

        # Separate metrics
        r_new["scheduling_coverage"] = sched_cov
        r_new["scheduling_coverage_pct"] = sched_cov_pct
        r_new["scheduled_pdr"] = sched_cov  # backward compatibility alias
        r_new["expected_received_pdr"] = exp_pdr
        r_new["expected_received_pdr_pct"] = exp_pdr_pct
        r_new["realized_received_pdr"] = realized_pdr
        r_new["realized_received_pdr_pct"] = realized_pdr_pct
        r_new["pdr"] = realized_pdr  # PDR strictly reserved for realized received packets / generated

        updated_runs.append(r_new)

    scenarios = ["normal_traffic", "sudden_bursts", "mixed_semantic_traffic", "dense_viable_coverage"]
    schedulers = ["FIFO", "RoundRobin", "StrictPriority", "BASIL_PSA", "BASIL_OPT"]
    reconciled_summary = {}

    for sc in scenarios:
        reconciled_summary[sc] = {}
        ap_power_mw = 60.0 if sc == "dense_viable_coverage" else 100.0
        opt_runs = [r for r in updated_runs if r["scenario"] == sc and r["scheduler"] == "BASIL_OPT"]
        opt_mean_goodput = float(np.mean([r["goodput_semantic_mbps"] for r in opt_runs])) if opt_runs else 1.0

        for sched in schedulers:
            sub = [r for r in updated_runs if r["scenario"] == sc and r["scheduler"] == sched]
            if not sub:
                continue
            sem_m = float(np.mean([r["goodput_semantic_mbps"] for r in sub]))
            sem_std = float(np.std([r["goodput_semantic_mbps"] for r in sub]))
            th_m = float(np.mean([r["throughput_mbps"] for r in sub]))
            lat_m = float(np.mean([r["avg_latency_ms"] for r in sub]))
            p95_m = float(np.mean([r["p95_latency_ms"] for r in sub]))
            sched_miss_m = float(np.mean([r["scheduling_deadline_misses"] for r in sub]))
            e2e_fail_m = float(np.mean([r["end_to_end_deadline_failures"] for r in sub]))
            opt_loss_m = float(np.mean([r["optical_channel_losses"] for r in sub]))
            sched_cov_m = float(np.mean([r["scheduling_coverage"] for r in sub]))
            exp_pdr_m = float(np.mean([r["expected_received_pdr"] for r in sub]))
            realized_pdr_m = float(np.mean([r["realized_received_pdr"] for r in sub]))
            jain_m = float(np.mean([r["jain_fairness_index"] for r in sub]))
            exec_m = float(np.mean([r["execution_time_s"] for r in sub]))

            rel_goodput_pct = round((sem_m / opt_mean_goodput) * 100.0, 2) if opt_mean_goodput > 0 else 100.0

            reconciled_summary[sc][sched] = {
                "semantic_goodput_mean_mbps": round(sem_m, 4),
                "semantic_goodput_std_mbps": round(sem_std, 4),
                "relative_semantic_goodput_vs_basil_opt_pct": rel_goodput_pct,
                "ratio_to_optimal_pct": rel_goodput_pct,  # backward compatibility alias
                "throughput_mean_mbps": round(th_m, 4),
                "avg_latency_mean_ms": round(lat_m, 2),
                "p95_latency_mean_ms": round(p95_m, 2),
                "scheduling_deadline_misses_mean": round(sched_miss_m, 2),
                "end_to_end_deadline_failures_mean": round(e2e_fail_m, 2),
                "optical_channel_losses_mean": round(opt_loss_m, 2),
                "scheduling_coverage_mean_pct": round(sched_cov_m * 100.0, 2),
                "expected_received_pdr_mean_pct": round(exp_pdr_m * 100.0, 2),
                "realized_received_pdr_mean_pct": round(realized_pdr_m * 100.0, 2),
                "scheduled_pdr_mean": round(sched_cov_m, 4),  # backward compatibility alias
                "expected_pdr_mean": round(exp_pdr_m, 4),  # backward compatibility alias
                "jain_fairness_mean": round(jain_m, 4),
                "execution_time_mean_s": round(exec_m, 4),
                "ap_power_unit": "mW",
                "ap_power_mw": ap_power_mw,
                "ap_power_w": round(ap_power_mw * 1e-3, 4),
            }

    reconciled_data = {
        "metadata": {
            "title": "BASIL Phase 3.4 Reconciled Cross-Algorithm Benchmark Dataset",
            "version": "3.4.0",
            "date": "2026-11-14",
            "parity_standard": "Phase 3.4 Final Research Reporting and Reproducibility Gate",
            "optical_power_unit": "mW (milliwatts)",
            "channel_replay_order_invariant": True,
            "prng_algorithm": "SplitMix64 64-bit keyed hash (seed, packet_id, device_id)",
            "metrics": {
                "scheduling_coverage": "Scheduled packets / generated packets (N_sched / N_gen * 100%)",
                "expected_received_pdr": "Analytical channel expectation (sum_{k in sched} (1 - PER_k)) / N_gen * 100%",
                "realized_received_pdr": "Empirical packets successfully received on channel / N_gen * 100%",
                "scheduling_deadline_misses": "Metric A: packets generated with deadline not fully transmitted by deadline",
                "end_to_end_deadline_failures": "Metric B: packets generated with deadline not successfully received on time",
                "optical_channel_losses": "Metric C: packets transmitted on-time but corrupted by optical channel PER",
                "relative_semantic_goodput_vs_basil_opt_pct": "Ratio of scheduler semantic goodput to BASIL-OPT semantic goodput (%)"
            },
            "total_runs": len(updated_runs),
        },
        "reconciled_summary": reconciled_summary,
        "runs": updated_runs,
    }

    with open(output_file, "w") as f:
        json.dump(reconciled_data, f, indent=2)

    print(f"Successfully generated Phase 3.4 reconciled dataset: {output_file} with {len(updated_runs)} runs.")

if __name__ == "__main__":
    reconcile_phase3_4()
