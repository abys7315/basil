import json
import math
from pathlib import Path
from typing import Dict, List, Any
import numpy as np
from scipy import stats

EXP_DIR = Path(__file__).resolve().parent

def run_audit():
    print("=== BASIL Phase 2.3 Research & Manifest Audit ===")
    
    # 1. Manifest Inspection
    manifest_path = EXP_DIR / "phase2_2_experiment_manifest.json"
    with open(manifest_path) as f:
        manifest = json.load(f)
        
    runs = manifest.get("runs", [])
    print(f"Manifest declared total_runs: {manifest.get('total_runs')}")
    print(f"Manifest declared successful_runs: {manifest.get('successful_runs')}")
    print(f"Manifest declared failed_runs: {manifest.get('failed_runs')}")
    print(f"Actual runs array length: {len(runs)}")
    
    # Check uniqueness of run_ids and scenario-scheduler-seed tuples
    run_ids = set()
    tuples = []
    group_counts = {}
    scenario_counts = {}
    scheduler_counts = {}
    seed_counts = {}
    config_hashes = set()
    failed_runs = []
    
    for r in runs:
        rid = r["run_id"]
        if rid in run_ids:
            print(f"DUPLICATE RUN ID DETECTED: {rid}")
        run_ids.add(rid)
        
        tup = (r.get("experiment_group"), r.get("scenario_id"), r.get("scheduler_id"), r.get("seed"))
        tuples.append(tup)
        
        grp = r.get("experiment_group", "unknown")
        group_counts[grp] = group_counts.get(grp, 0) + 1
        
        sc = r.get("scenario_id", "unknown")
        scenario_counts[sc] = scenario_counts.get(sc, 0) + 1
        
        sched = r.get("scheduler_id", "unknown")
        scheduler_counts[sched] = scheduler_counts.get(sched, 0) + 1
        
        s = r.get("seed", -1)
        seed_counts[s] = seed_counts.get(s, 0) + 1
        
        ch = r.get("config_hash")
        if ch:
            config_hashes.add(ch)
            
        if r.get("status") != "SUCCESS":
            failed_runs.append(r)
            
    print(f"\nUnique Run IDs: {len(run_ids)} / {len(runs)}")
    print(f"Unique (Group, Scenario, Scheduler, Seed) tuples: {len(set(tuples))} / {len(runs)}")
    print(f"Failed runs: {len(failed_runs)}")
    print(f"Unique config hashes: {len(config_hashes)}")
    print("\nBreakdown by Experiment Group:")
    for grp, cnt in sorted(group_counts.items()):
        print(f"  - {grp:<25}: {cnt} runs")
        
    # 2. Raw JSON Files Reconciliation
    raw_files = {
        "core_evaluation": EXP_DIR / "phase2_2_evaluation_results.json",
        "predictor_comparison": EXP_DIR / "phase2_2_predictor_results.json",
        "controlled_semantic": EXP_DIR / "phase2_2_controlled_results.json",
        "weight_sensitivity": EXP_DIR / "phase2_2_weights_results.json",
        "ablation_study": EXP_DIR / "phase2_2_ablation_results.json",
    }
    
    raw_counts = {}
    conservation_violations = []
    independent_jain_diffs = []
    
    # Audit Core Evaluation
    with open(raw_files["core_evaluation"]) as f:
        core_data = json.load(f)
    core_raw = core_data.get("raw", {})
    core_count = sum(len(seeds) for sc in core_raw.values() for seeds in sc.values())
    raw_counts["core_evaluation"] = core_count
    
    # Check 5-way conservation in all core runs
    for sc_name, scheds in core_raw.items():
        for sched_name, seed_runs in scheds.items():
            for run_obj in seed_runs:
                gen = run_obj.get("total_packets_generated", 0)
                ontime = run_obj.get("delivered_on_time", 0)
                late = run_obj.get("delivered_late", 0)
                lost = run_obj.get("lost_channel", 0)
                drop = run_obj.get("dropped_queue", 0)
                pend = run_obj.get("pending_queue", 0)
                sum_parts = ontime + late + lost + drop + pend
                if gen != sum_parts:
                    conservation_violations.append({
                        "file": "core_evaluation", "scenario": sc_name, "scheduler": sched_name,
                        "seed": run_obj.get("seed"), "gen": gen, "sum_parts": sum_parts
                    })
                # Check independent Jain's fairness index
                devs = run_obj.get("per_device_stats", [])
                if devs:
                    throughputs = [d.get("throughput_mbps", 0.0) for d in devs]
                    n_dev = len(throughputs)
                    sum_x = sum(throughputs)
                    sum_sq = sum(x*x for x in throughputs)
                    if sum_sq > 0:
                        calc_jain = (sum_x * sum_x) / (n_dev * sum_sq)
                    else:
                        calc_jain = 0.0
                    rep_jain = run_obj.get("jain_fairness_index", 0.0)
                    if abs(calc_jain - rep_jain) > 1e-3:
                        independent_jain_diffs.append({
                            "scenario": sc_name, "scheduler": sched_name, "seed": run_obj.get("seed"),
                            "reported": rep_jain, "calculated": calc_jain
                        })
                        
    # Audit Predictor
    with open(raw_files["predictor_comparison"]) as f:
        pred_data = json.load(f)
    pred_raw = pred_data.get("raw", {})
    pred_count = sum(len(seeds) for seeds in pred_raw.values())
    raw_counts["predictor_comparison"] = pred_count
    
    # Audit Controlled
    with open(raw_files["controlled_semantic"]) as f:
        ctrl_data = json.load(f)
    ctrl_raw = ctrl_data.get("raw", {})
    ctrl_count = sum(len(seeds) for sc in ctrl_raw.values() for seeds in sc.values())
    raw_counts["controlled_semantic"] = ctrl_count
    
    # Audit Weights
    with open(raw_files["weight_sensitivity"]) as f:
        w_data = json.load(f)
    w_raw = w_data.get("raw", {})
    w_count = sum(len(seeds) for seeds in w_raw.values())
    raw_counts["weight_sensitivity"] = w_count
    
    # Audit Ablations
    with open(raw_files["ablation_study"]) as f:
        abl_data = json.load(f)
    abl_raw = abl_data.get("raw", {})
    abl_count = sum(len(seeds) for sc in abl_raw.values() for seeds in sc.values())
    raw_counts["ablation_study"] = abl_count
    
    total_raw_runs = sum(raw_counts.values())
    print("\nRaw JSON Runs Reconciled:")
    for k, v in raw_counts.items():
        print(f"  - {k:<25}: {v} runs in raw file (Manifest: {group_counts.get(k, 0)})")
    print(f"Total Raw Runs: {total_raw_runs} (Matches Manifest 670: {total_raw_runs == 670})")
    print(f"Conservation law violations: {len(conservation_violations)}")
    print(f"Independent Jain index discrepancies (>1e-3): {len(independent_jain_diffs)}")
    
    # 3. Statistical Recalculation for Strongest Baselines
    print("\n=== Statistical Recalculation (Paired Student's t-test & Wilcoxon) ===")
    stats_audit = {}
    
    for sc_name, scheds in core_raw.items():
        stats_audit[sc_name] = {}
        basil_runs = scheds["BASIL_PSA"]
        
        # Determine strongest baseline for latency, semantic goodput, pdr, deadline misses
        metrics_to_test = ["avg_latency_ms", "goodput_semantic_mbps", "pdr", "total_deadline_misses", "jain_fairness_index"]
        
        # Find best baseline for each metric
        baselines = ["FIFO", "RoundRobin", "StrictPriority"]
        for m in metrics_to_test:
            if m in ["avg_latency_ms", "total_deadline_misses"]:
                # lower is better
                best_base = min(baselines, key=lambda b: np.mean([r.get(m, 0.0) for r in scheds[b]]))
            else:
                # higher is better
                best_base = max(baselines, key=lambda b: np.mean([r.get(m, 0.0) for r in scheds[b]]))
                
            basil_vals = [r.get(m, 0.0) for r in basil_runs]
            base_vals = [r.get(m, 0.0) for r in scheds[best_base]]
            
            diffs = np.array(basil_vals) - np.array(base_vals)
            n = len(diffs)
            mean_diff = float(np.mean(diffs))
            std_diff = float(np.std(diffs, ddof=1)) if n > 1 else 0.0
            sem_diff = std_diff / math.sqrt(n) if n > 0 else 0.0
            t_crit = stats.t.ppf(0.975, df=n-1)
            ci95 = float(t_crit * sem_diff)
            
            # Paired t-test
            if std_diff > 1e-12:
                t_stat, p_val = stats.ttest_rel(basil_vals, base_vals)
                # Wilcoxon signed rank test
                try:
                    w_res = stats.wilcoxon(basil_vals, base_vals)
                    w_pval = float(w_res.pvalue)
                except Exception:
                    w_pval = 1.0
            else:
                t_stat, p_val = 0.0, 1.0
                w_pval = 1.0
                
            stats_audit[sc_name][m] = {
                "metric": m,
                "strongest_baseline": best_base,
                "basil_mean": float(np.mean(basil_vals)),
                "baseline_mean": float(np.mean(base_vals)),
                "mean_paired_diff": mean_diff,
                "std_paired_diff": std_diff,
                "ci95": ci95,
                "t_statistic": float(t_stat),
                "p_value_parametric": float(p_val),
                "p_value_wilcoxon": float(w_pval),
                "n_seeds": n,
                "statistically_significant_005": bool(p_val < 0.05),
                "practically_meaningful": bool(abs(mean_diff) > 0.01 and p_val < 0.05)
            }
            
            sig_marker = "***" if p_val < 0.001 else ("**" if p_val < 0.01 else ("*" if p_val < 0.05 else "n.s."))
            print(f"[{sc_name:<25}] {m:<23} vs {best_base:<15} diff={mean_diff:+.4f} +/- {ci95:.4f} (p={p_val:.4e}, {sig_marker})")

    # Output manifest audit and statistical results
    manifest_audit_out = EXP_DIR / "phase2_3_manifest_audit.json"
    with open(manifest_audit_out, "w") as f:
        json.dump({
            "total_runs": len(runs),
            "unique_run_ids": len(run_ids),
            "unique_tuples": len(set(tuples)),
            "failed_runs_count": len(failed_runs),
            "group_breakdown": group_counts,
            "scenario_breakdown": scenario_counts,
            "scheduler_breakdown": scheduler_counts,
            "seed_breakdown": seed_counts,
            "conservation_violations": len(conservation_violations),
            "independent_jain_diffs": len(independent_jain_diffs)
        }, f, indent=2)
        
    stats_out = EXP_DIR / "phase2_3_statistical_results.json"
    with open(stats_out, "w") as f:
        json.dump(stats_audit, f, indent=2)
        
    print(f"\nSaved audit records to {manifest_audit_out} and {stats_out}")

if __name__ == "__main__":
    run_audit()
