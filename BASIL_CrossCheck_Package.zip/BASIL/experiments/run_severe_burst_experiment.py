import asyncio
import json
import math
import sys
from pathlib import Path
from typing import Dict, List, Any
import numpy as np
from scipy import stats

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "backend"))
from app.simulation.runner import SimulationRunner

SEEDS = [42, 101, 2024, 777, 9999, 12345, 54321, 98765, 11111, 22222]

CONFIGURATIONS = {
    "CUSUM": {"scheduler": "BASIL_PSA", "predictor_type": "cusum"},
    "Count_EWMA": {"scheduler": "BASIL_PSA", "predictor_type": "ewma", "ewma_alpha": 0.25},
    "Persistence": {"scheduler": "BASIL_PSA", "predictor_type": "persistence"},
    "Static": {"scheduler": "BASIL_PSA", "predictor_type": "static"},
    "No_Prediction": {"scheduler": "BASIL_PSA", "ablation_no_prediction": 1.0},
}

BASE_SCENARIO = {
    "num_devices": 4,
    "simulation_time": 2.0,
    "data_rate": 10.0,
    "traffic_mode": "burst",
    "normal_rate": 150.0,
    "burst_rate": 800.0,
    "burst_ratio": 0.50,
    "ap_power": 100.0,
    "coverage_mode": "viable",
}

def calc_stats(values: List[float]) -> Dict[str, float]:
    n = len(values)
    if n == 0:
        return {"mean": 0.0, "std": 0.0, "ci95": 0.0}
    mean = float(np.mean(values))
    std = float(np.std(values, ddof=1)) if n > 1 else 0.0
    t_val = stats.t.ppf(0.975, df=n-1) if n > 1 else 1.96
    ci95 = float(t_val * (std / math.sqrt(n))) if n > 1 else 0.0
    return {"mean": round(mean, 4), "std": round(std, 4), "ci95": round(ci95, 4)}

async def main():
    runner = SimulationRunner()
    raw_results = {}
    summary_results = {}

    print("=== Running Controlled Severe-Burst Overload Experiment (5 Configs x 10 Seeds) ===")

    for name, p_cfg in CONFIGURATIONS.items():
        raw_results[name] = []
        metrics = {
            "burst_prediction_mae": [],
            "burst_prediction_rmse": [],
            "dropped_queue": [],
            "total_deadline_misses": [],
            "goodput_semantic_mbps": [],
            "avg_latency_ms": [],
            "p95_latency_ms": [],
            "pdr": [],
        }

        for seed in SEEDS:
            cfg = dict(BASE_SCENARIO)
            cfg.update(p_cfg)
            cfg["seed"] = seed

            res = await runner.run(cfg, engine="ns3")
            raw_results[name].append(res)
            for k in metrics.keys():
                metrics[k].append(res.get(k, 0.0))

        summary_results[name] = {k: calc_stats(v) for k, v in metrics.items()}
        s = summary_results[name]
        print(f"  {name:<15} MAE={s['burst_prediction_mae']['mean']:.2f} | RMSE={s['burst_prediction_rmse']['mean']:.2f} | Latency={s['avg_latency_ms']['mean']:.2f}ms | p95={s['p95_latency_ms']['mean']:.2f} | Missed={s['total_deadline_misses']['mean']:.1f} | Drops={s['dropped_queue']['mean']:.1f} | SemGoodput={s['goodput_semantic_mbps']['mean']:.3f} Mbps")

    # Paired comparisons against No_Prediction baseline
    paired_diffs = {}
    no_pred_metrics = {k: [r.get(k, 0.0) for r in raw_results["No_Prediction"]] for k in ["avg_latency_ms", "p95_latency_ms", "total_deadline_misses", "dropped_queue", "goodput_semantic_mbps", "pdr"]}

    for name in ["CUSUM", "Count_EWMA", "Persistence", "Static"]:
        paired_diffs[f"{name}_vs_No_Prediction"] = {}
        for k, base_vals in no_pred_metrics.items():
            pred_vals = [r.get(k, 0.0) for r in raw_results[name]]
            diffs = np.array(pred_vals) - np.array(base_vals)
            t_stat, p_val = stats.ttest_rel(pred_vals, base_vals) if np.std(diffs) > 1e-12 else (0.0, 1.0)
            paired_diffs[f"{name}_vs_No_Prediction"][k] = {
                "mean_diff": float(np.mean(diffs)),
                "std_diff": float(np.std(diffs, ddof=1)),
                "p_value": float(p_val),
            }

    out_file = Path(__file__).resolve().parent / "phase2_3_severe_burst_results.json"
    with open(out_file, "w") as f:
        json.dump({
            "summary": summary_results,
            "paired_diff_vs_no_prediction": paired_diffs,
            "raw": raw_results
        }, f, indent=2)

    print(f"\nSaved severe burst overload results to {out_file}")

if __name__ == "__main__":
    asyncio.run(main())
