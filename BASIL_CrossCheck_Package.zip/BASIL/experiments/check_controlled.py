import json
from pathlib import Path

data = json.load(open(Path(__file__).parent / "phase2_2_controlled_results.json"))["summary"]
for sc_name, scheds in data.items():
    print(f"\n==========================================")
    print(f"Scenario: {sc_name}")
    print(f"==========================================")
    for sched in ["FIFO", "RoundRobin", "StrictPriority", "BASIL_PSA"]:
        s = scheds[sched]["overall"]
        print(f"\n--- Scheduler: {sched} ---")
        print(f"  Overall: SemGoodput={s['goodput_semantic_mbps']['mean']:.4f} Mbps, Latency={s['avg_latency_ms']['mean']:.2f} ms, Misses={s['total_deadline_misses']['mean']:.1f}, DSR={s['deadline_success_rate']['mean']*100:.2f}%")
        pc = scheds[sched]["per_class"]
        for c_id in sorted(pc.keys(), key=lambda x: int(x)):
            cs = pc[c_id]
            print(f"    Class {c_id}: OnTime={cs['delivered_on_time']['mean']:.1f}, Late={cs['delivered_late']['mean']:.1f}, Missed={cs['deadline_misses']['mean']:.1f}, Latency={cs['latency_ms']['mean']:.2f} ms")
