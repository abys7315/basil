import tempfile, json, subprocess, os, time, sys

schedulers = ['FIFO', 'RoundRobin', 'StrictPriority', 'BASIL_PSA']
scenarios = {
    'normal_traffic': {
        'num_devices': 4,
        'simulation_time': 2.0,
        'data_rate': 20.0,
        'traffic_mode': 'normal',
        'burst_ratio': 0.0,
        'room_width': 5.0,
        'room_height': 3.0,
        'ap_power': 100.0,
        'half_angle': 60.0,
        'packet_size': 1024,
        'normal_rate': 100.0,
        'burst_rate': 100.0,
    },
    'sudden_bursts': {
        'num_devices': 4,
        'simulation_time': 2.0,
        'data_rate': 15.0,
        'traffic_mode': 'burst',
        'burst_ratio': 0.4,
        'room_width': 5.0,
        'room_height': 3.0,
        'ap_power': 100.0,
        'half_angle': 60.0,
        'packet_size': 1024,
        'normal_rate': 80.0,
        'burst_rate': 450.0,
    },
    'high_device_density': {
        'num_devices': 8,
        'simulation_time': 2.0,
        'data_rate': 25.0,
        'traffic_mode': 'burst',
        'burst_ratio': 0.25,
        'room_width': 6.0,
        'room_height': 3.0,
        'ap_power': 120.0,
        'half_angle': 60.0,
        'packet_size': 1024,
        'normal_rate': 60.0,
        'burst_rate': 300.0,
    },
    'degraded_optical_channel': {
        'num_devices': 4,
        'simulation_time': 2.0,
        'data_rate': 15.0,
        'traffic_mode': 'normal',
        'burst_ratio': 0.0,
        'room_width': 5.0,
        'room_height': 3.0,
        'ap_power': 30.0, # low optical power -> degraded SNR / higher PER
        'half_angle': 60.0,
        'packet_size': 1024,
        'normal_rate': 80.0,
        'burst_rate': 80.0,
    }
}

print('Scenario evaluation starting...')
all_results = {}

for sc_name, base_cfg in scenarios.items():
    all_results[sc_name] = {}
    print(f'=== Scenario: {sc_name} ===')
    for sched in schedulers:
        cfg = dict(base_cfg)
        cfg['scheduler'] = sched
        with tempfile.NamedTemporaryFile('w', suffix='.json', delete=False) as f:
            json.dump(cfg, f)
            cfg_path = f.name
        
        wsl_path = '/mnt/c' + cfg_path.replace('\\', '/').replace('C:', '')
        cmd = ['wsl', '-d', 'Ubuntu', '--', 'bash', '-c', f'LD_LIBRARY_PATH=/opt/ns3/ns-allinone-3.42/ns-3.42/build/lib /opt/ns3/ns-allinone-3.42/ns-3.42/build/scratch/ns3.42-basil-ns3-sim {wsl_path}']
        
        t0 = time.time()
        res = subprocess.run(cmd, capture_output=True, text=True)
        t_elapsed = time.time() - t0
        try:
            os.unlink(cfg_path)
        except OSError:
            pass
        
        if res.returncode != 0:
            print(f'  {sched}: ERROR {res.stderr[:200]}')
            continue
            
        data = json.loads(res.stdout)
        data['wall_runtime_s'] = t_elapsed
        all_results[sc_name][sched] = data
        pdr = data['pdr']
        lat = data['avg_latency_ms']
        tput = data['throughput_mbps']
        fairness = data['fairness_index']
        d_misses = data.get('deadline_misses', 0)
        print(f'  {sched:<15s} | PDR={pdr:.4f} | Latency={lat:7.3f}ms | Tput={tput:6.2f}Mbps | Fairness={fairness:.4f} | DeadlinesMiss={d_misses} | WallTime={t_elapsed:.2f}s')

out_file = r'c:\Users\abys7\Downloads\BASIL-starter\BASIL\experiments\validation_scenario_runs.json'
with open(out_file, 'w') as out_f:
    json.dump(all_results, out_f, indent=2)
print('Results written to', out_file)
