import asyncio
import json
import math
import os
import sys
from pathlib import Path
from typing import Dict, List, Any

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "backend"))
from app.simulation.runner import SimulationRunner

# 10 random seeds for high statistical confidence
SEEDS = [42, 101, 2024, 777, 9999, 12345, 54321, 98765, 11111, 22222]
SCHEDULERS = ["FIFO", "RoundRobin", "StrictPriority", "BASIL_PSA"]

SCENARIOS = {
    "normal_traffic": {
        "description": "Uniform baseline traffic across 4 devices",
        "num_devices": 4,
        "simulation_time": 2.0,
        "data_rate": 10.0,
        "traffic_mode": "normal",
        "normal_rate": 100.0,
        "burst_rate": 100.0,
        "burst_ratio": 0.0,
        "ap_power": 100.0,
    },
    "sudden_bursts": {
        "description": "Periodic traffic bursts across 4 devices",
        "num_devices": 4,
        "simulation_time": 2.0,
        "data_rate": 10.0,
        "traffic_mode": "burst",
        "normal_rate": 80.0,
        "burst_rate": 400.0,
        "burst_ratio": 0.30,
        "ap_power": 100.0,
    },
    "high_device_density": {
        "description": "16 concurrent devices testing scale, channel diversity, and queue buildup",
        "num_devices": 16,
        "simulation_time": 2.0,
        "data_rate": 10.0,
        "traffic_mode": "burst",
        "normal_rate": 30.0,
        "burst_rate": 120.0,
        "burst_ratio": 0.25,
        "ap_power": 100.0,
    },
    "mixed_semantic_traffic": {
        "description": "Heterogeneous traffic classes with 4 priority tiers and varied deadlines",
        "num_devices": 4,
        "simulation_time": 2.0,
        "data_rate": 10.0,
        "traffic_mode": "burst",
        "normal_rate": 80.0,
        "burst_rate": 350.0,
        "burst_ratio": 0.35,
        "ap_power": 100.0,
    },
    "degraded_optical_channel": {
        "description": "Severe optical path attenuation (P_t = 25 mW) causing high PER on distant nodes",
        "num_devices": 4,
        "simulation_time": 2.0,
        "data_rate": 10.0,
        "traffic_mode": "burst",
        "normal_rate": 80.0,
        "burst_rate": 350.0,
        "burst_ratio": 0.30,
        "ap_power": 25.0,
    },
    "sustained_emergency_traffic": {
        "description": "Continuous high-priority emergency stream on Device 0 to assess best-effort starvation",
        "num_devices": 4,
        "simulation_time": 2.0,
        "data_rate": 10.0,
        "traffic_mode": "burst",
        "normal_rate": 120.0,
        "burst_rate": 500.0,
        "burst_ratio": 0.50,
        "ap_power": 100.0,
    },
    "semantic_vs_urgency_controlled": {
        "description": "Decoupled controlled experiment: low-semantic/tight-deadline vs high-semantic/loose-deadline",
        "num_devices": 4,
        "simulation_time": 2.0,
        "data_rate": 10.0,
        "traffic_mode": "semantic_decoupled",
        "normal_rate": 80.0,
        "burst_rate": 350.0,
        "burst_ratio": 0.35,
        "ap_power": 100.0,
    },
}

ABLATIONS = {
    "BASIL_PSA (Full Model)": {},
    "No Burst Prediction": {"ablation_no_prediction": 1.0},
    "No Semantic Importance": {"ablation_no_semantic": 1.0},
    "No Channel Awareness": {"ablation_no_channel": 1.0},
    "No Fairness Adjustment": {"ablation_no_fairness": 1.0},
}

# Student's t critical value for 95% CI (two-tailed)
T_CRIT_95 = {
    5: 2.776,
    9: 2.262, # N=10, df=9
    10: 2.228,
}

def calc_stats(values: List[float], df: int = 9) -> Dict[str, float]:
    n = len(values)
    if n == 0:
        return {"mean": 0.0, "std": 0.0, "ci95": 0.0, "min": 0.0, "max": 0.0}
    mean = sum(values) / n
    if n > 1:
        var = sum((x - mean) ** 2 for x in values) / (n - 1)
        std = math.sqrt(var)
        t_val = T_CRIT_95.get(n - 1, 1.96)
        ci95 = t_val * (std / math.sqrt(n))
    else:
        std = 0.0
        ci95 = 0.0
    return {
        "mean": round(mean, 4),
        "std": round(std, 4),
        "ci95": round(ci95, 4),
        "min": round(min(values), 4),
        "max": round(max(values), 4),
    }

def calc_paired_difference(a_vals: List[float], b_vals: List[float]) -> Dict[str, float]:
    diffs = [a - b for a, b in zip(a_vals, b_vals)]
    return calc_stats(diffs, df=len(diffs)-1)

async def main():
    runner = SimulationRunner()
    raw_eval = {}
    summary_eval = {}
    paired_comparisons = {}

    print(f"=== Running BASIL Phase 2.1 Benchmarks ({len(SCENARIOS)} scenarios x {len(SCHEDULERS)} schedulers x {len(SEEDS)} seeds) ===")

    for sc_name, sc_cfg in SCENARIOS.items():
        print(f"\n>> Scenario: {sc_name} ({sc_cfg['description']})")
        raw_eval[sc_name] = {}
        summary_eval[sc_name] = {}
        paired_comparisons[sc_name] = {}

        metrics_per_sched = {}

        for sched in SCHEDULERS:
            raw_eval[sc_name][sched] = []
            m = {
                "total_generated": [],
                "delivered_on_time": [],
                "delivered_late": [],
                "lost_channel": [],
                "dropped_queue": [],
                "pending_queue": [],
                "pdr": [],
                "channel_pdr": [],
                "avg_latency_ms": [],
                "p95_latency_ms": [],
                "p99_latency_ms": [],
                "throughput_mbps": [],
                "goodput_raw_mbps": [],
                "goodput_semantic_mbps": [],
                "total_deadline_misses": [],
                "deadline_success_rate": [],
                "jain_fairness_index": [],
                "burst_prediction_mae": [],
                "burst_prediction_rmse": [],
                "persistence_baseline_mae": [],
                "static_baseline_mae": [],
            }

            for seed in SEEDS:
                cfg = dict(sc_cfg)
                cfg["scheduler"] = sched
                cfg["seed"] = seed

                res = await runner.run(cfg, engine="ns3")
                raw_eval[sc_name][sched].append(res)

                # Collect metrics
                for key in m.keys():
                    m[key].append(res.get(key, 0.0))

            metrics_per_sched[sched] = m
            summary_eval[sc_name][sched] = {k: calc_stats(v) for k, v in m.items()}
            s = summary_eval[sc_name][sched]
            print(f"  {sched:<15} Latency={s['avg_latency_ms']['mean']}ms | p95={s['p95_latency_ms']['mean']} | OnTime={s['delivered_on_time']['mean']} | Late={s['delivered_late']['mean']} | Missed={s['total_deadline_misses']['mean']} | PDR={s['pdr']['mean']} | SemGoodput={s['goodput_semantic_mbps']['mean']} Mbps")

        # Compute paired per-seed differences: BASIL_PSA vs FIFO, RoundRobin, StrictPriority
        basil_m = metrics_per_sched["BASIL_PSA"]
        for base in ["FIFO", "RoundRobin", "StrictPriority"]:
            paired_comparisons[sc_name][f"BASIL_vs_{base}"] = {}
            for key in ["avg_latency_ms", "p95_latency_ms", "goodput_semantic_mbps", "total_deadline_misses", "pdr", "jain_fairness_index"]:
                paired_comparisons[sc_name][f"BASIL_vs_{base}"][key] = calc_paired_difference(basil_m[key], metrics_per_sched[base][key])

    eval_out = Path(__file__).resolve().parent / "phase2_1_evaluation_results.json"
    with open(eval_out, "w") as f:
        json.dump({"summary": summary_eval, "paired_diff": paired_comparisons, "raw": raw_eval}, f, indent=2)
    print(f"\nSaved evaluation results to {eval_out}")

    # Ablation Evaluation under mixed_semantic_traffic
    print("\n=== Running Phase 2.1 Ablation Study (mixed_semantic_traffic x 10 seeds) ===")
    ablation_raw = {}
    ablation_summary = {}
    base_cfg = SCENARIOS["mixed_semantic_traffic"]

    for ab_name, ab_flags in ABLATIONS.items():
        ablation_raw[ab_name] = []
        m = {
            "avg_latency_ms": [],
            "p95_latency_ms": [],
            "p99_latency_ms": [],
            "throughput_mbps": [],
            "goodput_semantic_mbps": [],
            "pdr": [],
            "total_deadline_misses": [],
            "deadline_success_rate": [],
            "jain_fairness_index": [],
            "burst_prediction_mae": [],
        }

        for seed in SEEDS:
            cfg = dict(base_cfg)
            cfg["scheduler"] = "BASIL_PSA"
            cfg["seed"] = seed
            cfg.update(ab_flags)

            res = await runner.run(cfg, engine="ns3")
            ablation_raw[ab_name].append(res)

            for key in m.keys():
                m[key].append(res.get(key, 0.0))

        ablation_summary[ab_name] = {k: calc_stats(v) for k, v in m.items()}
        s = ablation_summary[ab_name]
        print(f"  {ab_name:<25} Latency={s['avg_latency_ms']['mean']}ms | p95={s['p95_latency_ms']['mean']} | SemGoodput={s['goodput_semantic_mbps']['mean']} Mbps | Missed={s['total_deadline_misses']['mean']} | PDR={s['pdr']['mean']}")

    abl_out = Path(__file__).resolve().parent / "phase2_1_ablation_results.json"
    with open(abl_out, "w") as f:
        json.dump({"summary": ablation_summary, "raw": ablation_raw}, f, indent=2)
    print(f"\nSaved ablation results to {abl_out}")

if __name__ == "__main__":
    asyncio.run(main())
