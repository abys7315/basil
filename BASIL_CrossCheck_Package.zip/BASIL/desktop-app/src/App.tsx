import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';
import NetworkConfigPage from './pages/NetworkConfig';
import TrafficConfigPage from './pages/TrafficConfig';
import AlgorithmLab from './pages/AlgorithmLab';
import Results from './pages/Results';

export default function App() {
  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/network" element={<NetworkConfigPage />} />
          <Route path="/traffic" element={<TrafficConfigPage />} />
          <Route path="/algorithm-lab" element={<AlgorithmLab />} />
          <Route path="/results" element={<Results />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Layout>
    </Router>
  );
}
