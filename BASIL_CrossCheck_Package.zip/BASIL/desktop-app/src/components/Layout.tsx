import React, { useState, useEffect } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import {
  LayoutDashboard,
  Network,
  Activity,
  FlaskConical,
  BarChart3,
  Zap,
  Server,
  Layers,
  Terminal,
  ExternalLink,
  ShieldCheck,
  RefreshCw,
} from 'lucide-react';
import clsx from 'clsx';
import { checkHealth } from '../api/client';

const navItems = [
  { to: '/', label: 'Overview', sub: 'System Dashboard', icon: LayoutDashboard, end: true },
  { to: '/network', label: 'Network Designer', sub: '3D Optical Cell & APs', icon: Network },
  { to: '/traffic', label: 'Traffic Generator', sub: 'Poisson & Bursty Flows', icon: Activity },
  { to: '/algorithm-lab', label: 'Simulation Lab', sub: 'Execute & Benchmark', icon: FlaskConical },
  { to: '/results', label: 'Analytics & Telemetry', sub: 'Comparative Studies', icon: BarChart3 },
];

interface LayoutProps {
  children: React.ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const [backendOnline, setBackendOnline] = useState<boolean | null>(null);
  const [probing, setProbing] = useState<boolean>(false);
  const location = useLocation();

  const probe = async () => {
    setProbing(true);
    try {
      await checkHealth();
      setBackendOnline(true);
    } catch {
      setBackendOnline(false);
    } finally {
      setTimeout(() => setProbing(false), 300);
    }
  };

  useEffect(() => {
    probe();
    const interval = setInterval(probe, 10000);
    return () => clearInterval(interval);
  }, []);

  const currentNav = navItems.find(item => item.end ? location.pathname === item.to : location.pathname.startsWith(item.to)) || navItems[0];

  return (
    <div className="flex min-h-screen bg-[#07090e] text-slate-100 selection:bg-cyan-500/30 selection:text-cyan-200">
      {/* Sidebar */}
      <aside className="w-64 flex-shrink-0 flex flex-col border-r border-white/[0.06] bg-[#0c0e15]/90 backdrop-blur-xl relative z-20">
        {/* Brand Header */}
        <div className="px-5 py-5 border-b border-white/[0.06] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="relative flex items-center justify-center w-9 h-9 rounded-xl bg-gradient-to-br from-cyan-500 to-indigo-600 shadow-lg shadow-cyan-500/20 border border-cyan-400/30">
              <Zap className="text-white w-5 h-5 fill-white" />
              <div className="absolute inset-0 rounded-xl bg-cyan-400/20 blur-sm pointer-events-none" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-base tracking-wider bg-gradient-to-r from-white via-slate-200 to-slate-400 bg-clip-text text-transparent">
                  BASIL
                </span>
                <span className="text-[10px] font-bold uppercase tracking-widest px-1.5 py-0.5 rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                  v4.1.0
                </span>
              </div>
              <p className="text-[10px] text-slate-400 font-medium tracking-tight">Optical Li-Fi Simulator</p>
            </div>
          </div>
        </div>

        {/* Navigation Section */}
        <div className="px-3 py-4">
          <div className="px-3 pb-2 text-[10px] font-bold uppercase tracking-wider text-slate-400">
            Navigation
          </div>
          <nav className="space-y-1">
            {navItems.map(({ to, label, sub, icon: Icon, end }) => (
              <NavLink
                key={to}
                to={to}
                end={end}
                className={({ isActive }) =>
                  clsx(
                    'group relative flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold transition-all duration-200',
                    isActive
                      ? 'bg-gradient-to-r from-cyan-500/15 to-indigo-500/10 text-white border border-cyan-500/30 shadow-md shadow-cyan-500/5'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-white/[0.04] border border-transparent'
                  )
                }
              >
                {({ isActive }) => (
                  <>
                    <div
                      className={clsx(
                        'w-7 h-7 rounded-lg flex items-center justify-center transition-colors',
                        isActive
                          ? 'bg-cyan-500/20 text-cyan-300'
                          : 'bg-white/[0.03] text-slate-400 group-hover:text-slate-200 group-hover:bg-white/[0.06]'
                      )}
                    >
                      <Icon className="w-4 h-4" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="truncate">{label}</div>
                      <div className="text-[10px] font-normal text-slate-400 truncate">{sub}</div>
                    </div>
                    {isActive && (
                      <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 shadow-[0_0_8px_#38bdf8]" />
                    )}
                  </>
                )}
              </NavLink>
            ))}
          </nav>
        </div>

        {/* Engine Specs Badge */}
        <div className="mx-3 my-2 p-3 rounded-xl bg-gradient-to-b from-white/[0.04] to-transparent border border-white/[0.05] space-y-2">
          <div className="flex items-center justify-between text-[11px] font-semibold text-slate-300">
            <span className="flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5 text-cyan-400" /> Hybrid Engine
            </span>
            <span className="text-[10px] px-1.5 py-0.5 rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 font-mono">
              ns-3.42
            </span>
          </div>
          <div className="text-[10px] text-slate-400 leading-tight">
            Physical Lambertian optics with HiGHS-1.16 offline MILP oracle.
          </div>
        </div>

        {/* System Telemetry Footer */}
        <div className="mt-auto p-3 border-t border-white/[0.06] bg-black/20">
          <div className="px-3 py-2.5 rounded-xl bg-white/[0.02] border border-white/[0.04] space-y-2 text-[11px]">
            <div className="flex items-center justify-between">
              <span className="text-slate-400 flex items-center gap-1.5 font-medium">
                <Server className="w-3.5 h-3.5 text-slate-500" /> Fast-API
              </span>
              <span className="flex items-center gap-1.5 font-mono text-[10px]">
                <span
                  className={clsx(
                    'w-2 h-2 rounded-full',
                    backendOnline === true ? 'bg-emerald-400 animate-beacon' : backendOnline === false ? 'bg-rose-500' : 'bg-amber-400'
                  )}
                />
                <span className={backendOnline === true ? 'text-emerald-400 font-semibold' : 'text-rose-400'}>
                  {backendOnline === true ? '127.0.0.1:8000' : 'Offline'}
                </span>
              </span>
            </div>

            <div className="flex items-center justify-between pt-1 border-t border-white/[0.04] text-[10px] text-slate-400">
              <span className="flex items-center gap-1">
                <ShieldCheck className="w-3 h-3 text-cyan-400" /> Research Mode
              </span>
              <button
                onClick={probe}
                title="Refresh system status"
                className="hover:text-cyan-400 transition-colors flex items-center gap-1"
              >
                <RefreshCw className={clsx('w-2.5 h-2.5', probing && 'animate-spin text-cyan-400')} />
                <span>Sync</span>
              </button>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 bg-grid-pattern relative">
        {/* Ambient Top Glow */}
        <div className="absolute top-0 left-0 right-0 h-64 bg-radial-glow pointer-events-none" />

        {/* Global Top Header */}
        <header className="h-14 border-b border-white/[0.06] px-8 flex items-center justify-between bg-[#07090e]/80 backdrop-blur-md sticky top-0 z-10">
          <div className="flex items-center gap-3">
            <span className="text-xs font-semibold text-slate-400">BASIL Simulation Platform</span>
            <span className="text-slate-600">/</span>
            <span className="text-xs font-bold text-white">{currentNav.label}</span>
          </div>

          <div className="flex items-center gap-3">
            <a
              href="http://localhost:8000/docs"
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-white/[0.04] hover:bg-white/[0.08] text-slate-300 hover:text-white border border-white/[0.06] transition-colors"
            >
              <Terminal className="w-3.5 h-3.5 text-cyan-400" />
              <span>Swagger API</span>
              <ExternalLink className="w-2.5 h-2.5 text-slate-500" />
            </a>

            <div className="flex items-center gap-2 pl-3 border-l border-white/[0.08] text-[11px] font-mono text-slate-400">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
              <span>Engine: Hybrid ns-3</span>
            </div>
          </div>
        </header>

        {/* Page Content Viewport */}
        <main className="flex-1 p-8 max-w-7xl w-full mx-auto relative z-0">
          {children}
        </main>
      </div>
    </div>
  );
}
