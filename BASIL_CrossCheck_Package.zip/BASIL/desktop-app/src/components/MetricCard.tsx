import React from 'react';
import clsx from 'clsx';

interface MetricCardProps {
  title: string;
  value: string | number;
  unit?: string;
  icon?: React.ReactNode;
  change?: number; // positive = up, negative = down
  className?: string;
}

export default function MetricCard({ title, value, unit, icon, change, className }: MetricCardProps) {
  return (
    <div className={clsx('bg-gray-900 border border-gray-800 rounded-xl p-5', className)}>
      <div className="flex items-center justify-between mb-3">
        <span className="text-sm text-gray-400">{title}</span>
        {icon && <span className="text-blue-400">{icon}</span>}
      </div>
      <div className="flex items-end gap-1">
        <span className="text-2xl font-bold text-gray-100">{value}</span>
        {unit && <span className="text-sm text-gray-500 mb-0.5">{unit}</span>}
      </div>
      {change !== undefined && (
        <div className={clsx('mt-2 text-xs font-medium', change >= 0 ? 'text-green-400' : 'text-red-400')}>
          {change >= 0 ? '▲' : '▼'} {Math.abs(change).toFixed(1)}%
        </div>
      )}
    </div>
  );
}
