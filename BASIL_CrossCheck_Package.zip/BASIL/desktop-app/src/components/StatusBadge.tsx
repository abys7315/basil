import clsx from 'clsx';
import type { Experiment } from '../types';

type Status = Experiment['status'];

const config: Record<Status, { label: string; className: string }> = {
  pending: { label: 'Pending', className: 'bg-gray-700 text-gray-300' },
  running: { label: 'Running', className: 'bg-blue-900 text-blue-300 animate-pulse' },
  completed: { label: 'Completed', className: 'bg-green-900 text-green-300' },
  failed: { label: 'Failed', className: 'bg-red-900 text-red-300' },
};

export default function StatusBadge({ status }: { status: Status }) {
  const { label, className } = config[status] ?? config.pending;
  return (
    <span className={clsx('inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium', className)}>
      {label}
    </span>
  );
}
