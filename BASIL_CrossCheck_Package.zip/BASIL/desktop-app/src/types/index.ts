export interface NetworkConfig {
  id: number;
  name: string;
  num_devices: number;
  room_width: number;
  room_height: number;
  ap_power: number;
  half_angle: number;
  data_rate_mbps: number;
  created_at: string;
}

export interface TrafficConfig {
  id: number;
  name: string;
  traffic_mode: 'normal' | 'burst';
  normal_rate: number;
  burst_rate: number;
  burst_ratio: number;
  packet_size: number;
  created_at: string;
}

export interface Algorithm {
  id: string;
  name: string;
  description: string;
}

export interface Experiment {
  id: number;
  name: string;
  network_config_id: number;
  traffic_config_id: number;
  scheduler: string;
  simulation_time?: number;
  sim_time?: number;
  engine?: 'ns3' | 'custom';
  status: 'pending' | 'running' | 'completed' | 'failed';
  created_at: string;
  completed_at?: string;
}

export interface DeviceStat {
  device_id: number;
  packets_sent?: number;
  packets_received?: number;
  packets_dropped?: number;
  avg_latency_ms?: number;
  throughput_mbps?: number;
  pdr?: number;
  distance_m?: number;
  snr_db?: number;
  per?: number;
  packets_generated?: number;
  packets_delivered?: number;
  delivered_on_time?: number;
  delivered_late?: number;
  lost_channel?: number;
}

export interface TimeSeriesPoint {
  time?: number;
  time_s?: number;
  throughput_mbps: number;
  latency_ms: number;
  queue_depth?: number;
}

export interface SimulationResult {
  id: number;
  experiment_id: number;
  avg_latency_ms: number;
  throughput_mbps: number;
  pdr: number;
  packet_delivery_ratio?: number;
  packet_loss: number;
  deadline_misses: number;
  fairness_index: number;
  sim_time: number;
  device_stats: DeviceStat[];
  per_device_stats?: DeviceStat[];
  time_series: TimeSeriesPoint[];
  created_at: string;
  is_optimal?: boolean;
  status?: string;
  mip_gap?: number;
  objective_value?: number;
  goodput_semantic_mbps?: number;
  scheduling_coverage?: number;
  scheduling_coverage_pct?: number;
  expected_received_pdr?: number;
  expected_received_pdr_pct?: number;
  realized_received_pdr?: number;
  realized_received_pdr_pct?: number;
  relative_semantic_goodput_vs_basil_opt_pct?: number;
  solver?: string;
  execution_time_s?: number;
  scheduling_deadline_misses?: number;
  end_to_end_deadline_failures?: number;
  optical_channel_losses?: number;
  scheduled_packets_count?: number;
  delivered_on_time?: number;
  delivered_late?: number;
  lost_channel?: number;
  dropped_queue?: number;
  pending_queue?: number;
  total_packets_generated?: number;
  ap_power_unit?: string;
  ap_power_mw?: number;
  ap_power_w?: number;
  p95_latency_ms?: number;
}
