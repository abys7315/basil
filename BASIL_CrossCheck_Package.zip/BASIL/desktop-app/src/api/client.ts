import axios from 'axios';
import type { NetworkConfig, TrafficConfig, Algorithm, Experiment, SimulationResult } from '../types';

// Detect whether running inside Tauri desktop shell or browser dev server
const isTauri = typeof window !== 'undefined' && ('__TAURI_INTERNALS__' in window || '__TAURI__' in window);
export const API_BASE_URL = isTauri ? 'http://127.0.0.1:8000/api' : '/api';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: { 'Content-Type': 'application/json' },
});

// System Health
export const checkHealth = () =>
  api.get('/health').then(r => r.data).catch(() => axios.get('http://127.0.0.1:8000/health').then(r => r.data));

// Network Configs
export const getNetworkConfigs = () =>
  api.get<NetworkConfig[]>('/network-configs').then(r => r.data);

export const createNetworkConfig = (data: Omit<NetworkConfig, 'id' | 'created_at'>) =>
  api.post<NetworkConfig>('/network-configs', data).then(r => r.data);

export const deleteNetworkConfig = (id: number) =>
  api.delete(`/network-configs/${id}`).then(r => r.data);

// Traffic Configs
export const getTrafficConfigs = () =>
  api.get<TrafficConfig[]>('/traffic-configs').then(r => r.data);

export const createTrafficConfig = (data: Omit<TrafficConfig, 'id' | 'created_at'>) =>
  api.post<TrafficConfig>('/traffic-configs', data).then(r => r.data);

export const deleteTrafficConfig = (id: number) =>
  api.delete(`/traffic-configs/${id}`).then(r => r.data);

// Algorithms
export const getAlgorithms = () =>
  api.get<Algorithm[]>('/algorithms').then(r => r.data);

// Experiments
export const getExperiments = () =>
  api.get<Experiment[]>('/experiments').then(r => r.data);

export const createExperiment = (data: Omit<Experiment, 'id' | 'status' | 'created_at' | 'completed_at'>) =>
  api.post<Experiment>('/experiments', data).then(r => r.data);

export const getExperiment = (id: number) =>
  api.get<Experiment>(`/experiments/${id}`).then(r => r.data);

export const deleteExperiment = (id: number) =>
  api.delete(`/experiments/${id}`).then(r => r.data);

// Simulation
export const runSimulation = (experimentId: number) =>
  api.post<SimulationResult>(`/simulate/${experimentId}`).then(r => r.data);

// Results
export const getResult = (experimentId: number) =>
  api.get<SimulationResult>(`/results/${experimentId}`).then(r => r.data);

export const compareResults = (ids: number[]) =>
  api.get<SimulationResult[]>('/results/compare', { params: { ids: ids.join(',') } }).then(r => r.data);

// Export
export const getExportUrl = (experimentId: number): string =>
  `${API_BASE_URL}/results/${experimentId}/export?format=csv`;

export const getExportJsonUrl = (experimentId: number): string =>
  `${API_BASE_URL}/results/${experimentId}/export/json`;
