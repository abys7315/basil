import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  Activity,
  PlusCircle,
  Trash2,
  Sliders,
  Sparkles,
  Info,
  Check,
  Zap,
  BarChart2,
} from 'lucide-react';
import { getTrafficConfigs, createTrafficConfig, deleteTrafficConfig } from '../api/client';
import type { TrafficConfig } from '../types';

const defaultForm = {
  name: '',
  traffic_mode: 'burst' as 'normal' | 'burst',
  normal_rate: 50,
  burst_rate: 300,
  burst_ratio: 0.25,
  packet_size: 1024,
};

const PRESETS = [
  {
    title: 'IoT Sensor Streams',
    desc: 'Steady Poisson arrivals (50 pkt/s, 256 bytes)',
    values: { name: 'IoT Sensor Stream', traffic_mode: 'normal' as const, normal_rate: 50, burst_rate: 100, burst_ratio: 0.05, packet_size: 256 }
  },
  {
    title: 'Tele-Robotic Mission Burst',
    desc: 'Urgent burst surges (350 pkt/s peak, 1024 bytes)',
    values: { name: 'Tele-Robotic Mission Burst', traffic_mode: 'burst' as const, normal_rate: 60, burst_rate: 350, burst_ratio: 0.25, packet_size: 1024 }
  },
  {
    title: 'Severe Video Burst Stress',
    desc: 'Intense buffer stress test (800 pkt/s peak, 1400 bytes)',
    values: { name: 'Severe Video Burst Stress', traffic_mode: 'burst' as const, normal_rate: 80, burst_rate: 800, burst_ratio: 0.40, packet_size: 1400 }
  }
];

export default function TrafficConfigPage() {
  const [configs, setConfigs] = useState<TrafficConfig[]>([]);
  const [form, setForm] = useState(defaultForm);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const load = async () => {
    setLoading(true);
    try {
      const data = await getTrafficConfigs();
      setConfigs(data);
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : 'Failed to load traffic configs');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  // Compute live waveform simulation of packet arrivals over 4.0 seconds
  const waveformData = useMemo(() => {
    const durationS = 4.0;
    const numBins = 80;
    const binDt = durationS / numBins;
    const bins = [];

    const isBurst = form.traffic_mode === 'burst';
    const normalRate = form.normal_rate;
    const burstRate = form.burst_rate;
    const burstRatio = form.burst_ratio;

    // Simulate 2 burst windows across the 4 seconds timeline
    const burstWindow1Start = 1.0;
    const burstWindow1End = 1.0 + (durationS * burstRatio * 0.6);
    const burstWindow2Start = 2.6;
    const burstWindow2End = 2.6 + (durationS * burstRatio * 0.4);

    let totalPackets = 0;
    for (let i = 0; i < numBins; i++) {
      const t = i * binDt;
      const inBurst = isBurst && (
        (t >= burstWindow1Start && t <= burstWindow1End) ||
        (t >= burstWindow2Start && t <= burstWindow2End)
      );

      const currentRate = inBurst ? burstRate : normalRate;
      // Add slight stochastic Poisson variation
      const jitter = 0.8 + 0.4 * Math.sin(i * 1.5);
      const expectedPackets = currentRate * binDt * jitter;
      const packets = Math.max(0, Math.round(expectedPackets));
      totalPackets += packets;

      bins.push({
        time: Number(t.toFixed(2)),
        packets,
        inBurst,
        rate: currentRate,
      });
    }

    const avgRate = totalPackets / durationS;
    const offeredMbps = (avgRate * form.packet_size * 8) / 1e6;
    const peakMbps = (form.burst_rate * form.packet_size * 8) / 1e6;

    return { bins, totalPackets, avgRate, offeredMbps, peakMbps };
  }, [form]);

  // Render traffic waveform canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;
    ctx.clearRect(0, 0, width, height);

    const padding = { top: 20, right: 20, bottom: 30, left: 45 };
    const chartW = width - padding.left - padding.right;
    const chartH = height - padding.top - padding.bottom;

    // Background grid
    ctx.fillStyle = '#0a0d14';
    ctx.fillRect(padding.left, padding.top, chartW, chartH);

    ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
    ctx.lineWidth = 1;
    for (let y = 0; y <= 4; y++) {
      const py = padding.top + (y / 4) * chartH;
      ctx.beginPath();
      ctx.moveTo(padding.left, py);
      ctx.lineTo(padding.left + chartW, py);
      ctx.stroke();
    }

    const bins = waveformData.bins;
    const maxPackets = Math.max(10, Math.max(...bins.map(b => b.packets)) * 1.15);
    const barW = (chartW / bins.length) - 1.5;

    // Draw bars
    bins.forEach((b, idx) => {
      const bx = padding.left + idx * (chartW / bins.length);
      const barH = (b.packets / maxPackets) * chartH;
      const by = padding.top + chartH - barH;

      if (b.inBurst) {
        ctx.fillStyle = '#f43f5e'; // Vibrant rose for burst
      } else {
        ctx.fillStyle = '#38bdf8'; // Cyan for Poisson
      }
      ctx.fillRect(bx, by, Math.max(2, barW), barH);
    });

    // Draw Burst Threshold Baseline Line
    const normalH = (form.normal_rate * (4.0 / bins.length) / maxPackets) * chartH;
    const normalY = padding.top + chartH - normalH;

    ctx.strokeStyle = 'rgba(56, 189, 248, 0.5)';
    ctx.setLineDash([4, 4]);
    ctx.beginPath();
    ctx.moveTo(padding.left, normalY);
    ctx.lineTo(padding.left + chartW, normalY);
    ctx.stroke();
    ctx.setLineDash([]);

    // Y Axis labels
    ctx.font = '10px monospace';
    ctx.fillStyle = '#64748b';
    ctx.textAlign = 'right';
    ctx.fillText(`${Math.round(maxPackets)} pkts`, padding.left - 6, padding.top + 10);
    ctx.fillText('0', padding.left - 6, padding.top + chartH);

    // X Axis labels
    ctx.textAlign = 'center';
    ctx.fillText('0s', padding.left, padding.top + chartH + 16);
    ctx.fillText('2.0s', padding.left + chartW / 2, padding.top + chartH + 16);
    ctx.fillText('4.0s', padding.left + chartW, padding.top + chartH + 16);
  }, [waveformData, form]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim()) {
      setError('Please provide a name for this traffic configuration');
      return;
    }
    setSaving(true);
    setError(null);
    setSuccess(null);
    try {
      await createTrafficConfig({
        name: form.name.trim(),
        traffic_mode: form.traffic_mode,
        normal_rate: form.normal_rate,
        burst_rate: form.burst_rate,
        burst_ratio: form.burst_ratio,
        packet_size: form.packet_size,
      });
      setSuccess(`Traffic profile "${form.name.trim()}" saved.`);
      await load();
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : 'Save failed');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: number) => {
    try {
      await deleteTrafficConfig(id);
      await load();
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : 'Delete failed');
    }
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2.5">
            <Activity className="text-cyan-400 w-6 h-6" />
            Heterogeneous Traffic Profile Generator
          </h1>
          <p className="text-sm text-slate-400 mt-1">
            Synthesize heterogeneous Poisson background streams, sudden traffic bursts, and packet latency constraints.
          </p>
        </div>

        {/* Presets */}
        <div className="flex items-center gap-2">
          {PRESETS.map((p, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => setForm(p.values)}
              className="px-3 py-1.5 rounded-lg bg-white/[0.04] hover:bg-cyan-500/10 border border-white/[0.08] hover:border-cyan-500/30 text-xs font-semibold text-slate-300 hover:text-cyan-300 transition-colors flex items-center gap-1.5"
            >
              <Sparkles className="w-3 h-3 text-cyan-400" />
              <span>{p.title}</span>
            </button>
          ))}
        </div>
      </div>

      {error && (
        <div className="bg-rose-950/50 border border-rose-700/60 rounded-xl p-4 text-rose-300 text-sm flex items-center gap-2">
          <Info className="w-4 h-4 flex-shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {success && (
        <div className="bg-emerald-950/50 border border-emerald-700/60 rounded-xl p-4 text-emerald-300 text-sm flex items-center gap-2">
          <Check className="w-4 h-4 flex-shrink-0" />
          <span>{success}</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Form Left */}
        <div className="lg:col-span-6 space-y-6">
          <form onSubmit={handleSubmit} className="glass-panel rounded-2xl p-6 space-y-5">
            <div className="flex items-center justify-between border-b border-white/[0.06] pb-4">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-2">
                <Sliders className="w-4 h-4 text-cyan-400" /> Arrival Distribution Parameters
              </span>
              <div className="flex items-center gap-1 p-0.5 rounded-lg bg-slate-900 border border-white/[0.08]">
                <button
                  type="button"
                  onClick={() => setForm({ ...form, traffic_mode: 'normal' })}
                  className={`px-3 py-1 rounded-md text-xs font-semibold transition-colors ${
                    form.traffic_mode === 'normal'
                      ? 'bg-cyan-500 text-white shadow-sm'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Poisson Normal
                </button>
                <button
                  type="button"
                  onClick={() => setForm({ ...form, traffic_mode: 'burst' })}
                  className={`px-3 py-1 rounded-md text-xs font-semibold transition-colors ${
                    form.traffic_mode === 'burst'
                      ? 'bg-rose-500 text-white shadow-sm'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Bursty (BASIL Test)
                </button>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">Profile Name</label>
              <input
                type="text"
                value={form.name}
                placeholder="e.g., Heavy Burst Tele-Robotics"
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                className="w-full bg-slate-900/80 border border-white/[0.1] rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 transition-colors"
              />
            </div>

            {/* Rates */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-400 font-medium">Normal Poisson Rate</span>
                  <span className="font-mono text-cyan-400 font-bold">{form.normal_rate} pkts/s</span>
                </div>
                <input
                  type="range"
                  min={10}
                  max={500}
                  step={10}
                  value={form.normal_rate}
                  onChange={(e) => setForm({ ...form, normal_rate: Number(e.target.value) })}
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>

              <div className="space-y-1.5">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-400 font-medium">Burst Peak Rate</span>
                  <span className="font-mono text-rose-400 font-bold">{form.burst_rate} pkts/s</span>
                </div>
                <input
                  type="range"
                  min={50}
                  max={1200}
                  step={25}
                  value={form.burst_rate}
                  disabled={form.traffic_mode !== 'burst'}
                  onChange={(e) => setForm({ ...form, burst_rate: Number(e.target.value) })}
                  className="w-full accent-rose-400 cursor-pointer disabled:opacity-40"
                />
              </div>
            </div>

            {/* Ratio and Size */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-400 font-medium">Burst Duration Ratio</span>
                  <span className="font-mono text-indigo-400 font-bold">{(form.burst_ratio * 100).toFixed(0)}%</span>
                </div>
                <input
                  type="range"
                  min={0.05}
                  max={0.60}
                  step={0.05}
                  value={form.burst_ratio}
                  disabled={form.traffic_mode !== 'burst'}
                  onChange={(e) => setForm({ ...form, burst_ratio: Number(e.target.value) })}
                  className="w-full accent-indigo-400 cursor-pointer disabled:opacity-40"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1">Packet Payload Size</label>
                <select
                  value={form.packet_size}
                  onChange={(e) => setForm({ ...form, packet_size: Number(e.target.value) })}
                  className="w-full bg-slate-900/80 border border-white/[0.1] rounded-xl px-3 py-2 text-sm text-white"
                >
                  <option value={128}>128 Bytes (Sensor Telemetry)</option>
                  <option value={512}>512 Bytes (Voice / Audio Stream)</option>
                  <option value={1024}>1024 Bytes (Standard Li-Fi PDU)</option>
                  <option value={1400}>1400 Bytes (Maximum MTU Video)</option>
                </select>
              </div>
            </div>

            <button
              type="submit"
              disabled={saving}
              className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white font-bold py-3 rounded-xl shadow-lg shadow-cyan-500/20 transition-all disabled:opacity-50"
            >
              <PlusCircle className="w-4 h-4" />
              <span>{saving ? 'Saving Profile…' : 'Save Traffic Profile'}</span>
            </button>
          </form>

          {/* Saved List */}
          <div className="glass-panel rounded-2xl p-5 space-y-3">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Saved Traffic Profiles ({configs.length})
            </span>
            {loading ? (
              <p className="text-xs text-slate-500 py-3">Loading profiles…</p>
            ) : configs.length === 0 ? (
              <p className="text-xs text-slate-500 py-3">No profiles saved.</p>
            ) : (
              <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                {configs.map((c) => (
                  <div
                    key={c.id}
                    className="flex items-center justify-between p-3 rounded-xl bg-white/[0.02] hover:bg-white/[0.05] border border-white/[0.04] text-xs transition-colors"
                  >
                    <div>
                      <div className="font-semibold text-slate-200 flex items-center gap-2">
                        <span>{c.name}</span>
                        <span className={`text-[10px] px-1.5 py-0.2 rounded font-mono ${
                          c.traffic_mode === 'burst' ? 'bg-rose-500/20 text-rose-300' : 'bg-cyan-500/20 text-cyan-300'
                        }`}>
                          {c.traffic_mode}
                        </span>
                      </div>
                      <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                        Base: {c.normal_rate} pkts/s | Peak: {c.burst_rate} pkts/s | {c.packet_size} Bytes
                      </div>
                    </div>
                    <button
                      onClick={() => handleDelete(c.id)}
                      className="p-1.5 text-slate-500 hover:text-rose-400 transition-colors"
                      title="Delete profile"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Right Waveform Preview */}
        <div className="lg:col-span-6 space-y-4">
          <div className="glass-panel rounded-2xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-white/[0.06] pb-3">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
                <BarChart2 className="w-4 h-4 text-cyan-400" /> Waveform Arrival Timeline (4.0s Horizon)
              </span>
              <span className="text-[10px] font-mono text-slate-400">
                Live Waveform Preview
              </span>
            </div>

            <div className="relative flex items-center justify-center bg-black/40 rounded-xl border border-white/[0.05] p-2">
              <canvas
                ref={canvasRef}
                width={460}
                height={260}
                className="rounded-lg shadow-inner"
              />
            </div>

            {/* Offered Load Telemetry */}
            <div className="grid grid-cols-3 gap-3 pt-2">
              <div className="p-3 rounded-xl bg-white/[0.02] border border-white/[0.05] text-center">
                <div className="text-[10px] font-semibold uppercase tracking-wider text-slate-400">Average Rate</div>
                <div className="text-base font-extrabold text-cyan-400 font-mono mt-1">
                  {waveformData.avgRate.toFixed(0)} <span className="text-xs font-normal text-slate-400">pkts/s</span>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-white/[0.02] border border-white/[0.05] text-center">
                <div className="text-[10px] font-semibold uppercase tracking-wider text-slate-400">Average Offered</div>
                <div className="text-base font-extrabold text-indigo-300 font-mono mt-1">
                  {waveformData.offeredMbps.toFixed(2)} <span className="text-xs font-normal text-slate-400">Mbps</span>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-white/[0.02] border border-white/[0.05] text-center">
                <div className="text-[10px] font-semibold uppercase tracking-wider text-slate-400">Peak Burst Load</div>
                <div className="text-base font-extrabold text-rose-400 font-mono mt-1">
                  {waveformData.peakMbps.toFixed(2)} <span className="text-xs font-normal text-slate-400">Mbps</span>
                </div>
              </div>
            </div>

            <div className="text-[11px] text-slate-400 border-t border-white/[0.06] pt-3 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-sm bg-cyan-400" /> Poisson Baseline
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-sm bg-rose-500" /> Urgent Burst Spikes
              </span>
              <span className="text-slate-400">
                PDU: {form.packet_size}B
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
