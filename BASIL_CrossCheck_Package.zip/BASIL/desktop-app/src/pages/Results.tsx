import React, { useState, useEffect } from 'react';
import Plot from 'react-plotly.js';
import {
  Download,
  RefreshCw,
  BarChart2,
  Layers,
  FileCode,
  FileText,
  Search,
  CheckCircle2,
  Clock,
  Zap,
  TrendingUp,
  Cpu,
  Radio,
  ArrowRight,
  ExternalLink,
} from 'lucide-react';
import {
  getExperiments,
  getResult,
  compareResults,
  getExportUrl,
  getExportJsonUrl,
} from '../api/client';
import type { Experiment, SimulationResult } from '../types';

export default function Results() {
  const [experiments, setExperiments] = useState<Experiment[]>([]);
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [selectedExpId, setSelectedExpId] = useState<number | null>(null);
  const [result, setResult] = useState<SimulationResult | null>(null);
  const [loadingResult, setLoadingResult] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  // Comparison mode
  const [compareMode, setCompareMode] = useState<boolean>(false);
  const [selectedForCompare, setSelectedForCompare] = useState<number[]>([]);
  const [comparisonResults, setComparisonResults] = useState<SimulationResult[]>([]);
  const [loadingCompare, setLoadingCompare] = useState<boolean>(false);

  const loadExperiments = async () => {
    try {
      const data = await getExperiments();
      setExperiments(data);
      if (!selectedExpId && data.length > 0) {
        const completed = data.filter((e) => e.status === 'completed');
        if (completed.length > 0) {
          setSelectedExpId(completed[completed.length - 1].id);
        } else {
          setSelectedExpId(data[0].id);
        }
      }
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : 'Failed to fetch experiments');
    }
  };

  useEffect(() => {
    loadExperiments();
  }, []);

  useEffect(() => {
    if (!selectedExpId) return;
    const fetchResult = async () => {
      setLoadingResult(true);
      setError(null);
      try {
        const res = await getResult(selectedExpId);
        setResult(res);
      } catch {
        setResult(null);
      } finally {
        setLoadingResult(false);
      }
    };
    fetchResult();
  }, [selectedExpId]);

  const handleToggleCompare = (id: number) => {
    setSelectedForCompare((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );
  };

  const handleRunCompare = async () => {
    if (selectedForCompare.length === 0) return;
    setLoadingCompare(true);
    try {
      const res = await compareResults(selectedForCompare);
      setComparisonResults(res);
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : 'Failed to compare results');
    } finally {
      setLoadingCompare(false);
    }
  };

  const filteredExperiments = experiments.filter((e) => {
    const matchesStatus = statusFilter === 'all' || e.status === statusFilter;
    const matchesSearch =
      e.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      e.scheduler.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  const selectedExperiment = experiments.find((e) => e.id === selectedExpId);

  // Plotly chart series
  const timeSeries = result?.time_series || [];
  const perDeviceStats = (result?.per_device_stats || result?.device_stats || []) as any[];

  return (
    <div className="space-y-8">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2.5">
            <BarChart2 className="text-cyan-400 w-6 h-6" />
            Results & Telemetry Analytics
          </h1>
          <p className="text-sm text-slate-400 mt-1">
            Compare scheduling metrics, latency CDF curves, and optical packet loss distributions.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => {
              setCompareMode(!compareMode);
              if (!compareMode) {
                // Auto-select latest completed experiments for instant comparison
                const completed = experiments.filter((e) => e.status === 'completed');
                const lastIds = completed.slice(-3).map((e) => e.id);
                setSelectedForCompare(lastIds);
                if (lastIds.length > 0) {
                  compareResults(lastIds).then(setComparisonResults).catch(() => {});
                }
              }
            }}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all shadow-md ${
              compareMode
                ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-purple-500/20'
                : 'bg-white/[0.04] hover:bg-white/[0.08] text-slate-300 border border-white/[0.08]'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>{compareMode ? 'Single Run View' : 'Side-by-Side Comparison'}</span>
          </button>

          <button
            type="button"
            onClick={loadExperiments}
            className="p-2.5 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] text-slate-300 border border-white/[0.08] transition-colors"
            title="Refresh datasets"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {error && (
        <div className="bg-rose-950/60 border border-rose-700/60 rounded-xl p-4 text-rose-300 text-sm">
          {error}
        </div>
      )}

      {compareMode ? (
        /* ================= Multi-Experiment Side-by-Side Comparison View ================= */
        <div className="space-y-6">
          <div className="glass-panel rounded-2xl p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-white/[0.06] pb-3">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
                Select Experiments to Benchmark Side-by-Side
              </span>
              <button
                onClick={handleRunCompare}
                disabled={selectedForCompare.length < 2 || loadingCompare}
                className="bg-purple-600 hover:bg-purple-500 disabled:opacity-40 text-white px-4 py-2 rounded-xl text-xs font-bold transition-colors shadow-lg shadow-purple-500/20"
              >
                {loadingCompare ? 'Evaluating Benchmarks…' : `Update Comparison (${selectedForCompare.length} Selected)`}
              </button>
            </div>

            <div className="flex flex-wrap gap-2.5">
              {experiments
                .filter((e) => e.status === 'completed')
                .map((e) => {
                  const isChecked = selectedForCompare.includes(e.id);
                  return (
                    <button
                      key={e.id}
                      type="button"
                      onClick={() => handleToggleCompare(e.id)}
                      className={`px-3 py-2 rounded-xl border text-xs font-mono transition-all flex items-center gap-2 ${
                        isChecked
                          ? 'bg-purple-500/20 border-purple-400 text-white shadow-sm'
                          : 'bg-white/[0.02] border-white/[0.06] text-slate-400 hover:border-white/[0.15]'
                      }`}
                    >
                      <span className={`w-2 h-2 rounded-full ${isChecked ? 'bg-purple-400 shadow-[0_0_8px_#c084fc]' : 'bg-slate-600'}`} />
                      <span className="font-semibold text-slate-200">#{e.id}</span>
                      <span className="text-slate-400">[{e.scheduler}]</span>
                      <span className="text-slate-500 truncate max-w-[140px]">{e.name}</span>
                    </button>
                  );
                })}
            </div>
          </div>

          {/* Comparison Table */}
          {comparisonResults.length > 0 && (
            <div className="glass-panel rounded-2xl overflow-hidden border border-white/[0.08]">
              <div className="p-4 bg-white/[0.02] border-b border-white/[0.06] flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
                  Phase 3.5 Standardized Research Metrics Table
                </span>
                <span className="text-[10px] font-mono text-cyan-400">
                  {comparisonResults.length} Schedulers Compared
                </span>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-xs font-mono">
                  <thead>
                    <tr className="border-b border-white/[0.08] text-slate-400 bg-black/40 uppercase text-[10px] tracking-wider">
                      <th className="text-left px-4 py-3.5 font-bold">Scheduler & Run</th>
                      <th className="text-right px-4 py-3.5 font-bold text-emerald-400">Throughput (Mbps)</th>
                      <th className="text-right px-4 py-3.5 font-bold text-cyan-300">Realized PDR (%)</th>
                      <th className="text-right px-4 py-3.5 font-bold text-blue-300">Coverage (%)</th>
                      <th className="text-right px-4 py-3.5 font-bold text-amber-300">Sched Misses</th>
                      <th className="text-right px-4 py-3.5 font-bold text-rose-400">E2E Failures</th>
                      <th className="text-right px-4 py-3.5 font-bold text-orange-400">Optical Losses</th>
                      <th className="text-right px-4 py-3.5 font-bold">Latency (ms)</th>
                      <th className="text-right px-4 py-3.5 font-bold">Fairness</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/[0.04]">
                    {comparisonResults.map((cr) => {
                      const exp = experiments.find((e) => e.id === cr.experiment_id);
                      const realPdr = cr.realized_received_pdr_pct != null
                        ? cr.realized_received_pdr_pct.toFixed(2)
                        : (cr.pdr ? (cr.pdr * 100).toFixed(2) : '0.00');
                      const schedCov = cr.scheduling_coverage_pct != null
                        ? cr.scheduling_coverage_pct.toFixed(1)
                        : (cr.scheduling_coverage ? (cr.scheduling_coverage * 100).toFixed(1) : '100.0');

                      return (
                        <tr key={cr.id} className="hover:bg-white/[0.02] transition-colors">
                          <td className="px-4 py-3.5 font-sans font-medium text-white">
                            <div className="flex items-center gap-2">
                              <span className="font-bold text-cyan-400 font-mono">#{cr.experiment_id}</span>
                              <span className="px-2 py-0.5 rounded-full text-[10px] bg-white/[0.04] border border-white/[0.08] text-slate-300 font-mono">
                                {exp?.scheduler || 'Scheduler'}
                              </span>
                            </div>
                            <div className="text-[10px] text-slate-400 mt-0.5 truncate max-w-xs">
                              {exp?.name || 'Simulation'}
                            </div>
                          </td>
                          <td className="text-right px-4 py-3.5 text-emerald-400 font-bold">
                            {cr.throughput_mbps.toFixed(2)}
                          </td>
                          <td className="text-right px-4 py-3.5 text-cyan-300 font-bold">
                            {realPdr} %
                          </td>
                          <td className="text-right px-4 py-3.5 text-blue-300">
                            {schedCov} %
                          </td>
                          <td className="text-right px-4 py-3.5 text-amber-300 font-bold">
                            {cr.scheduling_deadline_misses ?? cr.deadline_misses ?? 0}
                          </td>
                          <td className="text-right px-4 py-3.5 text-rose-400 font-bold">
                            {cr.end_to_end_deadline_failures ?? 0}
                          </td>
                          <td className="text-right px-4 py-3.5 text-orange-400">
                            {cr.lost_channel ?? 0}
                          </td>
                          <td className="text-right px-4 py-3.5 text-slate-300">
                            {cr.avg_latency_ms.toFixed(2)}
                          </td>
                          <td className="text-right px-4 py-3.5 text-slate-300">
                            {(cr.fairness_index ?? 1.0).toFixed(3)}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      ) : (
        /* ================= Single Experiment Detailed View ================= */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Experiments Selector Sidebar */}
          <div className="lg:col-span-4 space-y-4">
            <div className="glass-panel rounded-2xl p-4 space-y-3">
              <div className="relative">
                <Search className="w-3.5 h-3.5 absolute left-3 top-3 text-slate-500" />
                <input
                  type="text"
                  placeholder="Filter runs by name..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full bg-slate-900/80 border border-white/[0.08] rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div className="space-y-1.5 max-h-[600px] overflow-y-auto pr-1">
                {filteredExperiments.length === 0 ? (
                  <p className="text-xs text-slate-500 py-6 text-center">No runs match filter.</p>
                ) : (
                  filteredExperiments.map((e) => {
                    const isSelected = selectedExpId === e.id;
                    return (
                      <button
                        key={e.id}
                        type="button"
                        onClick={() => setSelectedExpId(e.id)}
                        className={`w-full text-left p-3 rounded-xl border transition-all text-xs ${
                          isSelected
                            ? 'bg-gradient-to-r from-cyan-500/15 to-indigo-500/10 border-cyan-400 text-white shadow-md'
                            : 'bg-white/[0.02] border-white/[0.04] text-slate-400 hover:border-white/[0.12] hover:text-slate-200'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-bold font-mono text-cyan-400">#{e.id}</span>
                          <span
                            className={`text-[9px] font-bold px-1.5 py-0.2 rounded-full uppercase tracking-wider ${
                              e.status === 'completed'
                                ? 'bg-emerald-500/15 text-emerald-400'
                                : 'bg-rose-500/15 text-rose-400'
                            }`}
                          >
                            {e.status}
                          </span>
                        </div>
                        <div className="font-semibold text-white mt-1 truncate">{e.name}</div>
                        <div className="text-[10px] text-slate-500 mt-1 flex items-center justify-between font-mono">
                          <span>{e.scheduler}</span>
                          <span>{e.simulation_time ?? e.sim_time ?? 1.0}s</span>
                        </div>
                      </button>
                    );
                  })
                )}
              </div>
            </div>
          </div>

          {/* Right Main Telemetry & Plotly Analytics */}
          <div className="lg:col-span-8 space-y-6">
            {selectedExperiment && result ? (
              <>
                {/* Top Run Header Banner */}
                <div className="glass-panel rounded-2xl p-6 flex flex-wrap items-center justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-3">
                      <h2 className="text-xl font-bold text-white">{selectedExperiment.name}</h2>
                      <span className="text-xs px-2.5 py-0.5 rounded-full bg-cyan-500/15 text-cyan-300 border border-cyan-500/30 font-mono font-bold">
                        {selectedExperiment.scheduler}
                      </span>
                    </div>
                    <p className="text-xs text-slate-400 mt-1 font-mono">
                      Run #{selectedExperiment.id} | Engine: {selectedExperiment.engine ?? 'ns-3.42'} | Horizon: {selectedExperiment.simulation_time ?? selectedExperiment.sim_time ?? 1.0}s
                    </p>
                  </div>

                  {/* Export Buttons */}
                  <div className="flex items-center gap-2">
                    <a
                      href={getExportUrl(selectedExperiment.id)}
                      download={`basil_exp_${selectedExperiment.id}.csv`}
                      className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white/[0.04] hover:bg-cyan-500/10 border border-white/[0.08] hover:border-cyan-500/30 text-xs font-semibold text-slate-300 hover:text-cyan-300 transition-colors"
                    >
                      <Download className="w-3.5 h-3.5 text-cyan-400" />
                      <span>Export CSV</span>
                    </a>

                    <a
                      href={getExportJsonUrl(selectedExperiment.id)}
                      download={`basil_exp_${selectedExperiment.id}.json`}
                      className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white/[0.04] hover:bg-purple-500/10 border border-white/[0.08] hover:border-purple-500/30 text-xs font-semibold text-slate-300 hover:text-purple-300 transition-colors"
                    >
                      <FileCode className="w-3.5 h-3.5 text-purple-400" />
                      <span>Export JSON</span>
                    </a>
                  </div>
                </div>

                {/* 7 Standardized Metrics Cards */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div className="glass-panel rounded-xl p-4">
                    <div className="text-[10px] uppercase font-bold text-slate-400">Throughput</div>
                    <div className="text-xl font-extrabold text-cyan-400 font-mono mt-1">
                      {result.throughput_mbps.toFixed(2)} <span className="text-xs font-normal text-slate-400">Mbps</span>
                    </div>
                  </div>

                  <div className="glass-panel rounded-xl p-4">
                    <div className="text-[10px] uppercase font-bold text-slate-400">Realized PDR</div>
                    <div className="text-xl font-extrabold text-emerald-400 font-mono mt-1">
                      {result.realized_received_pdr_pct != null
                        ? result.realized_received_pdr_pct.toFixed(2)
                        : (result.pdr ? (result.pdr * 100).toFixed(2) : '0.00')} %
                    </div>
                  </div>

                  <div className="glass-panel rounded-xl p-4">
                    <div className="text-[10px] uppercase font-bold text-slate-400">Sched Coverage</div>
                    <div className="text-xl font-extrabold text-blue-300 font-mono mt-1">
                      {result.scheduling_coverage_pct != null ? result.scheduling_coverage_pct.toFixed(1) : '100.0'} %
                    </div>
                  </div>

                  <div className="glass-panel rounded-xl p-4">
                    <div className="text-[10px] uppercase font-bold text-slate-400">Avg Latency</div>
                    <div className="text-xl font-extrabold text-amber-300 font-mono mt-1">
                      {result.avg_latency_ms.toFixed(2)} <span className="text-xs font-normal text-slate-400">ms</span>
                    </div>
                  </div>
                </div>

                {/* Plotly Interactive Time Series */}
                <div className="glass-panel rounded-2xl p-5 space-y-3">
                  <div className="flex items-center justify-between border-b border-white/[0.06] pb-3">
                    <span className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
                      <TrendingUp className="w-4 h-4 text-cyan-400" /> Dynamic Telemetry Over Time
                    </span>
                    <span className="text-[10px] font-mono text-slate-400">Interactive Plotly Engine</span>
                  </div>

                  {timeSeries.length > 0 ? (
                    <div className="w-full h-72">
                      <Plot
                        data={[
                          {
                            x: timeSeries.map((t) => (t as any).time_s ?? (t as any).time ?? 0),
                            y: timeSeries.map((t) => t.throughput_mbps),
                            type: 'scatter',
                            mode: 'lines+markers',
                            name: 'Throughput (Mbps)',
                            line: { color: '#38bdf8', width: 2.5, shape: 'spline' },
                            marker: { size: 5, color: '#38bdf8' },
                          },
                          {
                            x: timeSeries.map((t) => (t as any).time_s ?? (t as any).time ?? 0),
                            y: timeSeries.map((t) => t.latency_ms),
                            type: 'scatter',
                            mode: 'lines',
                            name: 'Latency (ms)',
                            yaxis: 'y2',
                            line: { color: '#f59e0b', width: 1.8, dash: 'dot' },
                          },
                        ]}
                        layout={{
                          autosize: true,
                          paper_bgcolor: 'transparent',
                          plot_bgcolor: 'transparent',
                          margin: { l: 45, r: 45, t: 15, b: 35 },
                          font: { color: '#94a3b8', family: 'monospace', size: 10 },
                          xaxis: {
                            title: { text: 'Simulation Time (s)' } as any,
                            gridcolor: 'rgba(255, 255, 255, 0.05)',
                          },
                          yaxis: {
                            title: { text: 'Throughput (Mbps)' } as any,
                            gridcolor: 'rgba(255, 255, 255, 0.05)',
                          },
                          yaxis2: {
                            title: { text: 'Latency (ms)' } as any,
                            overlaying: 'y',
                            side: 'right',
                            gridcolor: 'transparent',
                          },
                          legend: {
                            orientation: 'h',
                            y: 1.15,
                            x: 0,
                            font: { color: '#cbd5e1' },
                          },
                        }}
                        useResizeHandler
                        style={{ width: '100%', height: '100%' }}
                      />
                    </div>
                  ) : (
                    <p className="text-xs text-slate-500 py-12 text-center font-mono">
                      No time-series data captured for this experiment.
                    </p>
                  )}
                </div>

                {/* Per-Device Optical Signal Breakdown */}
                {perDeviceStats.length > 0 && (
                  <div className="glass-panel rounded-2xl p-5 space-y-3">
                    <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
                      Per-Device Physical Channel Breakdown
                    </span>
                    <div className="overflow-x-auto">
                      <table className="w-full text-xs font-mono text-left">
                        <thead>
                          <tr className="border-b border-white/[0.06] text-slate-400 uppercase text-[10px]">
                            <th className="pb-2.5 font-bold">Device</th>
                            <th className="pb-2.5 font-bold">Distance</th>
                            <th className="pb-2.5 font-bold">Optical SNR</th>
                            <th className="pb-2.5 font-bold">Optical PER</th>
                            <th className="pb-2.5 font-bold text-right">Offered Pkts</th>
                            <th className="pb-2.5 font-bold text-right">Delivered</th>
                            <th className="pb-2.5 font-bold text-right">Channel Lost</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-white/[0.04]">
                          {perDeviceStats.map((d: any) => (
                            <tr key={d.device_id} className="hover:bg-white/[0.02]">
                              <td className="py-2.5 text-white font-bold">Device #{d.device_id}</td>
                              <td className="py-2.5 text-slate-400">{d.distance_m ?? '—'} m</td>
                              <td className="py-2.5 text-cyan-300 font-bold">{d.snr_db ? `${d.snr_db.toFixed(1)} dB` : '—'}</td>
                              <td className="py-2.5">
                                <span className={d.per < 0.05 ? 'text-emerald-400' : d.per < 0.5 ? 'text-amber-400' : 'text-rose-400'}>
                                  {d.per != null ? `${(d.per * 100).toFixed(1)}%` : '—'}
                                </span>
                              </td>
                              <td className="py-2.5 text-right text-slate-300">{d.packets_generated ?? '—'}</td>
                              <td className="py-2.5 text-right text-emerald-400 font-bold">{d.packets_delivered ?? d.delivered_on_time ?? '—'}</td>
                              <td className="py-2.5 text-right text-rose-400">{d.lost_channel ?? '0'}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}
              </>
            ) : (
              <div className="glass-panel rounded-2xl p-12 text-center text-slate-500 text-xs">
                {loadingResult ? 'Loading simulation telemetry…' : 'Select an experiment from the left to view comprehensive telemetry.'}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
