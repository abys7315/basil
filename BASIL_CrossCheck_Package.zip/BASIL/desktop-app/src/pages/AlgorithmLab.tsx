import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  FlaskConical,
  Play,
  CheckCircle,
  AlertTriangle,
  Loader2,
  Cpu,
  Layers,
  ArrowRight,
  Shield,
  Zap,
  BarChart3,
  Clock,
  Radio,
  FileCheck,
} from 'lucide-react';
import clsx from 'clsx';
import {
  getNetworkConfigs,
  getTrafficConfigs,
  createExperiment,
  runSimulation,
} from '../api/client';
import type { NetworkConfig, TrafficConfig, SimulationResult } from '../types';

const ALGORITHMS = [
  {
    id: 'FIFO',
    name: 'FIFO (First-In, First-Out)',
    badge: 'Baseline',
    badgeColor: 'border-slate-500 text-slate-400 bg-slate-500/10',
    desc: 'Strict arrival order. Suffers from Head-of-Line blocking and latency deadline degradation under bursts.',
    icon: Layers,
  },
  {
    id: 'RoundRobin',
    name: 'Round Robin (Cyclic)',
    badge: 'Fairness',
    badgeColor: 'border-emerald-500 text-emerald-400 bg-emerald-500/10',
    desc: 'Fair cyclic allocation across device queues. Prevents single-device starvation but is deadline-unaware.',
    icon: Radio,
  },
  {
    id: 'StrictPriority',
    name: 'Strict Priority (Preemptive)',
    badge: 'Urgency Only',
    badgeColor: 'border-amber-500 text-amber-400 bg-amber-500/10',
    desc: 'Urgent traffic always preempts best-effort. Starves lower-priority flows completely under sustained bursts.',
    icon: AlertTriangle,
  },
  {
    id: 'BASIL_PSA',
    name: 'BASIL-PSA (Online Adaptive)',
    badge: 'Proposed Novel',
    badgeColor: 'border-cyan-400 text-cyan-300 bg-cyan-500/15',
    desc: 'Dual-tier queuing + CUSUM burst detection + urgency weighting + starvation-free round-robin fallback.',
    icon: Zap,
  },
  {
    id: 'BASIL_OPT',
    name: 'BASIL-OPT (Offline MILP Oracle)',
    badge: 'Optimal Bound',
    badgeColor: 'border-purple-400 text-purple-300 bg-purple-500/15',
    desc: 'Mixed-Integer Linear Program with future arrival awareness. Solved via HiGHS-1.16.0 for proven upper bound.',
    icon: Cpu,
  },
];

export default function AlgorithmLab() {
  const navigate = useNavigate();
  const [networkConfigs, setNetworkConfigs] = useState<NetworkConfig[]>([]);
  const [trafficConfigs, setTrafficConfigs] = useState<TrafficConfig[]>([]);
  const [selectedNetwork, setSelectedNetwork] = useState<number | ''>('');
  const [selectedTraffic, setSelectedTraffic] = useState<number | ''>('');
  const [selectedAlgo, setSelectedAlgo] = useState('BASIL_PSA');
  const [simTime, setSimTime] = useState(1.0);
  const [selectedEngine, setSelectedEngine] = useState<'ns3' | 'custom'>('ns3');
  const [expName, setExpName] = useState('Li-Fi Benchmarking Run');

  const [loading, setLoading] = useState(false);
  const [configsLoading, setConfigsLoading] = useState(true);
  const [result, setResult] = useState<SimulationResult | null>(null);
  const [lastExpId, setLastExpId] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [status, setStatus] = useState<'idle' | 'running' | 'done' | 'error'>('idle');
  const [elapsedTime, setElapsedTime] = useState(0);

  useEffect(() => {
    (async () => {
      setConfigsLoading(true);
      try {
        const [nets, trafs] = await Promise.all([getNetworkConfigs(), getTrafficConfigs()]);
        setNetworkConfigs(nets);
        setTrafficConfigs(trafs);
        if (nets.length > 0) setSelectedNetwork(nets[0].id);
        if (trafs.length > 0) setSelectedTraffic(trafs[0].id);
      } catch (e: unknown) {
        setError(e instanceof Error ? e.message : 'Failed to load configurations');
      } finally {
        setConfigsLoading(false);
      }
    })();
  }, []);

  // Timer while running
  useEffect(() => {
    let interval: any = null;
    if (loading) {
      setElapsedTime(0);
      interval = setInterval(() => setElapsedTime((prev) => prev + 0.1), 100);
    } else if (interval) {
      clearInterval(interval);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [loading]);

  const handleRun = async () => {
    if (!selectedNetwork || !selectedTraffic || !selectedAlgo || !expName.trim()) {
      setError('Please select a network topology, traffic profile, and experiment name.');
      return;
    }
    setError(null);
    setResult(null);
    setStatus('running');
    setLoading(true);

    try {
      // Create experiment (both sim_time and simulation_time supported)
      const exp = await createExperiment({
        name: expName.trim(),
        network_config_id: Number(selectedNetwork),
        traffic_config_id: Number(selectedTraffic),
        scheduler: selectedAlgo,
        simulation_time: simTime,
        sim_time: simTime,
        engine: selectedEngine,
      });

      setLastExpId(exp.id);

      // Execute simulation
      const res = await runSimulation(exp.id);
      setResult(res);
      setStatus('done');
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : 'Simulation failed');
      setStatus('error');
    } finally {
      setLoading(false);
    }
  };

  const selectedNetObj = networkConfigs.find((n) => n.id === selectedNetwork);
  const selectedTrafObj = trafficConfigs.find((t) => t.id === selectedTraffic);

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2.5">
            <FlaskConical className="text-cyan-400 w-6 h-6" />
            Simulation & Algorithm Lab
          </h1>
          <p className="text-sm text-slate-400 mt-1">
            Execute real-time packet scheduling over physical Li-Fi optical channels using ns-3.42 and HiGHS-1.16.
          </p>
        </div>

        {/* Engine Mode Pill */}
        <div className="flex items-center gap-1.5 p-1 rounded-xl bg-slate-900 border border-white/[0.08] text-xs">
          <button
            type="button"
            onClick={() => setSelectedEngine('ns3')}
            className={`px-3 py-1.5 rounded-lg font-semibold transition-colors flex items-center gap-1.5 ${
              selectedEngine === 'ns3'
                ? 'bg-cyan-500 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Shield className="w-3.5 h-3.5" />
            <span>ns-3.42 Li-Fi (WSL)</span>
          </button>
          <button
            type="button"
            onClick={() => setSelectedEngine('custom')}
            className={`px-3 py-1.5 rounded-lg font-semibold transition-colors flex items-center gap-1.5 ${
              selectedEngine === 'custom'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Cpu className="w-3.5 h-3.5" />
            <span>Standalone C++ DES</span>
          </button>
        </div>
      </div>

      {error && (
        <div className="bg-rose-950/60 border border-rose-700/60 rounded-xl p-4 text-rose-300 text-sm flex items-center gap-2 shadow-lg">
          <AlertTriangle className="w-4 h-4 flex-shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Main Form and Execution Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Experiment Setup */}
        <div className="lg:col-span-7 space-y-6">
          {/* Card: Experiment Configuration */}
          <div className="glass-panel rounded-2xl p-6 space-y-5">
            <div className="flex items-center justify-between border-b border-white/[0.06] pb-3">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                1. Experiment Details
              </span>
              <span className="text-[10px] font-mono text-cyan-400">
                Auto-assigned ID on launch
              </span>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">Experiment Title</label>
              <input
                type="text"
                value={expName}
                onChange={(e) => setExpName(e.target.value)}
                placeholder="e.g., Burst Scenario - BASIL vs Strict Priority"
                className="w-full bg-slate-900/80 border border-white/[0.1] rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-cyan-400"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">Network Topology</label>
                {configsLoading ? (
                  <div className="text-xs text-slate-500 py-2">Loading topologies…</div>
                ) : (
                  <select
                    value={selectedNetwork}
                    onChange={(e) => setSelectedNetwork(Number(e.target.value))}
                    className="w-full bg-slate-900/80 border border-white/[0.1] rounded-xl px-3 py-2 text-xs text-white"
                  >
                    {networkConfigs.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name} ({c.num_devices} devices, {c.room_width}m)
                      </option>
                    ))}
                  </select>
                )}
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">Traffic Profile</label>
                {configsLoading ? (
                  <div className="text-xs text-slate-500 py-2">Loading profiles…</div>
                ) : (
                  <select
                    value={selectedTraffic}
                    onChange={(e) => setSelectedTraffic(Number(e.target.value))}
                    className="w-full bg-slate-900/80 border border-white/[0.1] rounded-xl px-3 py-2 text-xs text-white"
                  >
                    {trafficConfigs.map((t) => (
                      <option key={t.id} value={t.id}>
                        {t.name} ({t.traffic_mode}, {t.normal_rate} pkts/s)
                      </option>
                    ))}
                  </select>
                )}
              </div>
            </div>

            {/* Simulation Duration Horizon */}
            <div className="flex items-center justify-between pt-2">
              <span className="text-xs font-semibold text-slate-300">Simulation Horizon</span>
              <div className="flex items-center gap-2">
                {[0.5, 1.0, 2.0, 5.0].map((t) => (
                  <button
                    key={t}
                    type="button"
                    onClick={() => setSimTime(t)}
                    className={`px-3 py-1 rounded-lg text-xs font-mono font-bold transition-colors ${
                      simTime === t
                        ? 'bg-cyan-500 text-white'
                        : 'bg-white/[0.04] text-slate-400 hover:text-white'
                    }`}
                  >
                    {t}s
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Card: Scheduler Selection */}
          <div className="glass-panel rounded-2xl p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-white/[0.06] pb-3">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                2. Select Packet Scheduling Algorithm
              </span>
              <span className="text-[10px] font-mono text-slate-400">
                5 Standard Schedulers
              </span>
            </div>

            <div className="space-y-2.5">
              {ALGORITHMS.map((algo) => {
                const Icon = algo.icon;
                const isSelected = selectedAlgo === algo.id;
                return (
                  <button
                    key={algo.id}
                    type="button"
                    onClick={() => setSelectedAlgo(algo.id)}
                    className={clsx(
                      'w-full text-left p-3.5 rounded-xl border transition-all flex items-start gap-3.5',
                      isSelected
                        ? 'bg-gradient-to-r from-cyan-500/15 to-indigo-500/10 border-cyan-400/50 shadow-md shadow-cyan-500/5'
                        : 'bg-white/[0.02] border-white/[0.06] hover:border-white/[0.15]'
                    )}
                  >
                    <div
                      className={clsx(
                        'w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5',
                        isSelected ? 'bg-cyan-500/20 text-cyan-300' : 'bg-white/[0.04] text-slate-400'
                      )}
                    >
                      <Icon className="w-4 h-4" />
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-xs text-white">{algo.name}</span>
                        <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full border ${algo.badgeColor}`}>
                          {algo.badge}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">
                        {algo.desc}
                      </p>
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Launch Execution Button */}
            <button
              type="button"
              onClick={handleRun}
              disabled={loading}
              className="w-full mt-4 flex items-center justify-center gap-2.5 bg-gradient-to-r from-cyan-500 via-sky-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white font-extrabold py-3.5 rounded-xl shadow-xl shadow-cyan-500/25 transition-all disabled:opacity-50 text-sm tracking-wide"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Executing {selectedAlgo} in ns-3 ({elapsedTime.toFixed(1)}s)…</span>
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 fill-white" />
                  <span>Launch Simulation Run</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Right Column: Real-Time Execution Console & Results */}
        <div className="lg:col-span-5 space-y-6">
          {/* Active Configuration Summary */}
          <div className="glass-panel rounded-2xl p-5 space-y-3 text-xs">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
              Active Parameters Overview
            </span>
            <div className="grid grid-cols-2 gap-3 font-mono text-[11px]">
              <div className="p-2.5 rounded-xl bg-white/[0.02] border border-white/[0.05]">
                <span className="text-slate-400 block text-[10px]">Topology</span>
                <span className="text-white font-bold">{selectedNetObj?.name || 'Standard'}</span>
              </div>
              <div className="p-2.5 rounded-xl bg-white/[0.02] border border-white/[0.05]">
                <span className="text-slate-400 block text-[10px]">Traffic Flow</span>
                <span className="text-white font-bold">{selectedTrafObj?.name || 'Bursty'}</span>
              </div>
              <div className="p-2.5 rounded-xl bg-white/[0.02] border border-white/[0.05]">
                <span className="text-slate-400 block text-[10px]">Physical Rate</span>
                <span className="text-cyan-400 font-bold">{selectedNetObj?.data_rate_mbps || 20} Mbps</span>
              </div>
              <div className="p-2.5 rounded-xl bg-white/[0.02] border border-white/[0.05]">
                <span className="text-slate-400 block text-[10px]">Horizon</span>
                <span className="text-indigo-300 font-bold">{simTime} Seconds</span>
              </div>
            </div>
          </div>

          {/* Execution Progress / Results Panel */}
          {loading && (
            <div className="glass-panel rounded-2xl p-6 text-center space-y-4 shimmer-effect">
              <div className="w-12 h-12 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center mx-auto text-cyan-400">
                <Loader2 className="w-6 h-6 animate-spin" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">Simulating Optical Wireless Transmission</h3>
                <p className="text-xs text-slate-400 mt-1 font-mono">
                  Dispatching packets to {selectedAlgo} in ns-3.42 ({elapsedTime.toFixed(1)}s)
                </p>
              </div>
              <div className="w-full bg-slate-900 rounded-full h-1.5 overflow-hidden">
                <div className="bg-cyan-400 h-full rounded-full animate-pulse w-3/4" />
              </div>
            </div>
          )}

          {status === 'done' && result && (
            <div className="glass-panel rounded-2xl p-6 space-y-5 border-emerald-500/30 shadow-xl shadow-emerald-500/5">
              <div className="flex items-center justify-between border-b border-white/[0.08] pb-3">
                <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm">
                  <CheckCircle className="w-4 h-4" />
                  <span>Simulation Complete</span>
                </div>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
                  Exp #{lastExpId}
                </span>
              </div>

              {/* Solved Optimal Pill if BASIL-OPT */}
              {result.solver && (
                <div className="p-3 rounded-xl bg-purple-950/40 border border-purple-800/40 text-xs text-purple-200 space-y-1">
                  <div className="flex items-center justify-between font-bold">
                    <span>{result.solver} Offline Oracle</span>
                    <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-purple-500/20">
                      MIP Gap: {((result.mip_gap ?? 0) * 100).toFixed(2)}%
                    </span>
                  </div>
                  <div className="text-[11px] text-purple-300/80">
                    Slotted MILP solved to global mathematical optimality.
                  </div>
                </div>
              )}

              {/* 7 Standardized Metrics Telemetry Grid */}
              <div className="grid grid-cols-2 gap-2.5">
                <div className="p-3 rounded-xl bg-white/[0.02] border border-white/[0.05]">
                  <span className="text-[10px] font-medium text-slate-400 block">Realized Recv PDR</span>
                  <span className="text-base font-extrabold text-emerald-400 font-mono">
                    {result.realized_received_pdr_pct != null
                      ? result.realized_received_pdr_pct.toFixed(2)
                      : (result.pdr ? (result.pdr * 100).toFixed(2) : '0.00')} %
                  </span>
                </div>

                <div className="p-3 rounded-xl bg-white/[0.02] border border-white/[0.05]">
                  <span className="text-[10px] font-medium text-slate-400 block">Raw Throughput</span>
                  <span className="text-base font-extrabold text-cyan-400 font-mono">
                    {result.throughput_mbps.toFixed(2)} Mbps
                  </span>
                </div>

                <div className="p-3 rounded-xl bg-white/[0.02] border border-white/[0.05]">
                  <span className="text-[10px] font-medium text-slate-400 block">Sched Coverage (Coverage %)</span>
                  <span className="text-base font-extrabold text-blue-300 font-mono">
                    {result.scheduling_coverage_pct != null ? result.scheduling_coverage_pct.toFixed(1) : '100.0'} %
                  </span>
                </div>

                <div className="p-3 rounded-xl bg-white/[0.02] border border-white/[0.05]">
                  <span className="text-[10px] font-medium text-slate-400 block">Avg Latency</span>
                  <span className="text-base font-extrabold text-amber-300 font-mono">
                    {result.avg_latency_ms.toFixed(2)} ms
                  </span>
                </div>

                <div className="p-3 rounded-xl bg-white/[0.02] border border-white/[0.05]">
                  <span className="text-[10px] font-medium text-slate-400 block">Sched Deadline Misses</span>
                  <span className="text-base font-extrabold text-rose-400 font-mono">
                    {result.scheduling_deadline_misses ?? result.deadline_misses ?? 0}
                  </span>
                </div>

                <div className="p-3 rounded-xl bg-white/[0.02] border border-white/[0.05]">
                  <span className="text-[10px] font-medium text-slate-400 block">E2E Deadline Failures</span>
                  <span className="text-base font-extrabold text-rose-300 font-mono">
                    {result.end_to_end_deadline_failures ?? 0}
                  </span>
                </div>
              </div>

              {/* Optical Channel Losses */}
              <div className="p-3 rounded-xl bg-white/[0.02] border border-white/[0.05] flex items-center justify-between text-xs font-mono">
                <span className="text-slate-400">Physical Optical Losses:</span>
                <span className="text-amber-400 font-bold">{result.lost_channel ?? 0} Packets</span>
              </div>

              {/* Navigation button to compare */}
              <button
                type="button"
                onClick={() => navigate('/results')}
                className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-white/[0.05] hover:bg-white/[0.08] text-xs font-bold text-slate-200 border border-white/[0.1] transition-colors"
              >
                <BarChart3 className="w-3.5 h-3.5 text-cyan-400" />
                <span>Open in Results & Analytics Dashboard</span>
                <ArrowRight className="w-3.5 h-3.5 text-slate-400" />
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
