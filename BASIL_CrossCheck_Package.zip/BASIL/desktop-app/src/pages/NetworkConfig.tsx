import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  Network,
  PlusCircle,
  Trash2,
  Sliders,
  Layers,
  Sparkles,
  Info,
  Check,
  Radio,
  Eye,
} from 'lucide-react';
import { getNetworkConfigs, createNetworkConfig, deleteNetworkConfig } from '../api/client';
import type { NetworkConfig } from '../types';

const defaultForm = {
  name: '',
  num_devices: 4,
  room_width: 5,
  room_height: 3, // Room height in meters
  ap_power: 100,  // AP Optical power in Watts
  half_angle: 60, // Semi-angle at half power in degrees
  data_rate_mbps: 20,
};

const PRESETS = [
  {
    title: 'Standard Office Cell',
    desc: '4.0m × 3.0m cell, 3 devices, 100W AP, 20 Mbps rate',
    values: { name: 'Standard Office Cell', num_devices: 3, room_width: 4, room_height: 3, ap_power: 100, half_angle: 60, data_rate_mbps: 20 }
  },
  {
    title: 'High-Density Conference',
    desc: '6.0m × 6.0m cell, 8 devices, 200W AP, 50 Mbps rate',
    values: { name: 'High-Density Conference', num_devices: 8, room_width: 6, room_height: 3.5, ap_power: 200, half_angle: 70, data_rate_mbps: 50 }
  },
  {
    title: 'Attenuation Gradient Stress',
    desc: '5.0m × 5.0m cell, 5 devices spanning strong SNR to PER=1.0 edge',
    values: { name: 'Attenuation Gradient Stress', num_devices: 5, room_width: 5, room_height: 3, ap_power: 50, half_angle: 45, data_rate_mbps: 20 }
  }
];

export default function NetworkConfigPage() {
  const [configs, setConfigs] = useState<NetworkConfig[]>([]);
  const [form, setForm] = useState(defaultForm);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [selectedDevice, setSelectedDevice] = useState<number | null>(null);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const load = async () => {
    setLoading(true);
    try {
      const data = await getNetworkConfigs();
      setConfigs(data);
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : 'Failed to load configurations');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  // Compute physical optical channel characteristics for simulated devices
  const devicePositions = useMemo(() => {
    const devices = [];
    const count = Math.max(1, Math.min(20, form.num_devices));
    const h = form.room_height;
    const apX = form.room_width / 2;
    const apY = form.room_width / 2;
    const phiHalfRad = (form.half_angle * Math.PI) / 180;
    const m = -Math.log(2) / Math.log(Math.cos(phiHalfRad));

    for (let i = 0; i < count; i++) {
      // Position devices in a spiral distribution around the room center
      const angle = (i * 2.39996) + 0.5; // Golden angle
      const maxR = (form.room_width / 2) * 0.85;
      const r = Math.sqrt((i + 1) / count) * maxR;
      const x = apX + r * Math.cos(angle);
      const y = apY + r * Math.sin(angle);
      const dist = Math.sqrt(r * r + h * h);
      const cosPhi = h / dist;
      const incidenceRad = Math.acos(cosPhi);
      const incidenceDeg = (incidenceRad * 180) / Math.PI;

      // Optical Channel DC Gain H(0) = ((m+1)*A)/(2*pi*d^2) * cos^m(phi) * cos(psi)
      const Ar = 1e-4; // 1 cm^2 photodiode area
      const Ts = 1.0;
      const g = 1.5; // Concentrator gain
      let H0 = 0;
      if (incidenceDeg <= 70) {
        H0 = ((m + 1) * Ar) / (2 * Math.PI * dist * dist) * Math.pow(cosPhi, m) * Ts * g * cosPhi;
      }

      // Received optical power & SNR calculation
      const P_tx = form.ap_power;
      const P_rx = P_tx * H0;
      const responsivity = 0.53; // A/W
      const I_sig = responsivity * P_rx;
      const noiseVariance = 1e-14; // Typical indoor VLC noise
      const snrLinear = (I_sig * I_sig) / noiseVariance;
      const snrDb = snrLinear > 0 ? 10 * Math.log10(snrLinear) : 0;

      // Bit Error Rate and Packet Error Rate (OOK)
      const ber = 0.5 * (1 - Math.tanh(Math.sqrt(Math.max(0, snrLinear / 2))));
      const packetBytes = 1024;
      const per = 1 - Math.pow(Math.max(0, 1 - ber), packetBytes * 8);

      devices.push({
        id: i,
        x: Number(x.toFixed(2)),
        y: Number(y.toFixed(2)),
        distance: Number(dist.toFixed(2)),
        incidenceDeg: Number(incidenceDeg.toFixed(1)),
        snrDb: Number(Math.max(0, Math.min(60, snrDb)).toFixed(1)),
        per: Number(Math.max(0, Math.min(1, per)).toFixed(4)),
      });
    }
    return devices;
  }, [form.num_devices, form.room_width, form.room_height, form.ap_power, form.half_angle]);

  // Render optical beam canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;
    ctx.clearRect(0, 0, width, height);

    // Coordinate mapping
    const padding = 35;
    const roomSize = form.room_width;
    const scale = (Math.min(width, height) - padding * 2) / roomSize;
    const originX = (width - roomSize * scale) / 2;
    const originY = (height - roomSize * scale) / 2;

    const toCanvasX = (rx: number) => originX + rx * scale;
    const toCanvasY = (ry: number) => originY + ry * scale;

    // 1. Draw room floor grid
    ctx.fillStyle = '#0c0f17';
    ctx.fillRect(originX, originY, roomSize * scale, roomSize * scale);
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.07)';
    ctx.lineWidth = 1;

    const gridDivs = Math.max(2, Math.round(roomSize));
    for (let i = 0; i <= gridDivs; i++) {
      const pos = i * (roomSize / gridDivs);
      ctx.beginPath();
      ctx.moveTo(toCanvasX(pos), originY);
      ctx.lineTo(toCanvasX(pos), originY + roomSize * scale);
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(originX, toCanvasY(pos));
      ctx.lineTo(originX + roomSize * scale, toCanvasY(pos));
      ctx.stroke();
    }

    // 2. Draw Optical Radiation Cone (Footprint on floor)
    const centerX = toCanvasX(roomSize / 2);
    const centerY = toCanvasY(roomSize / 2);
    const beamRadiusM = form.room_height * Math.tan((form.half_angle * Math.PI) / 180);
    const beamRadiusPx = beamRadiusM * scale;

    const radialGradient = ctx.createRadialGradient(centerX, centerY, 4, centerX, centerY, beamRadiusPx);
    radialGradient.addColorStop(0, 'rgba(56, 189, 248, 0.45)');
    radialGradient.addColorStop(0.5, 'rgba(56, 189, 248, 0.15)');
    radialGradient.addColorStop(0.85, 'rgba(99, 102, 241, 0.05)');
    radialGradient.addColorStop(1, 'rgba(99, 102, 241, 0)');

    ctx.fillStyle = radialGradient;
    ctx.beginPath();
    ctx.arc(centerX, centerY, beamRadiusPx, 0, Math.PI * 2);
    ctx.fill();

    // Beam perimeter circle
    ctx.strokeStyle = 'rgba(56, 189, 248, 0.4)';
    ctx.setLineDash([4, 4]);
    ctx.beginPath();
    ctx.arc(centerX, centerY, beamRadiusPx, 0, Math.PI * 2);
    ctx.stroke();
    ctx.setLineDash([]);

    // 3. Draw Rays to Devices & Device Nodes
    devicePositions.forEach((dev) => {
      const devX = toCanvasX(dev.x);
      const devY = toCanvasY(dev.y);
      const isSelected = selectedDevice === dev.id;

      // Optical Ray
      ctx.beginPath();
      ctx.moveTo(centerX, centerY);
      ctx.lineTo(devX, devY);
      ctx.strokeStyle = dev.per < 0.05
        ? 'rgba(52, 211, 153, 0.35)'
        : dev.per < 0.5
        ? 'rgba(251, 191, 36, 0.35)'
        : 'rgba(244, 63, 94, 0.35)';
      ctx.lineWidth = isSelected ? 2 : 1;
      ctx.stroke();

      // Device Circle
      ctx.beginPath();
      ctx.arc(devX, devY, isSelected ? 7 : 5, 0, Math.PI * 2);
      ctx.fillStyle = dev.per < 0.05 ? '#10b981' : dev.per < 0.5 ? '#f59e0b' : '#f43f5e';
      ctx.fill();
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = isSelected ? 2 : 1;
      ctx.stroke();

      // Device ID label
      ctx.font = '10px monospace';
      ctx.fillStyle = '#cbd5e1';
      ctx.fillText(`D${dev.id}`, devX + 8, devY - 4);
    });

    // 4. Draw Ceiling AP Emitter at Center
    ctx.beginPath();
    ctx.arc(centerX, centerY, 8, 0, Math.PI * 2);
    ctx.fillStyle = '#38bdf8';
    ctx.shadowColor = '#38bdf8';
    ctx.shadowBlur = 12;
    ctx.fill();
    ctx.shadowBlur = 0;
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 2;
    ctx.stroke();

    ctx.font = 'bold 10px monospace';
    ctx.fillStyle = '#ffffff';
    ctx.fillText('AP (LOS)', centerX - 22, centerY - 12);
  }, [form, devicePositions, selectedDevice]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim()) {
      setError('Please provide a name for this network configuration');
      return;
    }
    setSaving(true);
    setError(null);
    setSuccess(null);
    try {
      await createNetworkConfig({
        name: form.name.trim(),
        num_devices: form.num_devices,
        room_width: form.room_width,
        room_height: form.room_height,
        ap_power: form.ap_power,
        half_angle: form.half_angle,
        data_rate_mbps: form.data_rate_mbps,
      });
      setSuccess(`Configuration "${form.name.trim()}" saved successfully.`);
      await load();
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : 'Save failed');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: number) => {
    try {
      await deleteNetworkConfig(id);
      await load();
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : 'Delete failed');
    }
  };

  return (
    <div className="space-y-8">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2.5">
            <Network className="text-cyan-400 w-6 h-6" />
            Optical Li-Fi Network Designer
          </h1>
          <p className="text-sm text-slate-400 mt-1">
            Configure indoor optical wireless cell geometry, Lambertian emitters, and multi-device photodiode coordinates.
          </p>
        </div>

        {/* Quick Presets */}
        <div className="flex items-center gap-2">
          {PRESETS.map((p, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => setForm(p.values)}
              className="px-3 py-1.5 rounded-lg bg-white/[0.04] hover:bg-cyan-500/10 border border-white/[0.08] hover:border-cyan-500/30 text-xs font-semibold text-slate-300 hover:text-cyan-300 transition-colors flex items-center gap-1.5"
            >
              <Sparkles className="w-3 h-3 text-cyan-400" />
              <span>{p.title}</span>
            </button>
          ))}
        </div>
      </div>

      {error && (
        <div className="bg-rose-950/50 border border-rose-700/60 rounded-xl p-4 text-rose-300 text-sm flex items-center gap-2">
          <Info className="w-4 h-4 flex-shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {success && (
        <div className="bg-emerald-950/50 border border-emerald-700/60 rounded-xl p-4 text-emerald-300 text-sm flex items-center gap-2">
          <Check className="w-4 h-4 flex-shrink-0" />
          <span>{success}</span>
        </div>
      )}

      {/* Main Grid: Designer Left + Visual Canvas Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Form Controls */}
        <div className="lg:col-span-6 space-y-6">
          <form onSubmit={handleSubmit} className="glass-panel rounded-2xl p-6 space-y-5">
            <div className="flex items-center justify-between border-b border-white/[0.06] pb-4">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-2">
                <Sliders className="w-4 h-4 text-cyan-400" /> Physical Parameters
              </span>
              <span className="text-[10px] font-mono text-cyan-400 bg-cyan-950/50 px-2 py-0.5 rounded border border-cyan-800/40">
                Lambertian Line-of-Sight
              </span>
            </div>

            {/* Config Name */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">Configuration Name</label>
              <input
                type="text"
                value={form.name}
                placeholder="e.g., Office Room 4-Device Test"
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                className="w-full bg-slate-900/80 border border-white/[0.1] rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 transition-colors"
              />
            </div>

            {/* Slider Parameters */}
            <div className="grid grid-cols-2 gap-4">
              {/* Number of Devices */}
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-400 font-medium">User Devices</span>
                  <span className="font-mono text-cyan-400 font-bold">{form.num_devices}</span>
                </div>
                <input
                  type="range"
                  min={1}
                  max={16}
                  value={form.num_devices}
                  onChange={(e) => setForm({ ...form, num_devices: Number(e.target.value) })}
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>

              {/* Data Rate */}
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-400 font-medium">PHY Channel Rate</span>
                  <span className="font-mono text-cyan-400 font-bold">{form.data_rate_mbps} Mbps</span>
                </div>
                <input
                  type="range"
                  min={5}
                  max={100}
                  step={5}
                  value={form.data_rate_mbps}
                  onChange={(e) => setForm({ ...form, data_rate_mbps: Number(e.target.value) })}
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>
            </div>

            {/* Optical AP Controls */}
            <div className="grid grid-cols-2 gap-4">
              {/* AP Transmit Power */}
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-400 font-medium">AP Optical Power</span>
                  <span className="font-mono text-indigo-400 font-bold">{form.ap_power} W</span>
                </div>
                <input
                  type="range"
                  min={10}
                  max={500}
                  step={10}
                  value={form.ap_power}
                  onChange={(e) => setForm({ ...form, ap_power: Number(e.target.value) })}
                  className="w-full accent-indigo-400 cursor-pointer"
                />
              </div>

              {/* Semi-angle */}
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-400 font-medium">Semi-Angle (Φ½)</span>
                  <span className="font-mono text-indigo-400 font-bold">{form.half_angle}°</span>
                </div>
                <input
                  type="range"
                  min={15}
                  max={85}
                  value={form.half_angle}
                  onChange={(e) => setForm({ ...form, half_angle: Number(e.target.value) })}
                  className="w-full accent-indigo-400 cursor-pointer"
                />
              </div>
            </div>

            {/* Room Dimensions */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1">Room Width (m)</label>
                <input
                  type="number"
                  min={2}
                  max={20}
                  value={form.room_width}
                  onChange={(e) => setForm({ ...form, room_width: Number(e.target.value) })}
                  className="w-full bg-slate-900/80 border border-white/[0.1] rounded-xl px-3 py-2 text-sm text-white"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1">Ceiling Height (m)</label>
                <input
                  type="number"
                  min={2}
                  max={6}
                  step={0.5}
                  value={form.room_height}
                  onChange={(e) => setForm({ ...form, room_height: Number(e.target.value) })}
                  className="w-full bg-slate-900/80 border border-white/[0.1] rounded-xl px-3 py-2 text-sm text-white"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={saving}
              className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white font-bold py-3 rounded-xl shadow-lg shadow-cyan-500/20 transition-all disabled:opacity-50"
            >
              <PlusCircle className="w-4 h-4" />
              <span>{saving ? 'Saving Topology…' : 'Save Topology Configuration'}</span>
            </button>
          </form>

          {/* Saved Configurations List */}
          <div className="glass-panel rounded-2xl p-5 space-y-3">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Saved Configurations ({configs.length})
            </span>
            {loading ? (
              <p className="text-xs text-slate-500 py-3">Loading topologies…</p>
            ) : configs.length === 0 ? (
              <p className="text-xs text-slate-500 py-3">No custom topologies saved. Create one above.</p>
            ) : (
              <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                {configs.map((c) => (
                  <div
                    key={c.id}
                    className="flex items-center justify-between p-3 rounded-xl bg-white/[0.02] hover:bg-white/[0.05] border border-white/[0.04] text-xs transition-colors"
                  >
                    <div>
                      <div className="font-semibold text-slate-200">{c.name}</div>
                      <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                        {c.num_devices} devices | {c.room_width}m × {c.room_height}m | {c.ap_power}W | {c.data_rate_mbps} Mbps
                      </div>
                    </div>
                    <button
                      onClick={() => handleDelete(c.id)}
                      className="p-1.5 text-slate-500 hover:text-rose-400 transition-colors"
                      title="Delete configuration"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Live Optical Cell Visualizer Canvas */}
        <div className="lg:col-span-6 space-y-4">
          <div className="glass-panel rounded-2xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-white/[0.06] pb-3">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
                <Eye className="w-4 h-4 text-cyan-400" /> Real-Time Optical Cell Footprint
              </span>
              <span className="text-[10px] font-mono text-slate-400 flex items-center gap-1.5">
                <Radio className="w-3 h-3 text-emerald-400 animate-pulse" /> Live Ray-Tracing
              </span>
            </div>

            {/* Interactive Canvas */}
            <div className="relative flex items-center justify-center bg-black/40 rounded-xl border border-white/[0.05] p-2">
              <canvas
                ref={canvasRef}
                width={460}
                height={360}
                className="rounded-lg shadow-inner cursor-crosshair"
              />
            </div>

            {/* Legend & Channel Math Explanation */}
            <div className="flex items-center justify-between text-[11px] text-slate-400 px-2 font-mono">
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400" /> PER &lt; 5% (Strong)
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-amber-400" /> 5% - 50% (Moderate)
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-500" /> PER &gt; 50% (Edge Outage)
              </span>
            </div>

            {/* Device Physical Telemetry Grid */}
            <div className="pt-2 border-t border-white/[0.06] space-y-2">
              <div className="text-[11px] font-bold text-slate-300 uppercase tracking-wider flex items-center justify-between">
                <span>Calculated Physical Channel Telemetry</span>
                <span className="text-[10px] font-normal text-slate-400">Click a node to inspect</span>
              </div>
              <div className="grid grid-cols-2 gap-2 max-h-40 overflow-y-auto pr-1">
                {devicePositions.map((d) => (
                  <button
                    key={d.id}
                    type="button"
                    onClick={() => setSelectedDevice(selectedDevice === d.id ? null : d.id)}
                    className={`p-2.5 rounded-xl border text-left transition-all text-xs font-mono ${
                      selectedDevice === d.id
                        ? 'bg-cyan-500/15 border-cyan-400 text-white'
                        : 'bg-white/[0.02] border-white/[0.05] text-slate-300 hover:border-white/[0.15]'
                    }`}
                  >
                    <div className="flex items-center justify-between font-bold">
                      <span>Device #{d.id}</span>
                      <span className={d.per < 0.05 ? 'text-emerald-400' : d.per < 0.5 ? 'text-amber-400' : 'text-rose-400'}>
                        SNR {d.snrDb} dB
                      </span>
                    </div>
                    <div className="text-[10px] text-slate-400 mt-1 flex justify-between">
                      <span>Dist: {d.distance}m</span>
                      <span>PER: {(d.per * 100).toFixed(1)}%</span>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
