use std::net::{SocketAddr, TcpStream};
use std::path::PathBuf;
use std::process::{Child, Command};
use std::sync::{Arc, Mutex};
use std::time::Duration;
use tauri::{State, WindowEvent};

#[cfg(target_os = "windows")]
use std::os::windows::process::CommandExt;

#[cfg(target_os = "windows")]
const CREATE_NO_WINDOW: u32 = 0x08000000;

#[derive(serde::Serialize, Clone)]
pub struct SystemStatus {
    pub backend_online: bool,
    pub authentic_basil: bool,
    pub backend_url: String,
    pub python_available: bool,
    pub wsl_available: bool,
    pub ns3_available: bool,
    pub message: String,
}

pub struct AppState {
    pub backend_process: Arc<Mutex<Option<Child>>>,
}

/// Probes the HTTP endpoint directly and returns (port_open, is_authentic_basil)
fn check_basil_health(addr: &str, timeout_ms: u64) -> (bool, bool) {
    let socket_addr = match addr.parse::<SocketAddr>() {
        Ok(a) => a,
        Err(_) => return (false, false),
    };

    let mut stream = match TcpStream::connect_timeout(&socket_addr, Duration::from_millis(timeout_ms)) {
        Ok(s) => s,
        Err(_) => return (false, false),
    };

    let _ = stream.set_read_timeout(Some(Duration::from_millis(timeout_ms)));
    let _ = stream.set_write_timeout(Some(Duration::from_millis(timeout_ms)));

    use std::io::{Read, Write};
    let req = "GET /health HTTP/1.1\r\nHost: 127.0.0.1:8000\r\nConnection: close\r\n\r\n";
    if stream.write_all(req.as_bytes()).is_err() {
        return (true, false);
    }

    let mut buf = [0u8; 1024];
    if let Ok(n) = stream.read(&mut buf) {
        let text = String::from_utf8_lossy(&buf[..n]);
        let is_basil = text.contains("200 OK") && (text.contains("\"status\":\"ok\"") || text.contains("\"message\":\"BASIL API\""));
        (true, is_basil)
    } else {
        (true, false)
    }
}

fn wait_for_backend_ready(max_attempts: usize, interval_ms: u64) -> bool {
    for _ in 0..max_attempts {
        let (_, is_basil) = check_basil_health("127.0.0.1:8000", 300);
        if is_basil {
            return true;
        }
        std::thread::sleep(Duration::from_millis(interval_ms));
    }
    false
}

fn get_app_data_directory() -> PathBuf {
    if let Ok(dir) = std::env::var("BASIL_DATA_DIR") {
        let p = PathBuf::from(dir);
        let _ = std::fs::create_dir_all(&p);
        return p;
    }
    if let Ok(local_app_data) = std::env::var("LOCALAPPDATA") {
        let p = PathBuf::from(local_app_data).join("BASIL").join("data");
        let _ = std::fs::create_dir_all(&p);
        return p;
    }
    let p = PathBuf::from("data");
    let _ = std::fs::create_dir_all(&p);
    p
}

fn find_backend_directory() -> PathBuf {
    if let Ok(dir) = std::env::var("BASIL_BACKEND_DIR") {
        let p = PathBuf::from(dir);
        if p.exists() && p.join("app").exists() {
            return p;
        }
    }

    if let Ok(mut exe) = std::env::current_exe() {
        exe.pop();
        for sub in &[
            "resources/backend",
            "backend",
            "resources",
            "../resources/backend",
            "../backend",
            "../../backend",
            "../../../backend",
        ] {
            let candidate = exe.join(sub);
            if candidate.exists() && candidate.join("app").exists() {
                return candidate;
            }
        }
    }

    // Relative to working directory
    for candidate_str in &[
        "resources/backend",
        "backend",
        "../backend",
        "../../backend",
        "BASIL/backend",
    ] {
        let p = PathBuf::from(candidate_str);
        if p.exists() && p.join("app").exists() {
            return p;
        }
    }

    PathBuf::from("backend")
}

fn spawn_uvicorn_backend() -> Result<Child, String> {
    let backend_dir = find_backend_directory();
    let data_dir = get_app_data_directory();
    let mut cmd = Command::new("python");
    cmd.args(["-m", "uvicorn", "app.main:app", "--host", "127.0.0.1", "--port", "8000"])
        .current_dir(&backend_dir)
        .env("BASIL_DATA_DIR", &data_dir)
        .env("BASIL_INSTALLED_MODE", "1");

    #[cfg(target_os = "windows")]
    cmd.creation_flags(CREATE_NO_WINDOW);

    cmd.spawn()
        .map_err(|e| format!("Failed to spawn Python FastAPI backend: {}", e))
}

fn kill_backend_process(child_opt: &mut Option<Child>) {
    // Only terminates a child process that this specific BASIL instance spawned
    if let Some(mut child) = child_opt.take() {
        let pid = child.id();
        let _ = child.kill();
        let _ = child.wait();

        #[cfg(target_os = "windows")]
        {
            let mut kill_cmd = Command::new("taskkill");
            kill_cmd.args(["/F", "/T", "/PID", &pid.to_string()]);
            kill_cmd.creation_flags(CREATE_NO_WINDOW);
            let _ = kill_cmd.output();
        }
    }
}

#[tauri::command]
fn check_system_status() -> SystemStatus {
    let (port_open, authentic_basil) = check_basil_health("127.0.0.1:8000", 300);

    let python_available = {
        let mut cmd = Command::new("python");
        cmd.arg("--version");
        #[cfg(target_os = "windows")]
        cmd.creation_flags(CREATE_NO_WINDOW);
        cmd.output().is_ok()
    };

    let wsl_available = {
        let mut cmd = Command::new("wsl");
        cmd.args(["--status"]);
        #[cfg(target_os = "windows")]
        cmd.creation_flags(CREATE_NO_WINDOW);
        cmd.output().map(|o| o.status.success()).unwrap_or(false)
    };

    let ns3_available = wsl_available && {
        let mut cmd = Command::new("wsl");
        cmd.args(["bash", "-c", "test -d /home -o -d /mnt/c"]);
        #[cfg(target_os = "windows")]
        cmd.creation_flags(CREATE_NO_WINDOW);
        cmd.output().map(|o| o.status.success()).unwrap_or(false)
    };

    let message = if authentic_basil {
        "FastAPI Backend is online and verified as authentic BASIL API on port 8000.".to_string()
    } else if port_open {
        "Port 8000 is open but responded with unexpected signature (foreign service detected).".to_string()
    } else if python_available {
        "FastAPI Backend is currently starting up...".to_string()
    } else {
        "Python environment not detected. Please verify Python 3.10+ is in PATH.".to_string()
    };

    SystemStatus {
        backend_online: authentic_basil,
        authentic_basil,
        backend_url: "http://127.0.0.1:8000".to_string(),
        python_available,
        wsl_available,
        ns3_available,
        message,
    }
}

#[tauri::command]
fn start_backend(state: State<AppState>) -> Result<String, String> {
    let (port_open, authentic_basil) = check_basil_health("127.0.0.1:8000", 250);
    if authentic_basil {
        return Ok("Backend is already running authentic BASIL API on port 8000".to_string());
    }
    if port_open {
        return Err("Port 8000 is occupied by an unrelated non-BASIL service. BASIL will not interfere with this process.".to_string());
    }

    let mut lock = state.backend_process.lock().map_err(|e| e.to_string())?;
    if lock.is_none() {
        let child = spawn_uvicorn_backend()?;
        *lock = Some(child);
        if wait_for_backend_ready(30, 200) {
            Ok("Started FastAPI backend process and verified health endpoint".to_string())
        } else {
            Ok("Backend process spawned; initializing...".to_string())
        }
    } else {
        Ok("Backend process handle already exists".to_string())
    }
}

#[tauri::command]
fn stop_backend(state: State<AppState>) -> Result<String, String> {
    let mut lock = state.backend_process.lock().map_err(|e| e.to_string())?;
    if lock.is_some() {
        kill_backend_process(&mut *lock);
        Ok("BASIL-owned backend process terminated cleanly".to_string())
    } else {
        Ok("No BASIL-owned backend process was running (unrelated services left untouched)".to_string())
    }
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    let backend_proc = Arc::new(Mutex::new(None));
    let proc_for_setup = Arc::clone(&backend_proc);
    let proc_for_events = Arc::clone(&backend_proc);

    tauri::Builder::default()
        .manage(AppState {
            backend_process: backend_proc,
        })
        .invoke_handler(tauri::generate_handler![
            check_system_status,
            start_backend,
            stop_backend
        ])
        .setup(move |_app| {
            let (port_open, authentic_basil) = check_basil_health("127.0.0.1:8000", 250);
            if !port_open && !authentic_basil {
                if let Ok(child) = spawn_uvicorn_backend() {
                    if let Ok(mut lock) = proc_for_setup.lock() {
                        *lock = Some(child);
                    }
                }
            }
            Ok(())
        })
        .on_window_event(move |_window, event| {
            if let WindowEvent::Destroyed = event {
                if let Ok(mut lock) = proc_for_events.lock() {
                    kill_backend_process(&mut *lock);
                }
            }
        })
        .run(tauri::generate_context!())
        .expect("error while running BASIL Tauri application");
}
