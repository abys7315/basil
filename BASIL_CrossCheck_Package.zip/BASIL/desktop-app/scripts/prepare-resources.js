import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const desktopRoot = path.resolve(__dirname, '..');
const repoRoot = path.resolve(desktopRoot, '..');
const targetResourcesDir = path.resolve(desktopRoot, 'src-tauri', 'resources');

console.log('--- Preparing Tauri Bundled Resources ---');
console.log(`Repo Root: ${repoRoot}`);
console.log(`Target Resources: ${targetResourcesDir}`);

// Clean target directory
if (fs.existsSync(targetResourcesDir)) {
  fs.rmSync(targetResourcesDir, { recursive: true, force: true });
}
fs.mkdirSync(targetResourcesDir, { recursive: true });

function copyDirRecursive(src, dest, ignoreDirs = ['__pycache__', '.pytest_cache']) {
  fs.mkdirSync(dest, { recursive: true });
  const entries = fs.readdirSync(src, { withFileTypes: true });
  for (const entry of entries) {
    if (ignoreDirs.includes(entry.name)) continue;
    const srcPath = path.join(src, entry.name);
    const destPath = path.join(dest, entry.name);
    if (entry.isDirectory()) {
      copyDirRecursive(srcPath, destPath, ignoreDirs);
    } else {
      fs.copyFileSync(srcPath, destPath);
    }
  }
}

// 1. Copy backend app source code
const backendSrc = path.join(repoRoot, 'backend', 'app');
const backendDest = path.join(targetResourcesDir, 'backend', 'app');
console.log(`Copying backend/app -> ${backendDest}`);
copyDirRecursive(backendSrc, backendDest);

// 2. Copy backend requirements and CLI tools
const filesToCopy = [
  { src: path.join(repoRoot, 'backend', 'requirements.txt'), dest: path.join(targetResourcesDir, 'backend', 'requirements.txt') },
  { src: path.join(repoRoot, 'backend', 'check_dependencies.py'), dest: path.join(targetResourcesDir, 'backend', 'check_dependencies.py') },
];

for (const { src, dest } of filesToCopy) {
  if (fs.existsSync(src)) {
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    fs.copyFileSync(src, dest);
    console.log(`Copied ${path.basename(src)} -> ${dest}`);
  }
}

// 3. Copy seed SQLite template database if available
const seedDb = path.join(repoRoot, 'experiments', 'basil.db');
const destDb = path.join(targetResourcesDir, 'backend', 'basil.db');
if (fs.existsSync(seedDb)) {
  fs.mkdirSync(path.dirname(destDb), { recursive: true });
  fs.copyFileSync(seedDb, destDb);
  console.log(`Copied seed database -> ${destDb}`);
}

// 4. Copy standalone C++ prototype simulator
const simExe = path.join(repoRoot, 'ns3-lifi', 'scratch', 'basil-sim.exe');
const destSimExe = path.join(targetResourcesDir, 'ns3-lifi', 'scratch', 'basil-sim.exe');
if (fs.existsSync(simExe)) {
  fs.mkdirSync(path.dirname(destSimExe), { recursive: true });
  fs.copyFileSync(simExe, destSimExe);
  console.log(`Copied simulator binary -> ${destSimExe}`);
}

console.log('--- Resource Preparation Complete ---');
