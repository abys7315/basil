# BASIL Desktop & Web Frontend

Interactive web and desktop user interface for the **BASIL** (Burst-Aware Semantic Intelligence for Li-Fi) simulation platform. Built with **React 18**, **TypeScript**, **Tailwind CSS**, and **Vite**, with optional desktop bundling via **Tauri**.

---

## Prerequisites

- **Node.js**: >= 16.0.0 (LTS recommended)
- **npm**: >= 8.0.0

---

## Installation

```bash
# From desktop-app directory
npm install
```

---

## Development

Start the local Vite development server:

```bash
npm run dev
```

- Accessible at: `http://localhost:5173`
- API Proxy: Automatically proxies `/api` calls to `http://localhost:8000`. Ensure the backend server is running concurrently.

---

## Production Build

Compile TypeScript and build optimized static assets:

```bash
npm run build
```

The output bundle is generated in the `dist/` directory.

To preview the production build locally:

```bash
npm run preview
```

---

## Features

- **Dashboard**: Live queue status and experiment history cards.
- **Configuration Studio**: Visual designer for indoor Li-Fi rooms, AP optical parameters, and multi-user traffic generators.
- **Analytics & Plots**: Interactive throughput-over-time graphs and per-device latency distributions powered by Plotly.
- **Comparative Analysis**: Multi-experiment performance benchmarking table (FIFO vs. RR vs. SP vs. BASIL-PSA).
