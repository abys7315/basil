# BASIL Phase 4.1 — Deployment Readiness and Windows Installer Report

**Milestone:** Phase 4.1 (Windows Installer, Runtime Validation, and Deployment Readiness)  
**Date:** November 14, 2026  
**Product Name:** BASIL  
**Version:** 4.1.0  
**Status:** COMPLETE (All 5 E2E Tests Passed, 17/17 Dependencies Verified, 45/45 Unit/Integration Tests Passed)

---

## Executive Summary

Phase 4.1 transitions the BASIL Li-Fi research platform into a production-grade, distributable Windows desktop application. Building upon the frozen research algorithms (BASIL-PSA and BASIL-OPT) and reconciled Phase 3.5 benchmark datasets, Phase 4.1 successfully generates a verified, self-contained **NSIS Windows Installer (`.exe`)**, implements an exhaustive **Runtime Dependency Checker**, secures **robust backend lifecycle management** with foreign process protection, and validates real desktop execution across 5 end-to-end integration tests (Tests A–E).

---

## 1. Windows Production Installer

Tauri 2 production bundling was configured for 64-bit Windows environments using the NSIS (`Nullsoft Scriptable Install System`) engine. The installer executable was compiled, packaged, and verified on disk:

* **Installer Executable:** `desktop-app/src-tauri/target/release/bundle/nsis/BASIL_4.1.0_x64-setup.exe`
* **Product Name:** `BASIL`
* **Version:** `4.1.0`
* **Package Format:** Single-file self-extracting NSIS Setup Executable (.exe)
* **File Size:** `3,310,866 bytes` (3.16 MiB)
* **SHA-256 Checksum:** `AC7FA5A9F8821A3991E42B19048503B89142710F354F653C9D7252919BC66A93`
* **Default Installation Target:** `%LOCALAPPDATA%\Programs\BASIL` (CurrentUser install mode; requires no administrative UAC elevation)
* **Application Binary:** `basil.exe` (10,291,712 bytes / 9.81 MiB)
* **Start Menu Integration:** `%APPDATA%\Microsoft\Windows\Start Menu\Programs\BASIL.lnk`
* **Uninstaller Binary:** `%LOCALAPPDATA%\Programs\BASIL\uninstall.exe` (79,187 bytes)

### Installation & Uninstallation Verification
1. **Silent Installation Test:** Executed `BASIL_4.1.0_x64-setup.exe /S /D=<test_dir>`. Verified installation of `basil.exe`, `uninstall.exe`, and generation of the Windows Start Menu shortcut.
2. **Silent Uninstallation Test:** Executed `uninstall.exe /S`. Verified complete and clean removal of `basil.exe`, runtime resources, and the Start Menu shortcut without orphaned artifacts.

---

## 2. Runtime Dependency Validation Suite

To eliminate deployment friction and provide immediate diagnostics on end-user machines, a comprehensive startup dependency validator was created in `backend/app/services/dependency_checker.py`, exposed via REST API (`GET /api/system/dependencies`), and made executable via standalone CLI (`python backend/check_dependencies.py`).

The checker categorizes every prerequisite, detects whether it is operational, missing, or incompatible, and outputs actionable remediation steps:

| Prerequisite | Category | Required Specification | Detected / Verified | Status |
|---|---|---|---|---|
| **Microsoft Edge WebView2** | Host Runtime | Evergreen Runtime | Version `157.0.4341.46` | **INSTALLED** |
| **Python Runtime** | Host Runtime | Python >= 3.10 64-bit | Python `3.10.11` (64bit) | **INSTALLED** |
| **Rust / Cargo** | Toolchain | Runtime: NOT REQUIRED | Native binary; Rust only for build | **NOT REQUIRED** |
| **fastapi** | Python Package | >= 0.100.0 | Version `0.109.2` | **INSTALLED** |
| **uvicorn** | Python Package | >= 0.20.0 | Version `0.27.1` | **INSTALLED** |
| **sqlalchemy** | Python Package | >= 2.0.0 | Version `2.0.25` | **INSTALLED** |
| **aiosqlite** | Python Package | >= 0.18.0 | Version `0.22.1` | **INSTALLED** |
| **pydantic** | Python Package | >= 2.0.0 | Version `2.13.5` | **INSTALLED** |
| **pandas** | Python Package | >= 2.0.0 | Version `2.2.0` | **INSTALLED** |
| **numpy** | Python Package | >= 1.24.0 | Version `1.26.4` | **INSTALLED** |
| **scipy** | Python Package | >= 1.10.0 | Version `1.15.3` | **INSTALLED** |
| **highspy** | Python Package | >= 1.5.0 | Version `1.16.0` | **INSTALLED** |
| **pytest** | Python Package | >= 7.0.0 | Version `9.1.1` | **INSTALLED** |
| **WSL2 Subsystem** | Simulation | Windows Subsystem for Linux 2 | WSL2 Kernel Operational | **INSTALLED** |
| **Ubuntu Distribution** | Simulation | Ubuntu 22.04 / 24.04 in WSL | `Ubuntu 24.04.3 LTS` | **INSTALLED** |
| **ns-3.42 Li-Fi Simulator** | Simulation | ns3.42-basil-ns3-sim | `/opt/ns3/ns-allinone-3.42/...` | **INSTALLED** |
| **Filesystem Writability** | Storage | R/W on backend & DB dirs | `BASIL/backend` R/W verified | **INSTALLED** |

**Summary:** 17/17 dependency checks passed. Missing: 0, Incompatible: 0.

---

## 3. Backend Lifecycle Reliability & Process Isolation

The Tauri Rust lifecycle manager in `desktop-app/src-tauri/src/lib.rs` was audited and hardened:
1. **Authentic HTTP Signature Probing:** Replaced raw TCP socket checks with direct HTTP health probing (`GET /health`). The probe inspects the HTTP response for `200 OK` and the authentic payload signature `{"status":"ok"}` or `{"message":"BASIL API"}`.
2. **Foreign Process Conflict Protection:** If port 8000 is occupied by an unrelated foreign service, BASIL detects the mismatched response signature, refuses to terminate or hijack the foreign process, and surfaces an informative notification to the user.
3. **PID-Scoped Child Termination:** The Tauri host tracks the exact child `process::Child` PID tree spawned by BASIL. Only processes spawned by the current BASIL session are terminated on window closure (`WindowEvent::Destroyed`), preventing orphaned background Python processes or collateral process termination.
4. **Data Isolation:** Simulation logs and SQLite databases are safely isolated in `BASIL/experiments/basil.db` with guaranteed transactional commits.

---

## 4. Real Desktop End-to-End Testing (Tests A–E)

The real end-to-end verification suite (`tests/verify_phase4_1_e2e.py`) was executed against the running desktop application stack. All 5 test gates passed:

```
================================================================================
BASIL Phase 4.1: Real Desktop End-to-End Testing & Deployment Verification
Timestamp: 2026-11-14T11:46:49.193581Z
================================================================================

--- Running Test A: Backend Lifecycle & Health Reporting ---
Test A PASSED in 5.072s

--- Running Test B: Normal Simulation (ns-3 via WSL) ---
Test B PASSED in 0.577s (PDR: 1.0000, Throughput: 1.27 Mbps)

--- Running Test C: BASIL-PSA and BASIL-OPT ---
Test C PASSED in 26.239s (PSA Throughput: 1.27 Mbps, OPT Throughput: 1.27 Mbps)

--- Running Test D: Results Comparison and CSV/JSON Export ---
Test D PASSED in 0.241s

--- Running Test E: Restart and Persistence Verification ---
Test E PASSED in 0.081s

================================================================================
Validation successfully completed! Saved results to PHASE4_1_VALIDATION_RESULTS.json
================================================================================
```

### Detailed Breakdown of Tests:

* **Test A (Backend Lifecycle):**
  * HTTP endpoints `GET /health` and `GET /api/health` returned HTTP 200 with authentic signature `{"status": "ok"}`.
  * Dependency checker endpoint `GET /api/system/dependencies` returned 200 with `all_ready: true` (17/17 passed).

* **Test B (Normal Simulation via ns-3 WSL):**
  * Configured a 3-device optical cell in a 4.0m × 3.0m room with 100W AP optical power and 20 Mbps channel rate.
  * Generated Poisson traffic (50 pkts/s, 1024-byte packets) and executed FIFO scheduling in ns-3.42 via WSL Ubuntu.
  * Results verified: 100% PDR, 1.27 Mbps throughput, 0.43 ms average latency, 3 devices tracked with distance and SNR gradient.

* **Test C (BASIL-PSA and BASIL-OPT Simulation):**
  * Configured bursty/mixed traffic (50 pkts/s normal, 200 pkts/s burst, burst ratio 0.3).
  * Executed online **BASIL-PSA**: ns-3.42 simulation completed in 0.56s (1.27 Mbps throughput, 0.43 ms latency, 0 deadline misses).
  * Executed offline **BASIL-OPT**: HiGHS 1.16.0 MILP solver executed and reached proven optimality (objective 242.00, 1.27 Mbps throughput, 0 deadline misses).

* **Test D (Results Comparison and CSV/JSON Export Parity):**
  * Compared FIFO, BASIL-PSA, and BASIL-OPT simultaneously via `GET /api/results/compare?ids=35,36,37`.
  * Verified all Phase 3.5 standardized research metric labels in both CSV and JSON exports:
    * `Scheduling Coverage (%)`
    * `Realized Received PDR (%)`
    * `Expected Received PDR (%)`
    * `Realized Goodput Efficiency (%)`
    * `Scheduling Deadline Misses`
    * `End-to-End Deadline Failures`
    * `Optical Channel Losses`
  * Validated that exported CSV and JSON values exactly match SQLite database records within 0.001 tolerance.

* **Test E (Restart and Persistence Verification):**
  * Captured simulation state for experiment 36, simulated application restart with re-initialization of the database connection.
  * Retrieved persisted records: 100% data integrity verified (identical experiment ID, completed status, throughput, PDR, and per-device statistics).

---

## 5. Test Suite Summary

The entire backend test suite now contains **45 automated tests** across 9 test modules:

```
tests/test_api.py (6 passed)
tests/test_basil_opt.py (5 passed)
tests/test_basil_opt_accounting.py (4 passed)
tests/test_basil_opt_integrity.py (6 passed)
tests/test_channel_replay_order.py (3 passed)
tests/test_dependency_checker.py (3 passed)
tests/test_metric_parity.py (3 passed)
tests/test_ns3_sim.py (12 passed)
tests/test_packet_parity_audit.py (3 passed)
======================= 45 passed, 2 warnings in 53.67s =======================
```

---

## 6. Deliverables Reference

* **Windows Installer:** [BASIL_4.1.0_x64-setup.exe](file:///C:/Users/abys7/Downloads/BASIL-starter/BASIL/desktop-app/src-tauri/target/release/bundle/nsis/BASIL_4.1.0_x64-setup.exe)
* **Validation Results JSON:** [PHASE4_1_VALIDATION_RESULTS.json](file:///C:/Users/abys7/Downloads/BASIL-starter/BASIL/PHASE4_1_VALIDATION_RESULTS.json)
* **Installation Guide:** [WINDOWS_INSTALLATION_GUIDE.md](file:///C:/Users/abys7/Downloads/BASIL-starter/BASIL/WINDOWS_INSTALLATION_GUIDE.md)
* **Demo Runbook:** [DEMO_RUNBOOK.md](file:///C:/Users/abys7/Downloads/BASIL-starter/BASIL/DEMO_RUNBOOK.md)
* **Dependency CLI:** [check_dependencies.py](file:///C:/Users/abys7/Downloads/BASIL-starter/BASIL/backend/check_dependencies.py)
* **One-Click Launcher:** [start-desktop.bat](file:///C:/Users/abys7/Downloads/BASIL-starter/BASIL/start-desktop.bat)
