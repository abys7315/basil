import asyncio
import json
import os
import subprocess
import time
import urllib.request
import websockets
from pathlib import Path

async def test_cdp():
    print("Starting installed basil.exe with CDP...")
    env = os.environ.copy()
    env["WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS"] = "--remote-debugging-port=9222"
    
    proc = subprocess.Popen(
        ["C:\\BASIL_CleanInstall\\basil.exe"],
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    print(f"Spawned basil.exe PID {proc.pid}")

    try:
        # Wait for backend health and CDP
        t0 = time.time()
        backend_ready = False
        cdp_ready = False
        target_ws_url = None

        for _ in range(30):
            await asyncio.sleep(1)
            # Check backend
            if not backend_ready:
                try:
                    req = urllib.request.urlopen("http://127.0.0.1:8000/health", timeout=2)
                    if req.status == 200:
                        backend_ready = True
                        print("Backend /health is OK (200)")
                except Exception:
                    pass

            # Check CDP
            if not cdp_ready:
                try:
                    req = urllib.request.urlopen("http://127.0.0.1:9222/json", timeout=2)
                    targets = json.loads(req.read().decode("utf-8"))
                    for t in targets:
                        if t.get("type") == "page":
                            target_ws_url = t.get("webSocketDebuggerUrl")
                            cdp_ready = True
                            print(f"Found CDP target: {t.get('title')} ({t.get('url')})")
                            break
                except Exception:
                    pass

            if backend_ready and cdp_ready:
                break

        assert backend_ready, "Backend failed to start"
        assert cdp_ready, "CDP port 9222 failed to respond"

        print(f"Connecting to CDP WebSocket: {target_ws_url}")
        async with websockets.connect(target_ws_url) as ws:
            # Helper
            msg_id = 1
            async def call(method, params=None):
                nonlocal msg_id
                mid = msg_id
                msg_id += 1
                await ws.send(json.dumps({"id": mid, "method": method, "params": params or {}}))
                while True:
                    raw = await ws.recv()
                    data = json.loads(raw)
                    if data.get("id") == mid:
                        return data.get("result", {})

            await call("Page.enable")
            await call("Runtime.enable")

            # Evaluate location and title
            eval_res = await call("Runtime.evaluate", {"expression": "document.title"})
            print(f"Document Title from DOM: {eval_res.get('result', {}).get('value')}")

            eval_url = await call("Runtime.evaluate", {"expression": "window.location.href"})
            print(f"Window URL from DOM: {eval_url.get('result', {}).get('value')}")

            # Capture screenshot
            shots_dir = Path("experiments") / "screenshots"
            shots_dir.mkdir(parents=True, exist_ok=True)
            shot_res = await call("Page.captureScreenshot", {"format": "png"})
            import base64
            img_bytes = base64.b64decode(shot_res.get("data", ""))
            out_path = shots_dir / "test_cdp_installed_app.png"
            with open(out_path, "wb") as f:
                f.write(img_bytes)
            print(f"Captured screenshot to: {out_path} ({len(img_bytes)} bytes)")

    finally:
        print("Terminating basil.exe...")
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except Exception:
            proc.kill()
        print("Test CDP finished.")

if __name__ == "__main__":
    asyncio.run(test_cdp())
