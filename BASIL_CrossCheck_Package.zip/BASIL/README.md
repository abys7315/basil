# BASIL — Burst-Aware Semantic Intelligence for Li-Fi

> A comprehensive desktop simulation platform for researching, designing, and benchmarking packet scheduling algorithms over indoor optical wireless (Li-Fi) networks.

---

## 1. Project Overview

**BASIL** (**B**urst-**A**ware **S**emantic **I**ntelligence for **L**i-F**i**) provides a full-stack research environment to simulate physical optical wireless communications (Visible Light Communication / Li-Fi) under heterogeneous, bursty traffic.

Key features:
- **Hybrid ns-3.42 Li-Fi Simulator & C++ DES**: Standalone C++17 DES and authentic ns-3.42 Li-Fi integration modeling Lambertian optical emitters, photodiode receiver geometry, shot and thermal noise variances, optical SNR, and packet error rates.
- **Novel Scheduling Policy (BASIL-PSA)**: Priority-Sensitive Adaptive scheduling combining burst detection, latency-deadline urgency, and starvation-free best-effort round-robin delivery.
- **Offline Optimization Oracle (BASIL-OPT)**: Slotted MILP reference solved via HiGHS-1.16.0 providing a proven mathematical upper bound on semantic goodput under future arrival awareness.
- **Native Windows Desktop Application (Tauri 2)**: Distributable Windows desktop application with self-contained NSIS installer, persistent SQLite database, and real-time backend lifecycle management.
- **Interactive UI**: Modern React 18 + Vite desktop interface featuring real-time experiment tracking, parameter configuration, and Plotly analytics.

---

## 2. Windows Desktop Installer & Deployment (Phase 4.2)

BASIL 4.1.0 ships with a production-ready, resource-bundled Windows installer:

* **Installer File:** [`desktop-app/src-tauri/target/release/bundle/nsis/BASIL_4.1.0_x64-setup.exe`](desktop-app/src-tauri/target/release/bundle/nsis/BASIL_4.1.0_x64-setup.exe)
* **Product Name:** `BASIL`
* **Version:** `4.1.0` (Phase 4.2 Resource-Bundled Build)
* **Format:** Single-file self-extracting NSIS Setup Executable (.exe)
* **File Size:** `3.23 MiB` (3,389,269 bytes)
* **SHA-256 Checksum:** `6F9781C663813C9CB81A94C95D7A1C1E9EEF1A6DDFC3EF05BCCCB05A42C3A542`
* **Target Installation Location:** `%LOCALAPPDATA%\Programs\BASIL` (CurrentUser mode, no administrative UAC elevation required)
* **Start Menu Shortcut:** `%APPDATA%\Microsoft\Windows\Start Menu\Programs\BASIL.lnk`
* **Application Data Directory:** `%LOCALAPPDATA%\BASIL\data\basil.db` (Survives app upgrades & uninstalls)
* **Uninstaller:** `%LOCALAPPDATA%\Programs\BASIL\uninstall.exe`
* **Bundled Resources:** Includes full FastAPI backend (`resources/backend`), seed database, dependency diagnostics, requirements, and standalone C++ DES simulator (`resources/ns3-lifi/scratch/basil-sim.exe`).

### User Documentation
- **[Windows Installation Guide](WINDOWS_INSTALLATION_GUIDE.md)**: Detailed step-by-step setup, 3-tier prerequisites, silent installation, and uninstallation.
- **[Demo Runbook](DEMO_RUNBOOK.md)**: 5-minute interactive walkthrough for evaluators demonstrating FIFO, BASIL-PSA, BASIL-OPT, and results export.
- **[Phase 4.2 Deployment Acceptance Report](PHASE4_2_DEPLOYMENT_ACCEPTANCE_REPORT.md)**: Installed application acceptance audit, repository independence verification, and GUI simulation proofs.
- **[Phase 4.2 Validation Results JSON](PHASE4_2_VALIDATION_RESULTS.json)**: Machine-readable acceptance records.
- **[Phase 4.1 Deployment Report](PHASE4_1_DEPLOYMENT_REPORT.md)**: Initial desktop packaging report.

---

## 3. Runtime Dependency Checker

BASIL includes an automated startup dependency validator that checks all 17 host, simulation, and storage prerequisites across three tiers:

```powershell
python backend/check_dependencies.py
```

To output machine-readable JSON:
```powershell
python backend/check_dependencies.py --json
```

The diagnostics can also be inspected at runtime via the backend REST API: `GET /api/system/dependencies`.

---

## 4. Prerequisites

| Component | Minimum Version | Note |
| :--- | :--- | :--- |
| **Operating System** | Windows 10/11 x86_64 | Native Windows desktop build verified |
| **WebView2 Runtime** | Evergreen Runtime | Pre-installed on Windows 10/11; bootstrapper available from Microsoft |
| **Python** | 3.10+ (64-bit) | Required for FastAPI backend and HiGHS optimizer |
| **WSL2 Ubuntu** | Ubuntu 22.04 / 24.04 | Required for ns-3.42 hybrid simulation pipeline |
| **Rust & Cargo** | 1.75+ | **Build-Time Only.** NOT required at runtime for end users running the installer or `basil.exe` |

---

## 5. Quick Start (Windows)

### Option A: Launch Native Desktop Application (Tauri 2)
```bat
start-desktop.bat
```
This automatically starts the local FastAPI backend service on port 8000 and opens the native Windows desktop application (`basil.exe`).

### Option B: Web Development Mode
```bat
start-all.bat
```
Launches backend at `http://127.0.0.1:8000` and Vite dev server at `http://localhost:5173`.

---

## 6. Building from Source

### 6.1 Compile Desktop Application & Installer (Tauri 2)
```powershell
# 1. Ensure Rust and Cargo are in PATH
$env:PATH = "$env:USERPROFILE\.cargo\bin;" + $env:PATH

# 2. Build desktop frontend and NSIS installer
cd desktop-app
npm install
npx tauri build --bundles nsis
```
Output files:
- Standalone Executable: `desktop-app/src-tauri/target/release/basil.exe`
- Windows Installer: `desktop-app/src-tauri/target/release/bundle/nsis/BASIL_4.1.0_x64-setup.exe`

### 6.2 Backend Verification
```powershell
python -m pytest backend/tests -v
```
*(Runs 45 automated unit, accounting, solver integrity, and integration tests).*

### 6.3 End-to-End Test Suites
```powershell
# Phase 4.1 End-to-End API verification:
python tests/verify_phase4_1_e2e.py

# Phase 4.2 Installed GUI Acceptance suite (drives live WebView2 UI via CDP):
python tests/test_installed_gui_acceptance.py
```
*(Executes real desktop tests A, B, C, D, and E across the installed binary, verifying live simulations, data persistence, and UI exports).*

---

## 7. Scheduling Algorithms

BASIL benchmarks five packet-scheduling strategies:

1. **FIFO (First-In, First-Out)**:
   - Packets served strictly according to queue arrival sequence.
   - Suffers from Head-of-Line (HoL) blocking during traffic bursts.
2. **Round Robin (RR)**:
   - Rotates through per-device transmission queues cyclically.
   - Prevents multi-device starvation, but ignores packet latency deadlines.
3. **Strict Priority (SP)**:
   - Always transmits highest-priority packets before lower-priority classes.
   - Causes complete starvation of lower-priority flows under heavy loads.
4. **BASIL-PSA (Priority-Sensitive Adaptive)**:
   - **Dual-Tier Queuing**: Separates urgent, deadline-bound packets from best-effort traffic.
   - **Burst Detection**: CUSUM / EWMA tracking automatically adapts to sudden burst traffic.
   - **Multi-Device Fairness**: Fallback round-robin serving across best-effort device queues prevents starvation.
5. **BASIL-OPT (Offline MILP Reference)**:
   - **Global Upper Bound**: Formulated as a Mixed-Integer Linear Program (MILP) solved via HiGHS-1.16.0 with future arrival awareness.
   - **Channel-Aware Matching**: Evaluates slotted transmission assignments against physical optical PER.

---

## 8. Li-Fi Optical Channel Model

BASIL accurately models indoor optical wireless channels (LOS Lambertian model):
- **Lambertian Order**: $m = \frac{-\ln 2}{\ln(\cos \Phi_{1/2})}$
- **Channel Gain**: $H(0) = \frac{(m+1) A_r}{2\pi d^2} \cos^m(\phi) T_s(\psi) g(\psi) \cos(\psi)$
- **Noise Analysis**: Accounts for optical shot noise ($\sigma^2_{\text{shot}} = 2 q \rho P_r B$) and receiver thermal noise ($\sigma^2_{\text{thermal}} = \frac{4 k_B T B}{R_L}$).
- **Modulation**: On-Off Keying (OOK) Bit Error Rate $\text{BER} = \frac{1}{2} \operatorname{erfc}\left(\sqrt{\frac{\text{SNR}}{2}}\right)$ and Packet Error Rate $\text{PER} = 1 - (1 - \text{BER})^{8L}$.

See [`docs/LIFI_MODEL.md`](docs/LIFI_MODEL.md) for full mathematical derivations.

---

## 9. API Endpoint Reference

Base URL: `http://localhost:8000`

| Method | Endpoint | Description |
| :--- | :--- | :--- |
| `GET` | `/health` | Server heartbeat & authentic signature verification |
| `GET` | `/api/health` | API health check |
| `GET` | `/api/system/dependencies` | Diagnostic report of all 17 system dependencies |
| `GET` | `/api/networks` | List saved Li-Fi room configurations |
| `POST` | `/api/network-configs` | Create a new room topology and AP config |
| `GET` | `/api/traffic` | List saved traffic patterns |
| `POST` | `/api/traffic-configs` | Create a new traffic profile |
| `GET` | `/api/experiments` | List all scheduled and finished runs |
| `POST` | `/api/experiments` | Create a new simulation run |
| `POST` | `/api/simulate/{id}` | Execute simulation for an experiment |
| `GET` | `/api/results/{exp_id}` | Retrieve comprehensive simulation metrics |
| `GET` | `/api/results/compare` | Compare multiple experiments side-by-side |
| `GET` | `/api/results/{exp_id}/export/csv` | Export experiment data as CSV |
| `GET` | `/api/results/{exp_id}/export/json` | Export experiment data as JSON |
| `GET` | `/api/algorithms` | List available scheduling algorithms |

---

## 10. Project Structure

```
BASIL/
├── README.md                          # Project overview and quick start
├── WINDOWS_INSTALLATION_GUIDE.md      # Step-by-step Windows installation guide (Phase 4.2)
├── DEMO_RUNBOOK.md                    # 5-minute evaluator demonstration walkthrough
├── PHASE4_2_DEPLOYMENT_ACCEPTANCE_REPORT.md # Installed app audit & GUI simulation proof
├── PHASE4_2_VALIDATION_RESULTS.json   # Machine-readable Phase 4.2 acceptance records
├── PHASE4_1_DEPLOYMENT_REPORT.md      # Phase 4.1 deployment report
├── PHASE4_1_VALIDATION_RESULTS.json   # Phase 4.1 validation records
├── start-all.bat                      # Web development launcher
├── start-desktop.bat                  # One-click native desktop launcher
├── docs/                              # In-depth architectural & theoretical documentation
├── backend/                           # FastAPI backend server
│   ├── check_dependencies.py          # Standalone 3-tier dependency validator CLI
│   ├── app/                           # FastAPI routers, models, schemas, services
│   └── tests/                         # Pytest automated test suite (45 tests)
├── desktop-app/                       # React + TypeScript + Tauri 2 desktop shell
│   ├── src/                           # UI pages, components, and Plotly charts
│   ├── src-tauri/                     # Rust desktop backend, NSIS packaging config
│   │   └── resources/                 # Bundled runtime assets (backend, seed db, simulator)
│   └── scripts/                       # Asset preparation scripts (prepare-resources.js)
├── ns3-lifi/                          # Standalone C++ DES simulator & ns-3 scripts
└── experiments/                       # Experiment datasets & development SQLite database
    ├── basil.db                       # Development SQLite database (production: %LOCALAPPDATA%)
    └── screenshots/                   # GUI acceptance test visual screenshots (CDP captures)
```
