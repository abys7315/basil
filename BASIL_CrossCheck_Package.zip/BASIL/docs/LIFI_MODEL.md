# BASIL Li-Fi Optical Channel Model Documentation

Technical specification of the optical wireless channel models, propagation equations, and noise derivations implemented in the BASIL simulation engine.

---

## 1. Optical Wireless Propagation Overview

In an indoor Visible Light Communication (Li-Fi) scenario, an optical Access Point (AP)—typically an array of high-power Light Emitting Diodes (LEDs)—transmits modulated optical signals to photodiode (PD) receivers. Due to the high reflective loss of ambient indoor surfaces, the Line-of-Sight (LOS) link predominantly determines signal reception and error rates.

---

## 2. Lambertian Radiation Model

Optical sources emit radiant energy conforming to a generalized Lambertian radiation pattern. The emission intensity distribution is described by:

$$R_0(\phi) = \frac{m + 1}{2\pi} \cos^m(\phi)$$

where:
- $\phi$ is the radiant angle of emission relative to the transmitter normal axis.
- $m$ is the Lambertian emission order, determined by the LED semi-angle at half power ($\Phi_{1/2}$):

$$m = \frac{-\ln(2)}{\ln(\cos(\Phi_{1/2}))}$$

---

## 3. LOS Channel DC Gain

The channel DC gain $H(0)$ for a direct LOS optical path between the LED AP and receiver photodetector is formulated as:

$$H(0) = \begin{cases} \dfrac{(m + 1) A_r}{2\pi d^2} \cos^m(\phi) T_s(\psi) g(\psi) \cos(\psi), & 0 \le \psi \le \Psi_c \\ 0, & \psi > \Psi_c \end{cases}$$

where:
- $A_r$: Active detection surface area of the photodetector ($\text{cm}^2 \to \text{m}^2$).
- $d$: Euclidean distance separating transmitter and receiver ($m$).
- $\psi$: Angle of incidence relative to the detector surface normal.
- $\Psi_c$: Field of View (FOV) semi-angle of the receiver photodetector.
- $T_s(\psi)$: Transmission coefficient of the optical filter.
- $g(\psi)$: Gain of the non-imaging optical concentrator:

$$g(\psi) = \begin{cases} \dfrac{n^2}{\sin^2(\Psi_c)}, & 0 \le \psi \le \Psi_c \\ 0, & \psi > \Psi_c \end{cases}$$

where $n$ represents the internal refractive index of the concentrator lens.

---

## 4. Received Optical Power

Given transmitted optical power $P_t$, received optical power $P_r$ is:

$$P_r = P_t \cdot H(0)$$

The generated photocurrent signal current is:

$$I_{\text{signal}} = \rho \cdot P_r$$

where $\rho$ is the photodiode responsivity ($\text{A/W}$).

---

## 5. Noise Variance Formulations

The optical channel is subject to two primary additive Gaussian noise processes:

### 5.1 Shot Noise Variance ($\sigma^2_{\text{shot}}$)
Induced by ambient light and received optical power:

$$\sigma^2_{\text{shot}} = 2 q \rho P_r B$$

where:
- $q = 1.602 \times 10^{-19} \text{ C}$ (electronic charge)
- $B$: System modulation bandwidth ($\text{Hz}$)

### 5.2 Thermal Noise Variance ($\sigma^2_{\text{thermal}}$)
Originates from the receiver transimpedance amplifier and load resistors:

$$\sigma^2_{\text{thermal}} = \frac{4 k_B T B}{R_L}$$

where:
- $k_B = 1.381 \times 10^{-23} \text{ J/K}$ (Boltzmann constant)
- $T$: Absolute temperature in Kelvin ($298 \text{ K}$)
- $R_L$: Receiver load resistance ($50\,\Omega$)

Total noise variance is:

$$\sigma^2_{\text{total}} = \sigma^2_{\text{shot}} + \sigma^2_{\text{thermal}}$$

---

## 6. Electrical Signal-to-Noise Ratio (SNR)

For On-Off Keying (OOK) modulation:

$$\text{SNR} = \frac{I^2_{\text{signal}}}{\sigma^2_{\text{total}}} = \frac{(\rho P_r)^2}{2 q \rho P_r B + \dfrac{4 k_B T B}{R_L}}$$

Converted to decibels ($\text{dB}$):

$$\text{SNR}_{\text{dB}} = 10 \log_{10}(\text{SNR})$$

---

## 7. Error Probabilities: BER & PER

### 7.1 Bit Error Rate (BER)
Assuming optimal detection thresholding under additive white Gaussian noise:

$$\text{BER} = \frac{1}{2} \operatorname{erfc}\left(\sqrt{\frac{\text{SNR}}{2}}\right)$$

where $\operatorname{erfc}(x)$ is the complementary error function:

$$\operatorname{erfc}(x) = \frac{2}{\sqrt{\pi}} \int_x^{\infty} e^{-u^2} du$$

### 7.2 Packet Error Rate (PER)
For an unencoded frame consisting of $L$ bytes ($8L$ bits), assuming independent bit errors:

$$\text{PER} = 1 - (1 - \text{BER})^{8L}$$

---

## 8. Physical Channel Parameters & Typical Values

| Parameter | Symbol | Default Value | Unit |
| :--- | :--- | :--- | :--- |
| LED Transmit Power | $P_t$ | 50.0 - 1000.0 | $\text{mW}$ |
| Transmitter Semi-Angle | $\Phi_{1/2}$ | 60.0 | $\text{deg}$ |
| Receiver Area | $A_r$ | 1.0 | $\text{cm}^2$ |
| Photodiode Responsivity | $\rho$ | 0.53 | $\text{A/W}$ |
| Receiver FOV | $\Psi_c$ | 60.0 | $\text{deg}$ |
| Optical Filter Gain | $T_s$ | 1.0 | unitless |
| Concentrator Gain | $g$ | 1.0 | unitless |
| Modulation Bandwidth | $B$ | 100.0 | $\text{MHz}$ |
| Load Resistance | $R_L$ | 50.0 | $\Omega$ |
| Absolute Temperature | $T$ | 298.0 | $\text{K}$ |

---

## 9. References

1. **Komine, T., & Nakagawa, M. (2004)**. *Fundamental analysis for visible-light communication system using LED lights*. IEEE Transactions on Consumer Electronics, 50(1), 100-107.
2. **Kahn, J. M., & Barry, J. R. (1997)**. *Wireless infrared communications*. Proceedings of the IEEE, 85(2), 265-298.
3. **Ghassemlooy, Z., Popoola, W., & Rajbhandari, S. (2012)**. *Optical Wireless Communications: System and Channel Modelling with MATLAB*. CRC Press.
