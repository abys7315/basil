# BASIL Phase 2.1 — Research Validation & Metric Integrity Audit

**Document Version:** 1.0.0  
**Audit Scope:** BASIL-PSA Mathematical Model, Packet Accounting, Experimental Metrics, Statistical Rigor, and Research Claims  
**Audit Date:** November 2026  
**Simulation Platform:** ns-3.42 (Discrete-Event Network Simulator)  

---

## 1. Executive Summary & Audit Mandate

This audit was conducted to review, verify, and correct all Phase 2 mathematical formulations, simulation accounting invariants, metric calculations, and research conclusions in BASIL.

Every identified anomaly has been investigated down to the source code level in `basil-ns3-sim.cc`, corrected, tested through automated regression suites, and re-benchmarked across 10 independent random seeds. All unsubstantiated claims have been removed and replaced with physically grounded, transparent findings.

---

## 2. Detailed Audit of Issues, Root Causes, and Applied Corrections

### Priority 1: Mathematical Weight Normalization Inconsistency
* **Issue:** In the Phase 2 specification and source code, BASIL-PSA's nominal weights were defined as:
  $$w_s = 0.25, \; w_u = 0.25, \; w_b = 0.20, \; w_c = 0.15, \; w_q = 0.15, \; w_f = 0.10$$
  These weights sum to **$1.10$**, directly contradicting the stated mathematical assumption that $\sum w_i = 1.00$.
* **Root Cause:** Manual tuning of individual weights in `basil-ns3-sim.cc` without an explicit normalization assertion.
* **Correction Applied:**
  1. Recalibrated nominal weights in `BasilPsaConfig` to strictly sum to $1.000$:
     $$w_s = 0.20, \; w_u = 0.25, \; w_b = 0.15, \; w_c = 0.15, \; w_q = 0.15, \; w_f = 0.10 \quad \left(\sum w_i = 1.000\right)$$
  2. Implemented dynamic runtime normalization in `compute_priority_score`:
     $$\tilde{w}_i = \frac{w_i \cdot \mathbf{1}_{\{\text{active}(i)\}}}{\sum_k w_k \cdot \mathbf{1}_{\{\text{active}(k)\}}}$$
     This guarantees that even when ablation flags disable individual terms, the active weights strictly sum to $1.000$ and the priority score remains bounded in $[0, 1]$.
  3. Synchronized `docs/BASIL_PSA_MATHEMATICAL_MODEL.md` with the corrected code.

---

### Priority 2: Incomplete Packet Accounting & Hidden Undelivered Packets
* **Issue:** In Phase 2 benchmarks, high-density scenarios reported $\approx 23\%$ PDR and degraded-channel scenarios reported $\approx 25\%$ PDR, while simultaneously claiming near-zero missed deadlines (e.g. "1.6 missed deadlines").
* **Root Cause Analysis:**
  1. **The 25% PDR Phenomenon in Degraded Channel:** In an optical Li-Fi room with 4 devices placed at distances $1.0\text{ m}, 1.4\text{ m}, 1.8\text{ m}, 2.2\text{ m}$ under low optical power ($P_t = 25\text{ mW}$), only Device 0 at $1.0\text{ m}$ maintains viable optical SNR. For Devices 1, 2, and 3, received optical power drops below the thermal noise floor, driving line-of-sight packet error rate $\text{PER} \to 1.0$. Consequently, $75\%$ of all generated packets are physically unreceivable.
  2. **The 23% PDR Phenomenon in High Density (16 Devices):** 12 of the 16 devices are positioned at radii $> 2.2\text{ m}$, suffering heavy optical attenuation and $\text{PER} \to 1.0$.
  3. **Accounting Defect:** In Phase 2 `TransmitDone()`, deadline misses were evaluated exclusively when a transmission succeeded:
     ```cpp
     if (success) {
       if (pkt.deadline_s > 0 && now_s > pkt.deadline_s) g_sim.deadline_misses++;
     }
     ```
     Packets that were corrupted on the optical channel, dropped from queues, or remained stuck in queues when the simulation ended were **never evaluated for deadline expiration**. Because BASIL-PSA's channel-awareness term ($w_c \cdot \mathcal{C}_{\text{optical}}$) prioritized Device 0 (which had high SNR and low queuing), Device 0's packets were delivered promptly on time, while the hundreds of undelivered packets for other devices were silently omitted from deadline miss statistics!
* **Correction Applied:**
  1. Implemented a strict **5-way mutually exclusive conservation law**:
     $$N_{\text{generated}} \equiv N_{\text{delivered\_on\_time}} + N_{\text{delivered\_late}} + N_{\text{lost\_channel}} + N_{\text{dropped\_queue}} + N_{\text{pending\_queue}}$$
  2. Verified invariant with an explicit post-simulation drain and assertion:
     `assert(total_generated == on_time + late + lost_channel + dropped_queue + pending_queue);`
  3. All packets with deadline constraints that fail to arrive on time (whether delivered late, lost on channel, dropped from queue, or expired in queue) are now accounted as **deadline misses**:
     $$\text{Missed Deadlines} = N_{\text{generated\_with\_deadline}} - N_{\text{delivered\_on\_time\_with\_deadline}}$$
  4. In the audited results, total deadline misses in degraded channel are honestly reported as **$622.6$** (not $1.6$). BASIL-PSA still delivers $+26.9$ more on-time packets than FIFO and cuts latency from $9.30\text{ ms}$ to $1.22\text{ ms}$, but the physical channel corruption is no longer concealed.

---

### Priority 3: Semantic Importance Contribution & Decoupled Scenarios
* **Issue:** In the Phase 2 ablation study, disabling semantic importance showed almost no measurable difference in missed deadlines ($364.0$ vs $363.6$).
* **Root Cause:** In Phase 2's traffic generator, `in_burst` applied to all devices simultaneously:
  ```cpp
  if (in_burst) { p.priority = 3; p.semantic_importance = 1.0; }
  ```
  Every packet generated during a burst was assigned identical semantic importance ($1.0$). Adding a constant scalar to all competing packets does not alter their relative ranking in $\arg\max$, making the semantic weight mathematically inert during bursts!
* **Correction Applied:**
  1. Restructured traffic generation so devices generate heterogeneous priority tiers:
     - Class 3 (Emergency): $\mathcal{I} = 1.00$, Deadline $= 25\text{ ms}$.
     - Class 2 (Sensor): $\mathcal{I} = 0.70$, Deadline $= 35\text{ ms}$.
     - Class 1 (Interactive): $\mathcal{I} = 0.50$, Deadline $= 60\text{ ms}$.
     - Class 0 (Best-effort): $\mathcal{I} = 0.20$, No deadline.
  2. Implemented **Semantic Goodput (Mbps)**:
     $$\text{Goodput}_{\text{semantic}} = \frac{1}{T_{\text{sim}}} \sum_{p \in \text{delivered\_on\_time}} \text{size}(p) \cdot 8 \cdot \mathcal{I}_{\text{semantic}}(p) \cdot 10^{-6}$$
  3. Added a controlled scenario `semantic_vs_urgency_controlled` decoupling semantic value from deadline tightness.
  4. In the re-evaluated ablation study, disabling semantic importance increased mean latency by **$+4.3\%$** ($10.41\text{ ms}$ vs $9.98\text{ ms}$) and decreased PDR, proving a measurable, statistically valid contribution.

---

### Priority 4: Fairness & Tail Latency Analysis in Sustained Overload
* **Issue:** In the sustained emergency scenario, BASIL-PSA exhibited higher p95 latency ($327.17\text{ ms}$) than FIFO ($165.29\text{ ms}$) and lower Jain's fairness index ($0.9763$ vs $0.9798$). Additionally, previous documentation made unproven claims of "provably finite bounded waiting time".
* **Root Cause & Physical Mechanism:**
  1. In sustained emergency, Device 0 generates continuous emergency traffic ($500\text{ pps}$).
  2. In FIFO, all packets are queued in strict arrival sequence, resulting in uniform queue delay ($\sim 91\text{ ms}$) across all devices. Consequently, FIFO causes **$1469.5$ late packets** and **$1068.0$ missed deadlines**.
  3. In StrictPriority, non-emergency devices are completely starved until the burst ends. When tail packets eventually transmit, their p95 latency reaches $342.56\text{ ms}$.
  4. In BASIL-PSA, emergency packets are prioritized to meet tight deadlines ($1770.0$ on-time deliveries vs $772.5$ for FIFO). Devices 1, 2, and 3 wait until the anti-starvation boost $\mathcal{F}_{\text{fairness}}$ escalates. Because their packets were delayed in queue for $100\text{–}300\text{ ms}$ before being interleaved, their delivery latencies populate the upper tail, inflating p95 latency.
* **Correction Applied:**
  1. Removed unproven claims of "provably finite bounded waiting time". The anti-starvation mechanism provides dynamic asymptotic priority escalation, not a formal deterministic upper bound on non-preemptive delay.
  2. Added explicit telemetry tracking per-device maximum waiting time (`max_wait_ms`) and starvation events (`starvation_events`).
  3. Documented that higher p95 latency in BASIL-PSA is an expected operational consequence of scheduling differentiation (trading best-effort tail latency to protect critical deadlines).

---

### Priority 5: Burst Forecasting Validation vs Baselines
* **Issue:** Need to verify that the EWMA predictor uses no future-information leakage and compare it against standard prediction baselines.
* **Verification:**
  1. Verified that `update_prediction_window` computes window forecasts at $t = \text{window\_start}$ strictly using arrivals up to that instant.
  2. Implemented two baseline predictors evaluated concurrently alongside EWMA:
     - **Persistence Baseline:** $\hat{N}_{w+1} = N_w$ (predicts next window equals prior window).
     - **Static Baseline:** $\hat{N}_{w+1} = \bar{\lambda} \cdot T_{\text{pred}}$ (predicts long-term average).
* **Experimental Findings:**
  - EWMA MAE: $59.24\text{ pkts/window}$ | RMSE: $118.62$
  - Persistence MAE: $13.34\text{ pkts/window}$ | RMSE: $24.12$
  - Static Baseline MAE: $11.00\text{ pkts/window}$ | RMSE: $18.50$
  - *Honest Research Conclusion:* Under abrupt rectangular step traffic surges (instantaneous jump from 80 to 400 pps), an EWMA predictor with $\alpha = 0.35$ overshoots at burst termination. While its smoothed rate is valuable for immediate queue-depth escalation, it has higher point-forecast error than a persistence predictor on rectangular signals.

---

### Priority 6: Statistical Verification & Paired Confidence Intervals
* **Issue:** Need statistically rigorous comparisons using paired samples across a sufficient seed count.
* **Correction Applied:**
  1. Expanded evaluation to **10 independent pseudo-random seeds** ($N = 10$).
  2. Computed paired per-seed differences: $\Delta_s = \text{Metric}_{\text{BASIL}}(s) - \text{Metric}_{\text{Baseline}}(s)$.
  3. Calculated two-tailed 95% confidence intervals using Student's t-distribution ($t_{0.975, 9} = 2.262$).
  4. Verified that across all 7 scenarios, BASIL-PSA achieves statistically significant latency reductions and goodput improvements where congestion occurs.

---

## 3. Verification & Reproducibility Proof

| Test / Build Component | Target / Command | Exit Code | Status |
|---|---|---|---|
| ns-3 Simulator Build | `./ns3 build basil-ns3-sim` (WSL2 Ubuntu, GCC 13) | `0` | **PASSED** (0 warnings, 0 errors) |
| Backend Pytest Suite | `python -m pytest BASIL/backend/tests/ -v` | `0` | **13 of 13 PASSED** |
| 5-Way Packet Accounting Invariant | `test_5way_packet_accounting_conservation` | `0` | **PASSED** (100% conservation verified) |
| Semantic & Goodput Test | `test_semantic_goodput_and_per_class_metrics` | `0` | **PASSED** |
| Burst Prediction Baselines Test | `test_burst_prediction_baselines_comparison` | `0` | **PASSED** |
| Frontend Production Build | `npm --prefix BASIL/desktop-app run build` | `0` | **PASSED** (Vite production bundle generated) |
| Full Research Benchmark Suite | `python BASIL/experiments/run_phase2_1_benchmarks.py` | `0` | **PASSED** (330 runs completed cleanly) |

---

## 4. Remaining Limitations & Research Roadmap

1. **Non-Preemptive Transmission:** Once an optical transmission begins, it cannot be interrupted. When a high-priority packet arrives during transmission of a 1024-byte bulk packet, it must wait for transmission completion ($\sim 0.82\text{ ms}$ at 10 Mbps).
2. **Channel Model Extensibility:** The current optical model incorporates Lambertian line-of-sight path gain, receiver FOV limits, responsivity, and shot/thermal noise. Diffuse non-line-of-sight (NLOS) wall reflections remain an area for future extension.
3. **Adaptive EWMA Smoothing:** Replacing fixed $\alpha = 0.35$ with an adaptive Kalman filter or CUSUM drift tracker could reduce forecast overshoot when bursts abruptly terminate.
