# BASIL Phase 3.3 — Final Cross-Algorithm Metric Parity Audit

**Audit Date:** November 14, 2026  
**Auditor:** Antigravity Autonomous Systems Validation  
**Scope:** Cross-algorithm metric parity, three-metric standardization (Scheduling Misses, E2E Failures, Channel Losses), terminology and conservation unification, and historical benchmark reconciliation across all five schedulers (FIFO, Round Robin, Strict Priority, BASIL-PSA, BASIL-OPT).  
**Components Audited & Updated:**
- `ns3-lifi/scratch/basil-ns3-sim.cc` (C++ discrete-event simulator optical PHY/MAC telemetry)
- `backend/app/algorithms/basil_opt.py` (HiGHS optimization oracle, analytical expectation & Monte Carlo replay)
- `backend/app/simulation/runner.py` (Simulation runner trace extraction & optimizer seed coupling)
- `backend/tests/test_metric_parity.py` (Automated 5-invariant parity regression test suite)
- `experiments/phase3_3_reconciled_benchmark_results.json` (Reconciled 100-run multi-scenario dataset)

---

## 1. Executive Summary

Phase 3.3 establishes absolute cross-algorithm evaluation parity across all five scheduling architectures in the BASIL research framework. 

Prior to this audit, historical comparisons between online heuristic schedulers (FIFO, Round Robin, Strict Priority, BASIL-PSA) and the offline optimization reference (BASIL-OPT) were vulnerable to semantic conflation:
1. The ns-3 simulator computed `total_deadline_misses = total_generated_with_deadline - total_delivered_on_time`, grouping physical optical attenuation drops together with queue delay misses.
2. The optimizer reported scheduled transmission counts as delivered packets without differentiating analytical expectations from stochastic Monte Carlo realizations.

This audit eliminates all semantic ambiguity by implementing **three distinct, non-conflated metrics** across every algorithm:
- **Metric A (Scheduling Deadline Misses):** Measures scheduler timeliness. Excludes on-time transmissions lost to optical PER.
- **Metric B (End-to-End Deadline Failures):** Measures complete application-layer packet delivery success. Includes unscheduled packets, late transmissions, and channel PER drops.
- **Metric C (Optical Channel Losses):** Measures physical wireless link drops independently of scheduler queues.

Under this standardized parity framework:
- In `dense_viable_coverage` (`optical_attenuation_gradient`), **all five algorithms achieve exactly 0.40 scheduling deadline misses** per seed.
- End-to-end deadline failures are reconciled to **92.0 failures** (online empirical) vs. **89.38 failures** (BASIL-OPT analytical expectation) / **90.0 failures** (BASIL-OPT Monte Carlo replay).
- The historical 100-run dataset was fully reconciled without rerunning unaffected experiments, preserving historical data while providing a versioned, parity-compliant dataset (`phase3_3_reconciled_benchmark_results.json`).
- All 18 unit, integrity, accounting, and parity regression tests pass with a 100% pass rate in 33.08 seconds.

---

## 2. Standardization of the Three Parity Metrics

```mermaid
flowchart TD
    Gen["Total Generated Packets with Deadlines<br>(K_with_deadline)"] --> SchedCheck{"Scheduled & Transmitted<br>Before Deadline?"}
    
    SchedCheck -->|No: Expired in Queue, Dropped, or Late| FailSched["Scheduling Deadline Miss<br>(Metric A)"]
    SchedCheck -->|Yes: Airtime Slot Meets Deadline| PassSched["On-Time Transmission<br>(NOT a Scheduling Miss)"]
    
    PassSched --> ChannelCheck{"Optical Link Reception<br>(Bernoulli Trial / PER)"}
    ChannelCheck -->|Lost on Optical Channel| LossChan["Optical Channel Loss<br>(Metric C)"]
    ChannelCheck -->|Successfully Decoded| SuccDeliv["Delivered On-Time<br>(Clean Success)"]
    
    FailSched --> E2EFail["End-to-End Deadline Failure<br>(Metric B)"]
    LossChan --> E2EFail
```

### 2.1 Metric A: Scheduling Deadline Misses (`scheduling_deadline_misses`)
- **Definition:** The integer count of deadline-bearing packets ($d_k > 0$) that failed to complete transmission over the air before their deadline.
- **Rules:**
  - A packet transmitted before its deadline but subsequently lost due to optical PER **must not** count as a scheduling deadline miss.
  - Packets transmitted after deadline (`delivered_late`), packets dropped due to buffer overflow (`dropped_queue`), and packets remaining in queue whose deadlines expired before or at simulation end (`pending_with_deadline_expired`) are counted.
  - Packets without deadlines (Class 0 Best-Effort, $d_k \le 0$) **never** increment this metric.
- **ns-3 C++ Formulation:**
  $$\text{scheduling\_deadline\_misses} = \text{total\_delivered\_late} + \text{lost\_channel\_late} + \text{dropped\_queue\_with\_ddl} + \text{pending\_with\_ddl\_expired}$$
- **BASIL-OPT Oracle Formulation:**
  $$\text{scheduling\_deadline\_misses} = \sum_{k \in \mathcal{K}_{\text{ddl}}} \left( 1 - \sum_{m \in \mathcal{M}_k} y_{k, m} \right)$$

### 2.2 Metric B: End-to-End Deadline Failures (`end_to_end_deadline_failures`)
- **Definition:** The count of deadline-bearing packets that were not successfully received and decoded at the receiver before their deadline.
- **Components:**
  $$\text{End-to-End Failures} = \text{Scheduling Deadline Misses} + \text{On-Time Optical Channel Losses}$$
- **ns-3 Online Formulation (Realized Integer):**
  $$\text{end\_to\_end\_deadline\_failures} = \text{total\_generated\_with\_deadline} - \text{total\_delivered\_on\_time}$$
- **BASIL-OPT Oracle Formulation (Analytical Expectation):**
  $$\mathbb{E}[\text{E2E Failures}] = \sum_{k \in \mathcal{K}_{\text{ddl}}, k \notin \text{sched}} 1.0 + \sum_{k \in \mathcal{K}_{\text{ddl}}, k \in \text{sched}} \text{PER}_{d(k)} = K_{\text{with\_deadline}} - \sum_{k \in \mathcal{K}_{\text{ddl}}, k \in \text{sched}} (1 - \text{PER}_{d(k)})$$
- **BASIL-OPT Monte Carlo Replay Formulation (Realized Integer):**
  $$\text{realized\_end\_to\_end\_deadline\_failures} = \text{scheduling\_deadline\_misses} + \text{realized\_lost\_channel\_deadline}$$

### 2.3 Metric C: Optical Channel Losses (`optical_channel_losses`)
- **Definition:** The count of packets that were transmitted over the optical wireless channel but failed physical receiver detection and CRC validation.
- **ns-3 Online Formulation (Realized Integer):**
  $$\text{optical\_channel\_losses} = \text{total\_lost\_channel}$$
- **BASIL-OPT Oracle Formulation (Analytical Expectation):**
  $$\mathbb{E}[\text{Channel Losses}] = \sum_{k \in \text{scheduled}} \text{PER}_{d(k)}$$
- **BASIL-OPT Monte Carlo Replay Formulation (Realized Integer):**
  $$\text{realized\_lost\_channel} = \sum_{k \in \text{scheduled}} \mathbb{I}(U_k < \text{PER}_{d(k)}), \quad U_k \sim \text{Uniform}(0, 1)$$

---

## 3. Strict Packet Terminology and Conservation Law

To eliminate metric inflation and mislabeling, the following standardized terminology is enforced:

| Term | Symbol | Exact Meaning |
| :--- | :---: | :--- |
| **Generated Packets** | $N_{\text{gen}} = K$ | Total offered packets created by application layer generators. |
| **Scheduled Packets** | $N_{\text{sched}}$ | Packets assigned an airtime transmission slot (NOT necessarily received). |
| **Delivered On-Time** | $N_{\text{del}}$ | Packets successfully transmitted and CRC-verified before deadline. |
| **Delivered Late** | $N_{\text{late}}$ | Packets successfully decoded whose reception finished after deadline. |
| **Lost Channel** | $N_{\text{lost}}$ | Packets transmitted over optical channel but corrupt upon reception. |
| **Dropped Queue** | $N_{\text{drop}}$ | Packets dropped due to finite buffer capacity constraints. |
| **Pending Queue** | $N_{\text{pend}}$ | Packets unserved and remaining in transmitter queue at simulation teardown. |

### Conservation Invariant
Conservation holds strictly without double-counting:
- **Online Discrete-Event Simulation:**
  $$N_{\text{gen}} = N_{\text{del}} + N_{\text{late}} + N_{\text{lost}} + N_{\text{drop}} + N_{\text{pend}}$$
- **Offline Optimizer Realized Replay:**
  $$N_{\text{gen}} = N_{\text{del,realized}} + N_{\text{late}} (0) + N_{\text{lost,realized}} + N_{\text{drop}} (0) + N_{\text{pend}}$$
- **Offline Optimizer Analytical Expectation:**
  $$N_{\text{gen}} = \mathbb{E}[N_{\text{del}}] + 0 + \mathbb{E}[N_{\text{lost}}] + 0 + N_{\text{pend}}$$

---

## 4. Reconciled Benchmark Results (100-Run Dataset)

All 100 runs from the Phase 3 multi-scenario benchmarking campaign were re-evaluated under the standardized parity metrics and persisted to `experiments/phase3_3_reconciled_benchmark_results.json`.

### 4.1 Scenario 4: `dense_viable_coverage` (`optical_attenuation_gradient`)

5 seeds (42–46), 4 devices, room 6.0 m $\times$ 3.0 m, AP optical power 60.0 W, burst ratio 0.30:

| Scheduler | Semantic Goodput (Mbps) | Scheduling Deadline Misses (Metric A) | End-to-End Deadline Failures (Metric B) | Optical Channel Losses (Metric C) | Scheduled PDR | Expected Received PDR | Ratio to Optimal |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| **FIFO** | $2.5321 \pm 0.078$ | **0.40** | **93.20** | 240.20 | $99.94\%$ | $61.94\%$ | $100.24\%$ |
| **Round Robin** | $2.5354 \pm 0.083$ | **0.40** | **92.40** | 239.40 | $99.94\%$ | $62.06\%$ | $100.37\%$ |
| **Strict Priority** | $2.5371 \pm 0.088$ | **0.40** | **92.00** | 239.00 | $99.94\%$ | $62.12\%$ | $100.44\%$ |
| **BASIL-PSA** | $2.5371 \pm 0.088$ | **0.40** | **92.00** | 239.00 | $99.94\%$ | $62.12\%$ | $100.44\%$ |
| **BASIL-OPT (Oracle)** | $2.5261 \pm 0.076$ | **0.40** | **89.38** *(Exp)* / **90.0** *(Real)* | **88.98** *(Exp)* / **89.6** *(Real)* | $76.61\%$ | **$62.52\%$** | $100.00\%$ |

> [!IMPORTANT]
> **Key Benchmark Insights:**
> 1. **Parity in Scheduling Deadline Misses:** When channel drops are separated from scheduling delay, all five algorithms exhibit an identical mean of **0.40 scheduling deadline misses**. In Seeds 42, 43, and 44, all five algorithms achieved 0 scheduling deadline misses. In Seeds 45 and 46, an instantaneous burst collision caused 1 packet to exceed its deadline.
> 2. **Channel-Aware Airtime Conservation:** Online schedulers blindly transmitted to Device 3 ($\text{PER} = 1.0$), wasting 148 transmission slots on packets guaranteed to fail CRC. BASIL-OPT refused to transmit to Device 3, reducing optical channel losses from **239.0 to 88.98**, saving $23.3\%$ of system airtime while achieving a higher expected received PDR ($62.52\%$ vs. $62.12\%$).
> 3. **Convergence of Expected and Realized Metrics:** BASIL-OPT's expected end-to-end deadline failures ($89.38$) match the realized Monte Carlo replay ($90.00$) and online empirical simulation ($92.00$) within the expected binomial standard error ($\sigma / \sqrt{5} \approx 2.7\text{ packets}$).

---

### 4.2 Clean Channel Benchmark Scenarios

In `normal_traffic`, `sudden_bursts`, and `mixed_semantic_traffic`, optical path loss is minimal ($\text{PER} \le 10^{-6}$ for devices with deadlines):

| Scenario | Scheduler | Scheduling Deadline Misses | End-to-End Deadline Failures | Optical Channel Losses | Scheduled PDR | Expected Received PDR |
| :--- | :--- | :---: | :---: | :---: | :---: | :---: |
| **Normal Traffic** | StrictPriority | 0.00 | 0.00 | 29.80 | $99.68\%$ | $93.68\%$ |
| | BASIL-OPT | 0.00 | 0.00 | 0.00 | $93.68\%$ | $93.68\%$ |
| **Sudden Bursts** | StrictPriority | 0.00 | 0.00 | 49.80 | $99.84\%$ | $91.80\%$ |
| | BASIL-OPT | 0.00 | 0.00 | 0.00 | $91.80\%$ | $91.80\%$ |
| **Mixed Semantic** | StrictPriority | 0.00 | 0.00 | 42.60 | $100.00\%$ | $93.07\%$ |
| | BASIL-OPT | 0.00 | 0.00 | 0.00 | $93.07\%$ | $93.07\%$ |

---

## 5. Verification Test Suite Execution

A dedicated automated test suite was developed in [test_metric_parity.py](file:///c:/Users/abys7/Downloads/BASIL-starter/BASIL/backend/tests/test_metric_parity.py) and executed alongside all existing regression suites:

```powershell
pytest BASIL/backend/tests/test_basil_opt.py BASIL/backend/tests/test_basil_opt_integrity.py BASIL/backend/tests/test_basil_opt_accounting.py BASIL/backend/tests/test_metric_parity.py -v
```

### Execution Log Summary:
- **Command:** `pytest BASIL/backend/tests/test_basil_opt.py BASIL/backend/tests/test_basil_opt_integrity.py BASIL/backend/tests/test_basil_opt_accounting.py BASIL/backend/tests/test_metric_parity.py -v`
- **Exit Code:** `0` (Success)
- **Total Tests Collected & Passed:** 18 items
- **Pass Rate:** 100% (18 passed, 0 failed)
- **Total Execution Time:** 33.08 seconds

### Test Invariant Proofs in `test_metric_parity.py`:
1. `test_metric_parity_five_invariants`:
   - **Invariant 1 Proved:** A packet transmitted before its deadline but lost due to PER is **not** a scheduling deadline miss (`scheduling_deadline_misses == 1`, accounting only for the infeasible packet, while on-time packet on lossy channel incurs 0 scheduling miss).
   - **Invariant 2 Proved:** The same lossy packet **is** counted as an end-to-end deadline failure (`expected_e2e_deadline_failures == 1.999`, `realized_e2e_deadline_failures == 2`).
   - **Invariant 3 Proved:** A packet never transmitted before its deadline **is** a scheduling deadline miss.
   - **Invariant 4 Proved:** An unscheduled best-effort packet without a deadline is **not** counted as a deadline miss.
   - **Invariant 5 Proved:** Generated-packet conservation is strictly maintained for both expected ($1.001 + 0.999 + 2 = 4$) and realized ($1 + 1 + 2 = 4$) outcomes.
2. `test_metric_parity_distinction_labels`:
   - Verifies explicit, non-overlapping dictionary keys for all expected, realized, scheduled, and delivered quantities.
3. `test_metric_parity_cross_algorithm_ns3_and_opt`:
   - Executes live end-to-end ns-3.42 and BASIL-OPT runs on identical optical gradients, confirming that both report `scheduling_deadline_misses == 0` and consistent end-to-end failure metrics.

---

## 6. Audit Classification Matrix

| Audit Item | Scope | Finding / Resolution | Classification |
| :--- | :--- | :--- | :---: |
| **Three Separate Parity Metrics** | All 5 Schedulers | Established `scheduling_deadline_misses`, `end_to_end_deadline_failures`, and `optical_channel_losses` across C++ and Python. | **Verified** |
| **ns-3 Telemetry Formatting** | `basil-ns3-sim.cc` | Updated telemetry to separate on-time channel losses from late deliveries and buffer drops. | **Corrected** |
| **BASIL-OPT Replay Mechanism** | `basil_opt.py` & `runner.py` | Implemented reproducible Monte Carlo channel replay coupled to experiment seeds. | **Verified** |
| **Terminology & Conservation** | All code & outputs | Replaced conflated "delivered" labels with `scheduled_packets_count`, `expected_delivered`, and `realized_delivered`. | **Corrected** |
| **Historical Benchmark Reconciliation** | 100-Run Dataset | Reconciled existing trace data without rerunning unaffected experiments; created versioned dataset. | **Verified** |
| **Five-Invariant Proof Test** | `test_metric_parity.py` | Automated tests proving all five core research-integrity invariants with 100% pass rate. | **Verified** |

---

## 7. Final Capstone Decision & Conclusion

All five scheduling algorithms in the BASIL framework—FIFO, Round Robin, Strict Priority, BASIL-PSA, and BASIL-OPT—now operate under **identical, comparable, and mathematically rigorous metric definitions**. 

- Scheduling delay is cleanly decoupled from physical optical attenuation.
- Analytical oracle expectations are transparently distinguished from stochastic Monte Carlo realizations.
- Conservation of offered traffic is strictly maintained across all scenarios.

**FINAL DECISION: VERIFIED — CROSS-ALGORITHM METRIC PARITY COMPLETE.**
