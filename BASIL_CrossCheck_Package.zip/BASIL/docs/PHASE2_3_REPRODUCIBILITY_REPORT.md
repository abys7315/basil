# BASIL Phase 2.3 — Reproducibility and Audit Report

**Project:** BASIL (Burst-Aware Semantic Intelligence for Li-Fi)  
**Document Version:** 2.3.0  
**Purpose:** Exact, deterministic step-by-step instructions to reproduce every simulation, benchmark, audit test, and statistical result reported in Phase 2.2 and Phase 2.3.  

---

## 1. System Requirements & Environment

| Component | Verified Specification | Notes |
|---|---|---|
| **Host OS** | Windows 11 / Windows 10 | Command Shell: PowerShell / Command Prompt |
| **Linux Subsystem** | WSL2 Ubuntu 24.04 LTS / 22.04 LTS | Used to run native Linux ns-3 simulation binary |
| **Simulation Core** | ns-3.42 (`/opt/ns3/ns-allinone-3.42/ns-3.42`) | Built with CMake + Ninja |
| **Python Environment** | Python 3.10.11 (Windows) | `scipy >= 1.11`, `numpy >= 1.26`, `pytest >= 8.0` |
| **Node.js Environment** | Node.js v22.13.1, npm 10.9.2 | Used for frontend desktop app verification |
| **C++ Compiler** | GCC 13.x (WSL Ubuntu) / MinGW g++ 6.3 (Windows) | Standard C++17 support |

---

## 2. Step-by-Step Reproduction Instructions

### Step 1: Compile the ns-3 Li-Fi Simulation Binary (WSL Ubuntu)
From the project root on Windows, synchronize and compile `basil-ns3-sim.cc` inside WSL Ubuntu:

```powershell
wsl -d Ubuntu -- bash -c "cp /mnt/c/Users/abys7/Downloads/BASIL-starter/BASIL/ns3-lifi/scratch/basil-ns3-sim.cc /opt/ns3/ns-allinone-3.42/ns-3.42/scratch/basil-ns3-sim.cc && cd /opt/ns3/ns-allinone-3.42/ns-3.42 && ./ns3 build basil-ns3-sim"
```

*Expected Result*:
```
[1/2] Building CXX object scratch/CMakeFiles/scratch_basil-ns3-sim.dir/basil-ns3-sim.cc.o
[2/2] Linking CXX executable /opt/ns3/ns-allinone-3.42/ns-3.42/build/scratch/ns3.42-basil-ns3-sim
```
Binary output: `/opt/ns3/ns-allinone-3.42/ns-3.42/build/scratch/ns3.42-basil-ns3-sim`.

---

### Step 2: Run the Automated Backend Regression Test Suite
Execute the pytest regression suite covering ns-3 execution, custom MinGW fallback, CUSUM predictor bounds, viable coverage fairness, and manifest reconciliation:

```powershell
python -m pytest BASIL\backend\tests\test_ns3_sim.py -v
```

*Expected Result*:
```
============================== 12 passed in 7.00s ==============================
```

---

### Step 3: Execute the Phase 2.2 Comprehensive Benchmark Suite
Run the 670 simulation runs across 10 random seeds:

```powershell
python BASIL\experiments\run_phase2_2_benchmarks.py
```

*Execution Details*:
- Part 1: Core Evaluation (8 scenarios $\times$ 4 schedulers $\times$ 10 seeds = 320 runs)
- Part 2: Predictor Accuracy Comparison (4 predictors $\times$ 10 seeds = 40 runs)
- Part 3: Controlled Semantic Experiments (4 scenarios $\times$ 4 schedulers $\times$ 10 seeds = 160 runs)
- Part 4: Weight Vector Sensitivity (5 configurations $\times$ 10 seeds = 50 runs)
- Part 5: Component Ablations (2 scenarios $\times$ 5 ablations $\times$ 10 seeds = 100 runs)
- Part 6: Experiment Manifest generation (`experiments/phase2_2_experiment_manifest.json`)
*Runtime*: Approximately 90–120 seconds.
*Output*: Reconciles 670 runs with 100% success.

---

### Step 4: Execute the Severe-Burst Overload Experiment
Evaluate the practical network benefit of CUSUM burst forecasting under saturated queues:

```powershell
python BASIL\experiments\run_severe_burst_experiment.py
```

*Expected Output*:
- `CUSUM`: Semantic Goodput $\approx 0.554\text{ Mbps}$, Deadline Misses $\approx 2649.6$.
- `No_Prediction`: Semantic Goodput $\approx 0.390\text{ Mbps}$, Deadline Misses $\approx 2696.8$.
- Paired differences: $\Delta\text{Goodput} = +0.1635\text{ Mbps}$ ($p = 0.0033$), $\Delta\text{Misses} = -47.2$ ($p = 0.0027$).
*Output File*: `experiments/phase2_3_severe_burst_results.json`.

---

### Step 5: Execute the Phase 2.3 Independent Audit Harness
Run the audit script to verify manifest uniqueness, raw file counts, 5-way packet conservation laws, independent Jain's index recalculation, and paired parametric/non-parametric tests:

```powershell
python BASIL\experiments\audit_phase2_3.py
```

*Expected Result*:
```
Manifest declared total_runs: 670
Manifest declared successful_runs: 670
Manifest declared failed_runs: 0
Actual runs array length: 670
Unique Run IDs: 670 / 670
Unique (Group, Scenario, Scheduler, Seed) tuples: 670 / 670
Failed runs: 0
Total Raw Runs: 670 (Matches Manifest 670: True)
Conservation law violations: 0
Independent Jain index discrepancies (>1e-3): 0
```
*Output Files*: `experiments/phase2_3_manifest_audit.json` and `experiments/phase2_3_statistical_results.json`.

---

### Step 6: Verify the Desktop Frontend Production Build
Confirm that the React / TypeScript desktop interface compiles with zero errors:

```powershell
npm --prefix BASIL\desktop-app run build
```

*Expected Result*:
```
✓ 1546 modules transformed.
dist/index.html                     0.48 kB
dist/assets/index-uGuqALDs.css     15.30 kB
dist/assets/index-DjhOgufW.js   5,120.38 kB
✓ built in 47.24s
```

---

## 3. Seed Determinism & Experimental Units

Every simulation run employs **Common Random Numbers (CRN)** drawn from the Mersenne Twister pseudo-random number generator initialized with explicit integer seeds:

$$\mathcal{S} = \{42, 101, 2024, 777, 9999, 12345, 54321, 98765, 11111, 22222\}$$

- **Unit of Randomization**: The simulation run (seed) is the unit of statistical independence ($N = 10$, degrees of freedom $df = 9$).
- Individual packets within a run are correlated and are **not** treated as independent samples.
- Paired statistical tests (Student's $t$ and Wilcoxon signed-rank) evaluate differences within identical seed pairs: $\Delta_s = \text{Metric}_{\text{BASIL}}(s) - \text{Metric}_{\text{Baseline}}(s)$.

---

## 4. Manifest Audit File Reference

| Output Artifact | Path | Size | Description |
|---|---|---|---|
| Manifest | `experiments/phase2_2_experiment_manifest.json` | $\approx 245\text{ KB}$ | Full record of all 670 runs with SHA-256 config hashes |
| Core Raw Results | `experiments/phase2_2_evaluation_results.json` | $\approx 5.38\text{ MB}$ | Full telemetry for 320 core evaluation runs |
| Predictor Raw Results | `experiments/phase2_2_predictor_results.json` | $\approx 510\text{ KB}$ | Telemetry for 40 predictor comparison runs |
| Controlled Raw Results | `experiments/phase2_2_controlled_results.json` | $\approx 2.20\text{ MB}$ | Per-class telemetry for 160 controlled semantic runs |
| Weights Raw Results | `experiments/phase2_2_weights_results.json` | $\approx 634\text{ KB}$ | Telemetry for 50 weight vector sensitivity runs |
| Ablations Raw Results | `experiments/phase2_2_ablation_results.json` | $\approx 1.28\text{ MB}$ | Telemetry for 100 component ablation runs |
| Severe Burst Results | `experiments/phase2_3_severe_burst_results.json` | $\approx 640\text{ KB}$ | Telemetry for 50 severe-burst overload runs |
| Statistical Audit | `experiments/phase2_3_statistical_results.json` | $\approx 12\text{ KB}$ | Paired $t$-test and Wilcoxon statistical results |
| Manifest Audit | `experiments/phase2_3_manifest_audit.json` | $\approx 2\text{ KB}$ | Independent verification counts and invariants |
