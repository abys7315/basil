# BASIL-OPT Mathematical Model & Theoretical Formulation

**Algorithm Title:** BASIL-OPT (**B**urst-**A**ware **S**emantic **I**ntelligence for **L**i-Fi — **Opt**imal Offline Oracle Reference)  
**Document Version:** 3.0.0 (Phase 3 Milestone)  
**Mathematical Category:** Mixed-Integer Linear Programming (MILP) / Maximum-Weight Constrained Scheduling  
**Underlying Solver Engine:** HiGHS 1.16.0 (C++ Core via Python `highspy` and `scipy.optimize.milp`)  

---

## 1. Algorithmic Identity & Purpose

BASIL-OPT is an **offline optimization reference scheduler** for optical wireless Li-Fi networks. Unlike the online BASIL-PSA algorithm—which operates under strict causal information constraints with only past telemetry and rolling window predictions—BASIL-OPT is formulated as an **offline oracle**.

The primary purpose of BASIL-OPT is to establish the **theoretical upper bound on achievable semantic goodput** and deadline satisfaction. By comparing the online BASIL-PSA against BASIL-OPT under identical traffic sequences and optical channel conditions, researchers can quantify the **optimality gap**—measuring how close causal predictive heuristics come to the mathematically ideal offline schedule.

---

## 2. Oracle Information Set (Offline Knowledge)

BASIL-OPT is endowed with complete, non-causal knowledge over the finite optimization horizon $\mathcal{T} = [0, T_{\text{sim}}]$:

1. **Packet Trace $\mathcal{K} = \{1, 2, \dots, K\}$**:
   - $a_k \in [0, T_{\text{sim}}]$: Exact packet arrival timestamp.
   - $d_k \in \{0, 1, \dots, N-1\}$: Destination Li-Fi device index.
   - $s_k$: Packet payload size in bytes (nominal $1024\text{ B}$).
   - $w_k \in \{0.20, 0.50, 0.70, 1.00\}$: Intrinsic semantic importance weight.
   - $D_k$: Absolute packet deadline timestamp ($D_k = a_k + \text{slack}_k$, or $\infty$ for best effort).
2. **Physical Channel Characteristics**:
   - $R_{\text{tx}}$: Li-Fi optical transmission data rate ($10\text{ Mbps} = 10^7\text{ bps}$).
   - $\tau_k = \frac{8 \cdot s_k}{R_{\text{tx}}}$: Transmission duration over the optical medium (for $1024\text{ B}$ at $10\text{ Mbps}$, $\tau = 0.8192\text{ ms}$).
   - $\text{PER}_{d_k} \in [0, 1]$: Packet Error Rate for destination node $d_k$, derived from the Lambertian LOS optical channel. $q_{d_k} = (1 - \text{PER}_{d_k})$ is the optical transmission reliability.
3. **Queue & Buffer Limitations**:
   - $B_{\text{cap}}$: Maximum buffer capacity per device queue (default 600 packets).

---

## 3. Slotted Network Flow / Matching Formulation

In the single-AP Li-Fi broadcast architecture, the optical channel is a shared, non-preemptive broadcast server: at most one packet can occupy the optical channel at any instant.

Let $\mathcal{M} = \{1, 2, \dots, M\}$ denote the set of discrete transmission slots over the optimization horizon $[0, T_{\text{sim}}]$, where $M = \lfloor T_{\text{sim}} / \tau \rfloor$. Slot $m \in \mathcal{M}$ spans the time window:
$$t_m^{\text{start}} = (m - 1) \cdot \tau, \quad t_m^{\text{end}} = m \cdot \tau$$

### 3.1 Decision Variables
- $y_{k, m} \in \{0, 1\}$: Binary variable indicating whether packet $k \in \mathcal{K}$ is scheduled for transmission during slot $m \in \mathcal{M}$ ($y_{k, m} = 1$) or not ($y_{k, m} = 0$).
- $x_k = \sum_{m \in \mathcal{M}} y_{k, m} \in \{0, 1\}$: Binary indicator whether packet $k$ is successfully delivered on time.
- $u_d \ge 0$: Auxiliary continuous variable representing the minimum allocation allocated to device $d$.

### 3.2 Objective Function
The optimization objective maximizes the total semantic goodput delivered on time over the simulation horizon, incorporating a micro-penalty $\epsilon$ to minimize queuing delay and an anti-starvation fairness regularization:

$$\max_{\mathbf{y}, \mathbf{u}} \quad \sum_{k \in \mathcal{K}} \sum_{m \in \mathcal{M}} \left( w_k \cdot (8 \cdot s_k) \cdot q_{d_k} - \epsilon \cdot (t_m^{\text{end}} - a_k) \right) y_{k, m} + \lambda_{\text{fair}} \cdot \sum_{d=0}^{N-1} u_d$$

Where:
- $w_k \cdot (8 \cdot s_k) \cdot q_{d_k}$: Semantic bits successfully delivered across the optical link.
- $-\epsilon \cdot (t_m^{\text{end}} - a_k)$: Secondary tie-breaker ($\epsilon = 10^{-6}$) that prefers earlier slots when multiple scheduling arrangements yield identical semantic goodput.
- $\lambda_{\text{fair}} \ge 0$: Regularization parameter balancing maximum throughput and per-device fairness.

### 3.4 Total Unimodularity (TUM) and Computational Complexity

**Theorem (Total Unimodularity of Core Slotted Formulation):**
The constraint matrix $A$ formed by constraints (1) Channel Exclusivity and (2) Packet Uniqueness over the candidate pair set $\mathcal{E}$ is **strictly totally unimodular (TUM)**.

*Proof:*
1. $A$ has dimension $(K + M) \times |\mathcal{E}|$. Every matrix element is in $\{0, 1\}$.
2. Each column corresponds to a valid packet-slot pair $(k, m) \in \mathcal{E}$.
3. Each column contains exactly two non-zero entries: $+1$ at packet row $k$ and $+1$ at slot row $K + m$.
4. By partitioning rows into $R_1 = \{0, \dots, K-1\}$ and $R_2 = \{K, \dots, K+M-1\}$, each column contains at most one non-zero in $R_1$ and at most one non-zero in $R_2$.
5. By the Hoffman-Gale characterization of bipartite incidence matrices, $A$ is totally unimodular.
6. Consequently, for any integer bounds vector $b \in \{0, 1\}^{K+M}$, every vertex of the continuous LP relaxation polytope is integral ($y_{k, m} \in \{0, 1\}$).
7. The linear programming relaxation solved by HiGHS is guaranteed to yield an exact integer-optimal solution with zero integrality gap ($\text{MIP Gap} \equiv 0.00\%$) in polynomial time. $\blacksquare$

> [!IMPORTANT]
> **Boundary Conditions on Total Unimodularity:**
> - Total unimodularity holds **strictly** for the core slotted matching model (uniform packet durations, single-server exclusivity, arrival causality, and deadline compliance enforced via candidate set $\mathcal{E}$).
> - Adding general knapsack-style buffer constraints (5), device min-rate constraints, or multi-slot packet fragmentation constraints destroys total unimodularity, requiring genuine branch-and-bound solving.
> - The continuous-time formulation (Section 4) with disjunctive Big-M constraints is **not** totally unimodular and is solved via HiGHS branch-and-bound.

---

## 4. Continuous-Time Disjunctive Formulation

For validation on small test scenarios with arbitrary packet lengths or continuous event times, BASIL-OPT also provides the continuous-time disjunctive formulation:

### 4.1 Decision Variables
- $x_k \in \{0, 1\}$: 1 if packet $k$ is transmitted on time, 0 otherwise.
- $t_k \ge 0$: Continuous start time of packet $k$ transmission.
- $z_{j, k} \in \{0, 1\}$ for each pair $j < k$: Precedence indicator ($z_{j, k} = 1$ if packet $j$ finishes before $k$ starts).

### 4.2 Constraints
1. **Release Times**:
   $$t_k \ge a_k \cdot x_k, \quad \forall k \in \mathcal{K}$$
2. **Deadlines**:
   $$t_k + \tau_k \le D_k + M_{\text{big}} \cdot (1 - x_k), \quad \forall k \in \mathcal{K} \text{ with } D_k > 0$$
3. **Horizon Limit**:
   $$t_k + \tau_k \le T_{\text{sim}} + M_{\text{big}} \cdot (1 - x_k), \quad \forall k \in \mathcal{K}$$
4. **Channel Exclusivity (Non-Overlapping Intervals)**:
   $$t_j + \tau_j \le t_k + M_{\text{big}} \cdot (1 - z_{j, k}) + M_{\text{big}} \cdot (2 - x_j - x_k), \quad \forall j < k$$
   $$t_k + \tau_k \le t_j + M_{\text{big}} \cdot z_{j, k} + M_{\text{big}} \cdot (2 - x_j - x_k), \quad \forall j < k$$

---

## 5. Metric Correspondence & Honest Comparison Principles

Because BASIL-OPT is an offline oracle, direct metric comparison with causal online schedulers requires strict consistency:

| Metric | Simulator Formula (BASIL-PSA / FIFO / RR / SP) | BASIL-OPT Formula |
|---|---|---|
| **Semantic Goodput** | $\frac{\sum_{p \in \text{Delivered}} w_p \cdot \text{size}_p \cdot 8}{T_{\text{sim}} \cdot 10^6}\text{ Mbps}$ | $\frac{\sum_{k} x_k \cdot w_k \cdot s_k \cdot 8 \cdot q_{d_k}}{T_{\text{sim}} \cdot 10^6}\text{ Mbps}$ |
| **Packet Delivery Ratio** | $\frac{N_{\text{ontime}} + N_{\text{late}}}{N_{\text{generated}}}$ | $\frac{\sum_k x_k}{K}$ |
| **Deadline Misses** | $N_{\text{with\_deadline}} - N_{\text{ontime}}$ | $K_{\text{with\_deadline}} - \sum_{k: D_k > 0} x_k$ |
| **Mean Latency** | $\frac{1}{N_{\text{del}}} \sum_{p} (t_{\text{del}} - a_p)\text{ ms}$ | $\frac{1}{\sum x_k} \sum_{k: x_k=1} (t_k + \tau_k - a_k) \cdot 1000\text{ ms}$ |
| **Jain's Fairness Index** | $\frac{(\sum x_i)^2}{N \sum x_i^2}$ across device throughputs | $\frac{(\sum \text{th}_d)^2}{N \sum \text{th}_d^2}$ across device throughputs |

### 5.1 Optimality Gap
The normalized optimality gap between the online scheduler and BASIL-OPT is formally defined as:
$$\text{Gap}_{\text{Semantic}} = \frac{\text{Goodput}_{\text{OPT}} - \text{Goodput}_{\text{Online}}}{\text{Goodput}_{\text{OPT}}} \times 100\%$$
A gap of $0\%$ denotes that the causal scheduler matched the theoretical offline ceiling.
