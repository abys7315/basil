# BASIL-PSA Mathematical Specification & Research Model

**Algorithm Title:** BASIL-PSA (**B**urst-**A**ware **S**emantic **I**ntelligence for **L**i-Fi — **P**redictive **S**cheduling **A**lgorithm)  
**Document Version:** 2.2.0 (Phase 2.2 Algorithm Improvement & Predictor Overhaul)  
**Status:** Rigorously Implemented, Corrected & Experimentally Validated  
**Simulation Engine:** ns-3.42 (Discrete-Event Network Simulator)  

---

## 1. Algorithmic Identity & Architecture

BASIL-PSA is a cross-layer scheduling algorithm engineered specifically for optical wireless Li-Fi networks. It optimizes packet dispatch decisions in the presence of:
1. Heterogeneous semantic packet classes with hard deadline constraints.
2. Non-uniform spatial optical line-of-sight (LOS) path attenuation and user orientation changes.
3. Sudden traffic surges and Poisson bursts.
4. Channel starvation risks for best-effort devices.

### Scheduling Paradigm Comparison
- **FIFO:** Single/multi-queue First-In First-Out. Oblivious to channel condition, deadlines, and semantic priority.
- **Round Robin (RR):** Enforces round-robin service across device queues. Guarantees long-term device fairness, but ignores packet expiration and emergency priority tiers.
- **Strict Priority (SP):** Prioritizes higher priority classes strictly over lower tiers. Causes total starvation of best-effort devices under sustained overload, and blindly schedules transmissions even if the destination channel has high Packet Error Rate ($\text{PER} \approx 1.0$).
- **BASIL-PSA:** Evaluates an instantaneous multi-objective composite priority scoring function $S(p, t) \in [0, 1]$ over head-of-line candidate packets across all active device queues, balancing semantic utility, residual deadline slack, predicted queue surge pressure, physical optical channel success probability, queue backlog, and anti-starvation aging.

---

## 2. Complete Mathematical Model

At dispatch time $t$, the scheduler examines the candidate head-of-line packets from each non-empty device queue $d \in \{0, \dots, N-1\}$ and dispatches the packet maximizing $S(p, t)$:

$$p^* = \arg\max_{p \in \text{Candidate}} S(p, t)$$

$$S(p, t) = \tilde{w}_s \cdot \mathcal{I}_{\text{semantic}}(p) + \tilde{w}_u \cdot \mathcal{U}_{\text{urgency}}(p, t) + \tilde{w}_b \cdot \mathcal{B}_{\text{pred}}(d, t) + \tilde{w}_c \cdot \mathcal{C}_{\text{optical}}(d) + \tilde{w}_q \cdot \mathcal{Q}_{\text{pressure}}(d, t) + \tilde{w}_f \cdot \mathcal{F}_{\text{fairness}}(d, t)$$

### 2.1 Weight Normalization & Invariant
Nominal weights strictly sum to $1.000$:

| Component | Symbol | Nominal Value | Functional Role |
|---|---|---|---|
| Semantic Importance | $w_s$ | $0.20$ | Intrinsic contextual value of payload |
| Deadline Urgency | $w_u$ | $0.25$ | Proximity to packet delivery expiration |
| Burst Prediction | $w_b$ | $0.15$ | Proactive forecast of impending queue surge |
| Optical Channel Quality | $w_c$ | $0.15$ | Physical transmission success probability ($1 - \text{PER}$) |
| Queue Backlog Pressure | $w_q$ | $0.15$ | Buffer overflow mitigation |
| Anti-Starvation Aging | $w_f$ | $0.10$ | Dynamic service guarantee for low-priority nodes |
| **Sum** | $\sum w_i$ | **$1.000$** | **Strict Unit Normalization** |

To guarantee mathematical consistency under ablation or runtime configuration changes, dynamic normalization is applied:
$$\tilde{w}_i = \frac{w_i \cdot \mathbf{1}_{\{\text{active}(i)\}}}{\sum_{k} w_k \cdot \mathbf{1}_{\{\text{active}(k)\}}}$$
ensuring that $\sum \tilde{w}_i = 1.000$ and $S(p, t) \in [0, 1]$ across all operational states.

---

## 3. Component Formulations

### 3.1 Semantic Importance $\mathcal{I}_{\text{semantic}}(p) \in [0, 1]$
Quantifies payload contextual utility across 4 defined priority classes:
$$\mathcal{I}_{\text{semantic}}(p) = \begin{cases}
1.00, & \text{Class 3 (Emergency Telemetry / Safety-Critical Control)} \\
0.70, & \text{Class 2 (Real-time Periodic Sensor Telemetry)} \\
0.50, & \text{Class 1 (Interactive Streaming / Multimedia)} \\
0.20, & \text{Class 0 (Best-effort Bulk Data Transfer)}
\end{cases}$$

### 3.2 Deadline Urgency $\mathcal{U}_{\text{urgency}}(p, t) \in [0, 1]$
Represents urgency as an exponential decay function of residual slack time:
$$\text{slack}(p, t) = t_{\text{deadline}}(p) - t$$
$$\mathcal{U}_{\text{urgency}}(p, t) = \begin{cases}
1.0, & \text{slack}(p, t) \le 0 \quad (\text{Overdue or imminent}) \\
\exp\left(-\frac{\text{slack}(p, t)}{\tau_{\text{urgency}}}\right), & \text{slack}(p, t) > 0 \\
0.0, & t_{\text{deadline}}(p) = -1.0 \quad (\text{Best effortFlow, no deadline})
\end{cases}$$
where $\tau_{\text{urgency}} = 20\text{ ms}$ is the scaling characteristic time constant.

### 3.3 Proactive Burst Prediction $\mathcal{B}_{\text{pred}}(d, t) \in [0, 1]$

#### 3.3.1 Historical Instantaneous Error Root Cause
In Phase 2.1, updating EWMA on every packet via $\lambda_{\text{instant}} = 1.0 / \Delta t$ caused singular rate spikes when Poisson packets arrived in close proximity ($\Delta t \approx 0.0002\text{ s}$), predicting hundreds of packets in a 100ms window where only 20 actually arrived.

#### 3.3.2 Window-Level Discrete-Time Count Predictors
Phase 2.2 transitions to windowed counting over non-overlapping windows $w$ of length $W = 100\text{ ms}$:

1. **Discrete-Time Count EWMA ($\alpha = 0.25$):**
   $$\hat{N}_{w+1} = (1 - \alpha) \hat{N}_w + \alpha N_w^{\text{actual}}$$
   Where $N_w^{\text{actual}}$ is the actual observed packet arrivals in window $w$.

2. **CUSUM (Cumulative Sum) Change-Point Detector:**
   Tracks cumulative positive deviation above the baseline mean arrival $\mu_0$:
   $$S_w^+ = \max\left(0, S_{w-1}^+ + N_w^{\text{actual}} - (\mu_0 + k)\right)$$
   where $k = 0.5 \sigma_0$ is the reference allowance and $h = 4.0 \sigma_0$ is the decision threshold.
   When $S_w^+ > h$, an optical burst state is detected, scaling predicted arrival to the burst rate:
   $$\hat{N}_{w+1} = \begin{cases} \mu_{\text{burst}}, & \text{if } S_w^+ > h \\ (1 - \alpha)\hat{N}_w + \alpha N_w^{\text{actual}}, & \text{otherwise} \end{cases}$$

3. **Burst Pressure Sigmoid:**
   The forecasted arrival count is normalized into scheduling pressure $\mathcal{B}_{\text{pred}} \in [0, 1]$:
   $$\rho_{\text{forecast}} = \frac{\hat{N}_{w+1}}{W \cdot \mu_{\text{service}}}$$
   $$\mathcal{B}_{\text{pred}}(d, t) = \frac{1}{1 + \exp\left(-5.0 \cdot (\rho_{\text{forecast}} - 0.40)\right)}$$

### 3.4 Optical Channel Quality $\mathcal{C}_{\text{optical}}(d) \in [0, 1]$
Derived directly from the physical Lambertian optical line-of-sight model:
$$\mathcal{C}_{\text{optical}}(d) = 1.0 - \min(1.0, \text{PER}_d) = (1 - \text{BER}_d)^L$$
where $\text{BER}_d = \frac{1}{2} \text{erfc}\left(\sqrt{\frac{\text{SNR}_d}{2}}\right)$, and $\text{SNR}_d$ is evaluated from received optical power $P_r = P_t \cdot H_{\text{LOS}}(d)$ and total shot/thermal noise variance $\sigma^2$.

### 3.5 Queue Backlog Pressure $\mathcal{Q}_{\text{pressure}}(d, t) \in [0, 1]$
$$\mathcal{Q}_{\text{pressure}}(d, t) = 1.0 - \exp\left(-\frac{|Q_d(t)|}{15}\right)$$

### 3.6 Anti-Starvation Aging $\mathcal{F}_{\text{fairness}}(d, t) \in [0, 1]$
Tracks elapsed time since device $d$ was last serviced:
$$\Delta t_{\text{unserviced}}(d, t) = t - t_{\text{last\_served}}(d)$$
$$\mathcal{F}_{\text{fairness}}(d, t) = 1.0 - \exp\left(-\frac{\Delta t_{\text{unserviced}}(d, t)}{\tau_{\text{starve}}}\right)$$
where $\tau_{\text{starve}} = 50\text{ ms}$. As $\Delta t_{\text{unserviced}}$ increases, $\mathcal{F}_{\text{fairness}} \to 1.0$, boosting the device's composite score and ensuring service interleaving.

---

## 4. Optical Coverage Topologies

To disentangle MAC scheduling fairness from physical path loss attenuation, BASIL-PSA supports three configurable spatial geometries:
1. **Radial Geometry (`coverage_mode: "radial"`):**
   $$d_i = \sqrt{h^2 + (0.5 + i \times 0.45)^2}\text{ m}$$
   Devices with $i \ge 4$ extend beyond $2.5\text{ m}$, experiencing optical extinction ($\text{PER} \to 1.0$).
2. **Dense Viable Coverage (`coverage_mode: "viable"`):**
   $$d_i \in [0.9\text{ m}, 2.0\text{ m}], \quad \forall i \in \{0, \dots, N-1\}$$
   All devices reside within the line-of-sight optical cone ($\text{PER} < 0.02$). Isolates pure MAC scheduling behavior.
3. **Mixed Optical Coverage (`coverage_mode: "mixed"`):**
   $50\%$ of devices reside in viable near-LOS ($d \le 1.8\text{ m}$); $50\%$ reside in moderate edge conditions ($d \in [2.2\text{ m}, 2.8\text{ m}], \text{PER} \approx 0.40$).

---

## 5. Packet Accounting Conservation Law

For every simulation run, the five-way mutually exclusive conservation law holds identically:
$$N_{\text{total\_generated}} \equiv N_{\text{delivered\_on\_time}} + N_{\text{delivered\_late}} + N_{\text{lost\_channel}} + N_{\text{dropped\_queue}} + N_{\text{pending\_queue}}$$

From this, derived metrics are unambiguously defined:
$$\text{PDR} = \frac{N_{\text{delivered\_on\_time}} + N_{\text{delivered\_late}}}{N_{\text{total\_generated}}}$$
$$\text{Packet Loss Rate} = 1.0 - \text{PDR}$$
$$\text{Deadline Success Rate} = \frac{N_{\text{delivered\_on\_time}}}{N_{\text{total\_generated}}}$$
$$\text{Semantic Goodput} = \frac{\sum_{p \in \text{Delivered\_On\_Time}} \mathcal{I}_{\text{semantic}}(p) \cdot \text{size}(p) \cdot 8}{T_{\text{sim}} \cdot 10^6} \quad (\text{Mbps})$$
