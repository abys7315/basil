# NS-3 Source Code Audit & Integration Analysis

**Document Version:** 1.0.0  
**Target File:** `ns3-lifi/scratch/basil-ns3-sim.cc`  
**ns-3 Release:** `ns-3.42` (x86_64, built in WSL2 Ubuntu 24.04 via CMake/Ninja)  
**Verification Date:** November 2026  

---

## 1. Executive Summary

This audit assesses the actual degree of ns-3 integration in `basil-ns3-sim.cc` versus custom C++ abstractions. 

### Implementation Classification Status
* **ns-3 Event Engine & Core Architecture:** **IMPLEMENTED** (Uses native `ns3::Simulator`, `ns3::Time`, `ns3::Packet`, `ns3::NodeContainer`).
* **Discrete-Event Simulation (DES) Scheduling:** **IMPLEMENTED** (Packet arrivals, transmissions, and telemetry sampling scheduled via `Simulator::Schedule()`).
* **Li-Fi PHY/MAC as Native ns-3 Subclasses (`ns3::NetDevice`, `ns3::Channel`):** **PARTIALLY IMPLEMENTED / APPLICATION-LEVEL EMULATION**.
  - Rather than inheriting from `ns3::Channel` and `ns3::NetDevice`, optical channel propagation and transmission queueing are implemented in custom C++ classes and orchestrated via ns-3 simulator events.
* **Open-Source VLC Framework Integration (e.g., Aldalbahias/VLC):** **STANDALONE ADAPTATION** (Analytical physics derived from academic VLC literature without compiling external community modules).

---

## 2. Inventory of ns-3 Modules and APIs Used

### A. Included ns-3 Headers
```cpp
#include "ns3/core-module.h"       // Core types, logging, attributes, random variables
#include "ns3/network-module.h"    // Node, NodeContainer, Packet, Header
#include "ns3/simulator.h"         // Simulator::Schedule, Run, Stop, Destroy, Now
#include "ns3/nstime.h"            // Seconds(), Time::SetResolution(Time::NS)
#include "ns3/packet.h"            // Ptr<Packet>, Create<Packet>(pkt_size)
```

### B. Specific ns-3 APIs Invoked in `basil-ns3-sim.cc`
| ns-3 API Call | Location | Purpose | Integration Level |
|---|---|---|---|
| `Time::SetResolution(Time::NS)` | Line 512 | Sets global time resolution to nanoseconds | Native ns-3 Core |
| `NodeContainer nodes; nodes.Create(N+1)` | Line 513-514 | Allocates topology nodes (1 AP + N User Devices) | Native ns-3 Network |
| `Create<Packet>(pkt_size)` | Line 579 | Instantiates native ns-3 reference-counted packet payload | Native ns-3 Network |
| `Simulator::Now().GetSeconds()` | Lines 414, 438, 457, 464 | Obtains discrete event simulation timestamp | Native ns-3 Core |
| `Simulator::Schedule(Seconds(t), ...)` | Lines 451, 474, 580 | Registers discrete events on ns-3 scheduler wheel | Native ns-3 Core |
| `Simulator::Stop(Seconds(sim_time))` | Line 587 | Bounds the simulation time horizon | Native ns-3 Core |
| `Simulator::Run()` | Line 588 | Executes the discrete-event processing loop | Native ns-3 Core |
| `Simulator::Destroy()` | Line 589 | Cleans up ns-3 simulation context and memory | Native ns-3 Core |

---

## 3. Dissection: ns-3 Functionality vs. Custom C++ Logic

To provide complete research transparency, the table below maps each networking subsystem to its actual implementation:

| Subsystem | ns-3 Component | Custom C++ Component | Audit Assessment |
|---|---|---|---|
| **Event Execution** | `ns3::Simulator::Schedule`, `ns3::Simulator::Run` | None | **Native ns-3**: Real event calendar and scheduler wheel. |
| **Packet Representation** | `Ptr<ns3::Packet>` | `struct BasilPacket` wrapping `Ptr<Packet>` with metadata (deadline, priority, arrival time) | **Hybrid**: Uses ns-3 packet allocations wrapped with application-layer tags. |
| **Node Topology** | `ns3::NodeContainer` | `std::vector<DeviceStats>` | **Hybrid**: ns-3 nodes created, device channel states stored in custom struct. |
| **Queueing & Buffering** | None (`ns3::Queue` / `QueueDisc` not subclassed) | `std::queue<BasilPacket>`, `std::deque<BasilPacket>` | **Custom C++**: Standard library queues. |
| **Queue Scheduling (MAC)** | None (`ns3::TrafficControlLayer` not used) | `FIFOScheduler`, `RoundRobinScheduler`, `StrictPriorityScheduler`, `BASILPSAScheduler` | **Custom C++**: Schedulers implemented via standard C++ polymorphism. |
| **Optical Channel** | None (`ns3::Channel` not subclassed) | `namespace lifi` (Lambertian LOS equation, noise calculation) | **Custom Physics Engine**: Real analytical optical equations executed at simulation initialization. |
| **Error Modeling** | None (`ns3::RateErrorModel` not subclassed) | Monte-Carlo PER drawing against uniform distribution in `TryTransmitNext()` | **Custom DES Logic**: PER computed from analytical SNR and evaluated per packet. |
| **Traffic Generation** | None (`ns3::OnOffApplication` not used) | `std::exponential_distribution<double>` Poisson arrival generator | **Custom Event Generator**: Events pre-scheduled onto `ns3::Simulator`. |

---

## 4. Transmission Pipeline & Event Workflow

```
[Poisson Traffic Generator]
          │
          │ ns3::Simulator::Schedule(Seconds(t), &PacketArrivalEvent)
          ▼
   PacketArrivalEvent()
          │ Enqueues into active LifiScheduler (FIFO / RR / SP / BASIL-PSA)
          ▼
    TryTransmitNext()
          │ Checks optical transmitter status
          │ Dequeues next packet according to scheduling policy
          │ Evaluates optical channel PER (Analytical SNR & OOK BER)
          │ Computes optical airtime: (size_bytes * 8) / data_rate_bps
          │
          │ ns3::Simulator::Schedule(Seconds(tx_duration), &TransmitDone)
          ▼
     TransmitDone()
          │ Updates latency, throughput, delivery/drop telemetry
          │ Checks deadline miss status
          ▼
    TryTransmitNext() (Recursive pipeline dispatch)
```

---

## 5. Audit Conclusions & Technical Labeling

1. **What `basil-ns3-sim.cc` IS**:
   - A genuine C++ simulation executable linked against official `libns3.42-core.so` and `libns3.42-network.so`.
   - An event-driven simulator running on the official **ns-3.42 event execution engine** (`Simulator::Run()`).
   - A physically accurate implementation of the Lambertian optical wireless LOS channel and OOK error model.

2. **What `basil-ns3-sim.cc` IS NOT**:
   - It is **not** a full IEEE 802.15.7 ns-3 PHY/MAC module inheriting from `ns3::NetDevice` and `ns3::Channel`.
   - It does not use the ns-3 socket layer (`ns3::Socket`) or standard traffic control (`ns3::QueueDisc`).

> **Architectural Recommendation for Future ns-3 Expansion:**
> To promote this prototype to a fully native ns-3 module in subsequent milestones:
> 1. Derive `LifiChannel` from `ns3::Channel`.
> 2. Derive `LifiNetDevice` from `ns3::NetDevice`.
> 3. Implement BASIL-PSA as an `ns3::QueueDisc` within the `ns3::TrafficControlLayer`.
