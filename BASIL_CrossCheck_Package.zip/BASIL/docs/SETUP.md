# BASIL Setup and User Guide

This guide details instructions for setting up the BASIL environment, starting all system components, running your first experiment, and troubleshooting common issues.

---

## 1. System Requirements & Prerequisites

Ensure the following tools are installed on your workstation:
- **Operating System**: Windows 10/11 (or Linux / Ubuntu WSL)
- **Python**: Version 3.10 or later (installed on `PATH`)
- **Node.js**: Version 16 LTS or later (with `npm`)
- **C++ Compiler**: MinGW-w64 (`g++.exe`) supporting C++17

---

## 2. Step-by-Step Installation

### Step 1: Build the C++ Simulator
The Li-Fi simulation engine is located in `ns3-lifi/`. Compile the executable:

```cmd
cd ns3-lifi
build.bat
```
*Note: This generates `scratch\basil-sim.exe`. You can verify by running `scratch\basil-sim.exe`.*

### Step 2: Set Up & Launch the Backend API
Install required Python dependencies and start the Uvicorn server:

```cmd
cd backend
pip install -r requirements.txt
start.bat
```
The FastAPI backend starts on `http://localhost:8000`. You can inspect endpoints via Swagger at `http://localhost:8000/docs`.

### Step 3: Set Up & Launch the Frontend Application
Install client npm dependencies and launch the Vite development server:

```cmd
cd desktop-app
npm install
npm run dev
```
The user interface starts on `http://localhost:5173`.

### Step 4: Open Browser
Navigate your browser to:
```
http://localhost:5173
```

---

## 3. One-Click Startup Script

For quick execution without opening multiple terminal windows manually, launch:

```cmd
start-all.bat
```
This script opens separate terminal windows for the backend and frontend servers and directs you to `http://localhost:5173`.

---

## 4. Running Your First Experiment

1. **Access the Configuration Tab**:
   - In the navigation bar, click **Configure**.
2. **Define a Network Configuration**:
   - Give your configuration a name (e.g. `Office_Room_5x5`).
   - Specify `num_devices` (e.g. `4`).
   - Configure optical parameters: Room dimensions, AP power (`50` mW), semi-angle (`60` deg), and bandwidth.
   - Click **Save Network Configuration**.
3. **Define a Traffic Configuration**:
   - Specify name (e.g. `Mixed_Bursty_Profile`).
   - Set normal arrival rate (`100` pps), burst arrival rate (`500` pps), and burst ratio (`0.2`).
   - Select packet size (e.g. `1024` bytes).
   - Click **Save Traffic Configuration**.
4. **Create & Execute Experiment**:
   - Go to the **Dashboard** or **Experiments** tab.
   - Click **New Experiment**.
   - Select your saved Network and Traffic configurations.
   - Choose a scheduling policy (e.g., `BASIL-PSA` or `RoundRobin`).
   - Set simulation duration (e.g., `5.0` seconds).
   - Click **Run Experiment**.
5. **View Results & Analytics**:
   - Once the simulation completes, inspect the metric summary cards: Average Latency, Throughput (Mbps), Packet Delivery Ratio (PDR), Packet Loss, and Fairness Index.
   - Interact with the Plotly time-series charts to observe throughput dynamics during burst periods.
   - Click **Export CSV** to download raw per-device statistics for offline analysis.

---

## 5. Troubleshooting Common Issues

### Issue: `g++.exe` is not recognized
- **Cause**: MinGW is not included in the system `PATH`.
- **Fix**: Open `ns3-lifi\build.bat` and verify that the compiler points to your installed MinGW directory (e.g., `C:\MinGW\bin\g++.exe`), or add MinGW to your system Environment Variables.

### Issue: Port 8000 or 5173 is already in use
- **Cause**: Another service or orphaned Python/Node process is binding the port.
- **Fix**: Check active ports:
  ```powershell
  netstat -ano | findstr :8000
  taskkill /PID <PID> /F
  ```

### Issue: Frontend fails to connect to backend
- **Cause**: The backend service is not running or proxy is misconfigured.
- **Fix**: Verify backend health by checking `http://localhost:8000/health`. Ensure `desktop-app/vite.config.ts` includes proxy settings forwarding `/api` to `http://localhost:8000`.

### Issue: SQLite Database Lock
- **Cause**: Concurrent process accessing `experiments/basil.db`.
- **Fix**: Close any external database browser tools or orphan uvicorn workers. If needed, the database file at `experiments/basil.db` can be safely deleted; the backend will re-initialize schemas automatically on startup.
