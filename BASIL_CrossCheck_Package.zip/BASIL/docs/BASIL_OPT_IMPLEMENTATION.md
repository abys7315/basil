# BASIL-OPT: Implementation Architecture & Solver Integration

**Document Version:** 1.0  
**Phase:** 3 — Offline Optimization Reference  
**Platform:** ns-3.42 / C++17 Hybrid Engine, Python 3.10, HiGHS 1.16.0, React 18 / Vite  

---

## 1. Executive Summary

This document specifies the software architecture, solver interfaces, and algorithmic workflows implementing **BASIL-OPT**, the offline optimization oracle for the BASIL Li-Fi research framework. BASIL-OPT provides a rigorous, mathematically sound benchmark representing the theoretical maximum achievable performance under complete future knowledge of packet arrivals, deadlines, channel conditions, and semantic weights.

BASIL-OPT does not replace the online scheduling pipeline or claim real-time execution in embedded hardware. Rather, it serves as an offline ground truth against which online heuristics—most notably **BASIL-PSA**—can be objectively benchmarked to quantify their optimality gap.

---

## 2. Architecture Overview

The BASIL-OPT subsystem bridges ns-3's discrete-event optical physics simulation engine with the HiGHS mathematical programming solver through an exact, non-lossy trace pipeline:

```
+-------------------------------------------------------------------------------+
|                       Phase 3 Simulation & Solver Architecture                |
+-------------------------------------------------------------------------------+
|                                                                               |
|  [ Experiment Configuration ]                                                 |
|          |                                                                    |
|          v                                                                    |
|  [ ns-3.42 Li-Fi Hybrid Engine (WSL Ubuntu) ]                                 |
|     * Lambertian LOS optical propagation                                      |
|     * Photodiode responsivity, FOV, concentrator gain                         |
|     * Shot noise, thermal noise, SNR calculation                              |
|     * OOK BER and Packet Error Rate (PER) per device                          |
|     * Exact Poisson / burst packet generation with semantic tags              |
|     * Trace Export (`export_trace: 1.0`)                                      |
|          |                                                                    |
|          v Exact Packet Arrivals, Deadlines, Semantic Weights, Device PERs    |
|  [ SimulationRunner (runner.py) ]                                             |
|          |                                                                    |
|          v                                                                    |
|  [ BasilOptSolver (basil_opt.py) ]                                            |
|     * Slotted Maximum-Weight Matching MILP Formulation                        |
|     * Native HiGHS 1.16.0 Solver (`highspy.Highs`)                            |
|     * Total Unimodularity exploitation & branch-and-cut                       |
|     * Reconstructs optimal schedule, timestamps, and outcome accounting       |
|          |                                                                    |
|          v Optimal Schedule & Multi-Metric Telemetry                          |
|  [ Aggregated Result Payload ] -------------------+                           |
|          |                                        |                           |
|          v                                        v                           |
|  [ React / Vite Desktop App ]           [ Experiment Analytics ]              |
|  * Algorithm Lab UI                     * basil_opt_results.json              |
|  * MIP Gap & Runtime display            * Optimality Gap & Ratio Analysis     |
+-------------------------------------------------------------------------------+
```

---

## 3. Solver Implementation: `BasilOptSolver`

The solver is implemented in `backend/app/algorithms/basil_opt.py` as `BasilOptSolver`. It features two distinct formulations:

### 3.1 Slotted Formulation (`solve_slotted`)

The primary production engine decomposes time into discrete optical transmission slots of duration:
$$\tau_{\text{slot}} = \frac{L \times 8}{R_{\text{data}}}$$
where $L$ is the packet size in bytes and $R_{\text{data}}$ is the Li-Fi data rate in bps.

#### Problem Formulation:
- **Decision Variables:** Binary variable $y_{k, m} \in \{0, 1\}$ denoting whether packet $k$ is transmitted in slot $m$.
- **Eligibility Filter:** Pair $(k, m)$ is generated only if:
  1. $t_m^{\text{start}} \ge a_k$ (Arrival causality)
  2. $t_m^{\text{end}} \le d_k^{\text{eff}}$ (Deadline satisfaction, where $d_k^{\text{eff}} = d_k$ if $d_k > 0$, else $\min(T_{\text{sim}}, a_k + W_{\max})$ with buffer horizon $W_{\max} = 100\text{ ms}$)
  3. $t_m^{\text{end}} \le T_{\text{sim}}$ (Horizon constraint)
- **Objective Function:**
  $$\min \sum_{(k, m) \in \mathcal{E}} - \left( w_k \cdot 8L \cdot (1 - \text{PER}_{d(k)}) - \epsilon \cdot (t_m^{\text{end}} - a_k) \right) y_{k, m}$$
  where $\epsilon = 10^{-6}$ acts as a tie-breaker favoring earlier dispatch.
- **Constraints:**
  1. *Packet Uniqueness:* For each packet $k$, $\sum_{m: (k, m) \in \mathcal{E}} y_{k, m} \le 1$
  2. *Channel Exclusivity:* For each slot $m$, $\sum_{k: (k, m) \in \mathcal{E}} y_{k, m} \le 1$

#### Mathematical Structure & Efficiency:
Because each variable $y_{k, m}$ appears in at most one packet constraint and at most one slot constraint with all coefficients equal to $+1$, the constraint matrix $A$ is **totally unimodular**. HiGHS solves this bipartite matching structure with polynomial speed and provable zero MIP gap.

### 3.2 Continuous-Time Disjunctive Formulation (`solve_continuous`)

For small-scale verification without time discretization, `solve_continuous()` implements a disjunctive Big-M MILP:
- Continuous start times $t_k \in [0, T_{\text{sim}}]$
- Binary transmission selection $x_k \in \{0, 1\}$
- Binary sequencing variables $z_{j, k} \in \{0, 1\}$ enforcing non-preemptive exclusivity:
  $$t_j + \tau_j - t_k \le M(1 - z_{j, k}) + M(2 - x_j - x_k)$$
  $$t_k + \tau_k - t_j \le M z_{j, k} + M(2 - x_j - x_k)$$
- Guaranteed exact agreement with `solve_slotted()` on manual test scenarios.

---

## 4. Integration with Experiment Runner

In `backend/app/simulation/runner.py`, when `config["scheduler"] == "BASIL_OPT"`:
1. `SimulationRunner` executes the authentic ns-3.42 Li-Fi simulator inside WSL Ubuntu with `export_trace: 1.0`.
2. ns-3 simulates physical channel propagation, Lambertian optical path gain, receiver SNR, and per-device PER, and emits the complete packet trace.
3. `SimulationRunner` instantiates `BasilOptSolver` and solves the instance.
4. Output metrics are normalized into standard BASIL schema (PDR, goodput, latency, p95, deadline misses, Jain fairness, solver status, MIP gap, runtime).

---

## 5. Desktop Application Integration

In `desktop-app/src/pages/AlgorithmLab.tsx`:
- Added `BASIL_OPT` to `ALGORITHMS` roster: `"BASIL-OPT (Offline Oracle)"`.
- The user can select `BASIL_OPT` alongside `FIFO`, `RoundRobin`, `StrictPriority`, and `BASIL_PSA`.
- When simulation completes, a dedicated Optimization Reference Banner displays:
  - Solver Engine (`HiGHS-1.16.0`)
  - Status (`Optimal`)
  - MIP Optimality Gap (`0.00%`)
  - Execution Wall Time

---

## 6. Verification & Regression Testing

The optimization subsystem is validated by automated regression tests in `backend/tests/test_basil_opt.py`:
1. `test_basil_opt_solver_feasibility_manual_instance`: Known 3-packet scheduling instance with exact analytical solution.
2. `test_basil_opt_uniqueness_and_exclusivity`: Overload scenario verifying no packet is transmitted twice and no slot is double-booked.
3. `test_basil_opt_channel_reliability_weighting`: Verifies solver trades off raw semantic weight against channel packet error rate (PER).
4. `test_basil_opt_continuous_formulation`: Continuous Big-M disjunctive formulation parity test.
5. `test_simulation_runner_basil_opt_integration`: Full end-to-end integration test through `SimulationRunner` and ns-3 hybrid engine verifying the packet conservation law.

All tests pass 100% with zero regressions.
