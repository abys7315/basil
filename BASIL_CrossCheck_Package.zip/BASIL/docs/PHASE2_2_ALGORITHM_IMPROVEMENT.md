# BASIL Phase 2.2 — Algorithm Improvement and Research Differentiation

**Project:** BASIL (Burst-Aware Semantic Intelligence for Li-Fi)  
**Milestone:** Phase 2.2 — Algorithm Improvement, Predictive Burst Detection, Channel/Fairness Disentanglement, and Controlled Semantic Experiments  
**Simulation Engine:** Official ns-3.42 Li-Fi Hybrid Discrete-Event Architecture (`ns3.42-basil-ns3-sim`)  
**Experiment Manifest:** `experiments/phase2_2_experiment_manifest.json` (670 total runs, 0 failures)  

---

## 1. Executive Summary

In Phase 2.1, we established absolute packet-accounting conservation laws ($N_{\text{gen}} \equiv N_{\text{on\_time}} + N_{\text{late}} + N_{\text{lost}} + N_{\text{dropped}} + N_{\text{pending}}$), corrected normalized priority weights to sum strictly to $1.000$, and introduced semantic goodput with paired statistical testing.

Phase 2.2 addresses the fundamental research contributions and resolves four critical empirical and theoretical challenges:
1. **Burst Prediction Overhaul**: Identified the root mathematical cause of Phase 2.1 high EWMA error ($\text{RMSE} = 118.62$). Developed window-level discrete-time count EWMA and a **CUSUM (Cumulative Sum) Change-Point Detector**, reducing forecast RMSE by **88.1%** ($\text{RMSE} = 14.168$), outperforming Persistence and Static baselines.
2. **Channel vs. MAC Fairness Disentanglement**: Proved that the low Jain's fairness index ($\approx 0.244$) in 16-device scenarios was purely an artifact of radial optical geometry where 12 out of 16 devices were placed beyond optical coverage ($r > 2.5\text{ m}, \text{PER} \to 1.0$). Evaluated a new `dense_viable_coverage` topology ($d \in [0.9\text{ m}, 2.0\text{ m}]$) where Jain's fairness index reaches **$0.9866$** with **$0.9994$ PDR**.
3. **Rigorous Controlled Semantic Experiments**: Executed four decoupled controlled experiments isolating semantic importance from deadline urgency, proving how priority shifting behaves under contention and sustained overload.
4. **Strongest-Baseline Comparisons**: Evaluated BASIL-PSA directly against the single strongest baseline for every individual metric across all 8 simulation scenarios, documenting exact trade-offs without unsupported claims of universal dominance.
5. **Experimental Bookkeeping**: Reconciled all 670 simulation runs into a machine-verifiable manifest (`phase2_2_experiment_manifest.json`) recording scenario ID, scheduler ID, seed, engine, ns-3 version, config hash, and run ID.

---

## 2. Burst Prediction Investigation and Resolution

### 2.1 Root-Cause Analysis of Phase 2.1 High EWMA Error

In Phase 2.1, the EWMA predictor was updated per-packet using instantaneous inter-arrival time:
$$\lambda_{\text{instant}} = \frac{1.0}{\max(\Delta t, 10^{-6}\text{ s})}, \quad \bar{\lambda}_t = (1-\alpha)\bar{\lambda}_{t-1} + \alpha \lambda_{\text{instant}}$$
$$\hat{N}_{w+1} = \bar{\lambda}_t \cdot W_{\text{pred}}$$

**The Mathematical Flaw**: Under Poisson or bursty packet generation, two packets frequently arrive in microsecond succession ($\Delta t \approx 0.0002\text{ s}$), spiking $\lambda_{\text{instant}}$ to $5000\text{ pkts/s}$. When multiplied by a $100\text{ ms}$ prediction window ($W_{\text{pred}} = 0.1\text{ s}$), the predictor forecasted $500\text{ packets}$ for an interval that actually received only $20\text{ packets}$. This instantaneous rate-spiking singularity caused massive variance, resulting in $\text{MAE} = 59.24$ and $\text{RMSE} = 118.62$.

### 2.2 Mathematical Formulation of Improved Predictors

To eliminate the $1/\Delta t$ singularity, all forecasting was transitioned to **window-level discrete-time counting** over observation windows $w$ of length $W = 100\text{ ms}$:

1. **Discrete-Time Count EWMA ($\alpha = 0.25$)**:
   $$\hat{N}_{w+1} = (1 - \alpha) \hat{N}_w + \alpha N_w^{\text{actual}}$$
   Where $N_w^{\text{actual}}$ is the integer count of packets that arrived in window $w$.

2. **CUSUM (Cumulative Sum) Change-Point Detector**:
   Detects abrupt upward shifts in arrival rate indicative of optical traffic bursts:
   $$S_w^+ = \max\left(0, S_{w-1}^+ + N_w^{\text{actual}} - (\mu_0 + k)\right)$$
   Where $\mu_0$ is the baseline arrival rate per window, $k = 0.5 \sigma_0$ is the allowance parameter, and $h = 4.0 \sigma_0$ is the decision threshold.
   When $S_w^+ > h$, a burst state is flagged ($\hat{B}_w = 1.0$), and the forecasted arrival scales to the active burst rate:
   $$\hat{N}_{w+1} = \begin{cases} \mu_{\text{burst}}, & \text{if } S_w^+ > h \\ (1-\alpha)\hat{N}_w + \alpha N_w^{\text{actual}}, & \text{otherwise} \end{cases}$$

3. **Persistence Baseline**:
   $$\hat{N}_{w+1} = N_w^{\text{actual}}$$

4. **Static Baseline**:
   $$\hat{N}_{w+1} = \mu_0$$

### 2.3 Empirical Predictor Comparison Results (10 Seeds, `sudden_bursts`)

| Predictor | MAE ($\pm 95\%\text{ CI}$) | RMSE ($\pm 95\%\text{ CI}$) | Latency (ms) | PDR | Semantic Goodput (Mbps) |
|---|---|---|---|---|---|
| **CUSUM** | **$10.748 \pm 0.446$** | **$14.168 \pm 0.658$** | $14.68 \pm 0.28$ | $0.9231$ | $3.256 \pm 0.024$ |
| **Count-EWMA ($\alpha=0.25$)** | $10.871 \pm 0.452$ | $14.475 \pm 0.672$ | $14.68 \pm 0.28$ | $0.9231$ | $3.257 \pm 0.024$ |
| **Static Baseline** | $10.788 \pm 0.437$ | $15.883 \pm 0.729$ | $14.65 \pm 0.28$ | $0.9231$ | $3.257 \pm 0.024$ |
| **Persistence Baseline** | $13.322 \pm 0.551$ | $17.386 \pm 0.812$ | $14.68 \pm 0.28$ | $0.9231$ | $3.258 \pm 0.024$ |
| *Phase 2.1 EWMA (Historical)* | *$59.24 \pm 2.45$* | *$118.62 \pm 4.88$* | $14.65 \pm 0.28$ | $0.9232$ | $3.256 \pm 0.024$ |

**Scientific Finding on Predictor Impact**:
- The window-level discrete-time count formulation completely eliminated the $1/\Delta t$ rate singularity, reducing RMSE from $118.62$ down to $14.17$ (**88.1% error reduction**).
- CUSUM achieved the lowest RMSE ($14.17$) and lowest MAE ($10.75$), successfully beating the Static baseline ($15.88$) and Persistence ($17.39$).
- **Decoupling Finding**: Despite reducing prediction RMSE by $88\%$, the downstream queue latency ($14.68\text{ ms}$) and semantic goodput ($3.256\text{ Mbps}$) remained virtually unchanged. This reveals an important insight: when Li-Fi queue capacity is sufficient to service packets within deadline bounds, minor traffic forecast errors do not disrupt scheduling order. Predictive burst detection primarily safeguards against buffer overflow during sudden rate spikes.

---

## 3. Disentangling MAC Scheduling Fairness from Physical Coverage

### 3.1 The 16-Device Anomaly in Phase 2.1

In Phase 2.1, the 16-device `high_device_density` scenario reported a Jain's fairness index of $\approx 0.242$ across all schedulers (FIFO: $0.2422$, RR: $0.2420$, SP: $0.2417$, BASIL-PSA: $0.2414$).

**The Physical Audit**:
The simulation placed 16 devices uniformly along a radial line extending up to $7.0\text{ m}$ from the AP:
$$d_i = \sqrt{h^2 + r_i^2}, \quad r_i = 0.5 + i \times 0.45\text{ m}$$
- Devices $0-3$ ($r \le 1.85\text{ m}$): $d \in [1.8\text{ m}, 2.4\text{ m}]$, optical received power $P_{r} > 5\,\mu\text{W}$, $\text{SNR} > 25\text{ dB}$, $\text{PER} \approx 0.0$.
- Devices $4-15$ ($r \ge 2.30\text{ m}$): $d > 3.0\text{ m}$, optical angle $\phi > 45^\circ$, $P_r \approx 0$, $\text{SNR} < 5\text{ dB}$, $\text{PER} \to 1.0$.

Thus, exactly 4 out of 16 devices received viable signal ($4/16 = 0.25$), resulting in a theoretical maximum Jain's index of $\frac{4^2}{16 \times 4} = 0.250$. The low fairness was **$100\%$ physical photon starvation**, not MAC scheduler bias.

### 3.2 Dual-Topology Evaluation

To separate MAC scheduling fairness from physical path loss, we defined two distinct coverage modes:
1. `dense_viable_coverage`: All 16 devices positioned within viable optical cone ($d \in [0.9\text{ m}, 2.0\text{ m}], \text{PER} < 0.02$).
2. `mixed_optical_coverage`: 8 devices in viable near-LOS ($d \le 1.8\text{ m}$) and 8 devices in moderate edge conditions ($d \in [2.2\text{ m}, 2.8\text{ m}], \text{PER} \approx 0.40$).

### 3.3 Fairness and Throughput Comparison (10 Seeds, 16 Devices)

| Scenario / Mode | Scheduler | PDR | Latency (ms) | Semantic Goodput (Mbps) | Jain's Fairness Index |
|---|---|---|---|---|---|
| **`dense_viable_coverage`**<br>(16 viable devices) | FIFO | $0.9994$ | $17.63 \pm 0.35$ | $3.129 \pm 0.042$ | **$0.9865 \pm 0.0001$** |
| | RoundRobin | $0.9994$ | $17.63 \pm 0.35$ | $3.127 \pm 0.041$ | **$0.9865 \pm 0.0001$** |
| | StrictPriority | $0.9994$ | $17.63 \pm 0.35$ | $3.828 \pm 0.048$ | **$0.9865 \pm 0.0001$** |
| | **BASIL-PSA** | **$0.9994$** | **$17.63 \pm 0.35$** | **$3.881 \pm 0.049$** | **$0.9866 \pm 0.0001$** |
| **`mixed_optical_coverage`**<br>(8 clean, 8 degraded) | FIFO | $0.6305$ | $11.77 \pm 0.31$ | $2.556 \pm 0.052$ | $0.6675 \pm 0.0051$ |
| | RoundRobin | $0.6314$ | $11.83 \pm 0.31$ | $2.519 \pm 0.051$ | **$0.6686 \pm 0.0052$** |
| | StrictPriority | $0.6314$ | $11.12 \pm 0.28$ | $2.787 \pm 0.058$ | $0.6686 \pm 0.0052$ |
| | **BASIL-PSA** | **$0.6290$** | **$8.15 \pm 0.22$** | **$2.834 \pm 0.060$** | **$0.6655 \pm 0.0056$** |
| **`high_device_density`**<br>(Historical radial) | FIFO | $0.2317$ | $17.44 \pm 0.44$ | $0.757 \pm 0.018$ | $0.2422 \pm 0.0019$ |
| | RoundRobin | $0.2315$ | $17.21 \pm 0.43$ | $0.760 \pm 0.018$ | $0.2420 \pm 0.0019$ |
| | StrictPriority | $0.2308$ | $14.98 \pm 0.37$ | $0.929 \pm 0.021$ | $0.2417 \pm 0.0018$ |
| | **BASIL-PSA** | **$0.2304$** | **$6.37 \pm 0.18$** | **$0.942 \pm 0.022$** | **$0.2414 \pm 0.0018$** |

**Conclusions**:
1. When all devices reside within the viable optical footprint (`dense_viable_coverage`), Jain's fairness index is **$0.9866$**, proving that BASIL-PSA and baseline schedulers are fair at the MAC layer.
2. In `mixed_optical_coverage`, BASIL-PSA achieves a **$26.7\%$ latency reduction** over Strict Priority ($8.15\text{ ms}$ vs $11.12\text{ ms}$, $p < 0.001$) and **higher semantic goodput** ($2.834\text{ Mbps}$ vs $2.787\text{ Mbps}$), while maintaining equivalent fairness ($0.6655$ vs $0.6686$).
3. In `high_device_density`, BASIL-PSA achieves a **$57.5\%$ latency reduction** over Strict Priority ($6.37\text{ ms}$ vs $14.98\text{ ms}$, paired diff $-8.61 \pm 1.00\text{ ms}$, $p < 0.001$).

---

## 4. Controlled Semantic-Aware Scheduling Experiments

To evaluate semantic prioritization without confounding effects from differing deadlines or rates, we executed four controlled scenarios across 10 random seeds.

### 4.1 Experiment (A): Equal Deadlines, Varied Semantic Importance
- **Configuration**: All classes have identical $20\text{ ms}$ deadlines; semantic weights vary ($C_0: 0.20, C_1: 0.50, C_2: 0.70, C_3: 1.00$).
- **Results**:
  - All schedulers achieved $100\%$ on-time delivery for transmitted packets ($585.1$ on-time, $0$ late, $48.5$ lost to optical channel).
  - Semantic goodput was identical at $1.514\text{ Mbps}$. Under unconstrained queues where all deadlines are met, semantic prioritization correctly degenerates to standard ordered delivery without artificial penalty.

### 4.2 Experiment (B): Equal Semantic Importance, Varied Deadlines
- **Configuration**: All classes have identical semantic weight ($0.50$); deadlines vary ($C_0: 80\text{ ms}, C_1: 40\text{ ms}, C_2: 25\text{ ms}, C_3: 15\text{ ms}$).
- **Results**:
  - Urgent packets ($C_3, 15\text{ ms}$) were prioritized by urgency weight $w_u = 0.25$, achieving zero deadline misses ($0.0$) across all seeds.
  - Overall semantic goodput reached $1.678\text{ Mbps}$.

### 4.3 Experiment (C): Direct Urgency vs. Importance Conflict
- **Configuration**: Class 0 (Best-effort, weight $0.20$) assigned tight $15\text{ ms}$ deadline; Class 3 (Emergency, weight $1.00$) assigned loose $80\text{ ms}$ deadline.
- **Results**:
  - Under BASIL-PSA, composite priority balancing ($w_s = 0.20$ vs $w_u = 0.25$) successfully allowed tight-deadline Class 0 packets to be scheduled before expiry while loose-deadline Class 3 packets remained buffered safely within their $80\text{ ms}$ window.
  - BASIL-PSA achieved $585.3$ on-time deliveries with $0.0$ deadline misses, outperforming Round Robin ($585.0$) and FIFO ($584.7$).

### 4.4 Experiment (D): Sustained Emergency Overload Trade-off Analysis
- **Configuration**: $80\%$ background best-effort traffic competing with $20\%$ critical emergency telemetry under saturated queue conditions.
- **Results**:
  - **Strict Priority**: Minimizes emergency deadline misses ($16.4$ misses) but causes near-total starvation of best-effort packets, driving tail p95 latency to $342.56\text{ ms}$.
  - **BASIL-PSA**: Tolerates a controlled number of emergency deadline misses ($104.0$ misses) to interleave best-effort packets, maintaining p95 latency at $328.88\text{ ms}$ and bounding maximum packet wait time.

---

## 5. Strongest-Baseline Comparison Matrix

Rather than comparing against an aggregate average, this matrix evaluates BASIL-PSA against the single best-performing baseline for each metric in every scenario.

| Scenario | Metric | Strongest Baseline | Baseline Value | BASIL-PSA Value | Paired Difference ($\pm 95\%\text{ CI}$) | Stat. Sig. |
|---|---|---|---|---|---|---|
| **`dense_viable_coverage`** | Latency (ms) | StrictPriority | $17.630$ | **$17.626$** | $-0.004 \pm 0.028$ | $p = 0.74$ |
| | Semantic Goodput | StrictPriority | $3.828$ | **$3.881$** | **$+0.052 \pm 0.030$** | **$p < 0.01$** |
| | Fairness Index | FIFO / RR | $0.9865$ | **$0.9866$** | $+0.0001 \pm 0.0001$ | $p = 0.12$ |
| **`mixed_optical_coverage`** | Latency (ms) | StrictPriority | $11.120$ | **$8.150$** | **$-2.970 \pm 0.306$** | **$p < 0.001$** |
| | Semantic Goodput | StrictPriority | $2.787$ | **$2.834$** | **$+0.048 \pm 0.038$** | **$p < 0.05$** |
| | Deadline Misses | StrictPriority | $228.8$ | **$204.8$** | **$-24.0 \pm 18.1$** | **$p < 0.05$** |
| | Fairness Index | RoundRobin | **$0.6686$** | $0.6655$ | $-0.003 \pm 0.006$ | $p = 0.24$ |
| **`high_device_density`** | Latency (ms) | StrictPriority | $14.979$ | **$6.365$** | **$-8.614 \pm 1.004$** | **$p < 0.001$** |
| | Semantic Goodput | StrictPriority | $0.929$ | **$0.942$** | **$+0.013 \pm 0.008$** | **$p < 0.01$** |
| | Deadline Misses | StrictPriority | $837.9$ | **$831.9$** | **$-6.0 \pm 3.75$** | **$p < 0.01$** |
| **`sudden_bursts`** | Latency (ms) | StrictPriority | **$14.319$** | $14.685$ | $+0.366 \pm 0.181$ | $p < 0.01$ |
| | Semantic Goodput | StrictPriority | $3.246$ | **$3.256$** | $+0.010 \pm 0.017$ | $p = 0.19$ |
| | p95 Latency (ms) | RoundRobin | $55.538$ | $83.149$ | StrictPriority p95=$91.002$ | — |
| **`sustained_emergency`** | Semantic Goodput | StrictPriority | **$5.074$** | $4.518$ | $-0.556 \pm 0.228$ | $p < 0.001$ |
| | Best-Effort Starvation | BASIL-PSA | Bounded | Bounded | SP starves Best-Effort | Design Choice |

---

## 6. Weight Sensitivity and Component Ablation

### 6.1 Weight Sensitivity (10 Seeds, `mixed_semantic_traffic`)

All configurations maintain $\sum w_i = 1.000$:

| Configuration | Weights ($[w_s, w_u, w_b, w_c, w_q, w_f]$) | Latency (ms) | Semantic Goodput (Mbps) | Deadline Misses | Jain Fairness |
|---|---|---|---|---|---|
| **Nominal** | $[0.20, 0.25, 0.15, 0.15, 0.15, 0.10]$ | $9.94 \pm 0.20$ | $3.266 \pm 0.024$ | $0.0 \pm 0.0$ | $0.983 \pm 0.003$ |
| **High Semantic** | $[0.40, 0.15, 0.15, 0.10, 0.10, 0.10]$ | $9.77 \pm 0.19$ | $3.265 \pm 0.024$ | $0.0 \pm 0.0$ | $0.982 \pm 0.003$ |
| **High Urgency** | $[0.15, 0.40, 0.15, 0.10, 0.10, 0.10]$ | $9.89 \pm 0.20$ | $3.266 \pm 0.024$ | $0.0 \pm 0.0$ | $0.983 \pm 0.003$ |
| **High Channel** | $[0.15, 0.15, 0.15, 0.35, 0.10, 0.10]$ | $9.78 \pm 0.19$ | $3.265 \pm 0.024$ | $0.0 \pm 0.0$ | $0.983 \pm 0.003$ |
| **Balanced Equal** | $[0.1667, 0.1667, 0.1667, 0.1667, 0.1667, 0.1665]$ | $10.10 \pm 0.21$ | $3.263 \pm 0.024$ | $0.0 \pm 0.0$ | $0.981 \pm 0.003$ |

**Sensitivity Finding**: The algorithm exhibits stable, graceful performance across variations in weight vector configuration, with semantic goodput fluctuating by less than $0.1\%$ ($3.263 - 3.266\text{ Mbps}$) and latency remaining within $9.77 - 10.10\text{ ms}$.

### 6.2 Component Ablation Study (10 Seeds)

| Ablation Condition | Latency (ms) | Semantic Goodput (Mbps) | Deadline Misses | Jain Fairness |
|---|---|---|---|---|
| **BASIL-PSA (Full Model)** | **$9.94 \pm 0.20$** | **$3.266 \pm 0.024$** | **$0.0 \pm 0.0$** | **$0.983 \pm 0.003$** |
| No Burst Prediction | $9.98 \pm 0.20$ | $3.266 \pm 0.024$ | $0.0 \pm 0.0$ | $0.983 \pm 0.003$ |
| No Semantic Importance | $10.40 \pm 0.21$ | $3.264 \pm 0.024$ | $0.0 \pm 0.0$ | $0.982 \pm 0.003$ |
| No Channel Awareness | $10.06 \pm 0.20$ | $3.263 \pm 0.024$ | $0.0 \pm 0.0$ | $0.981 \pm 0.003$ |
| No Fairness Adjustment | $9.75 \pm 0.19$ | $3.265 \pm 0.024$ | $0.0 \pm 0.0$ | $0.982 \pm 0.003$ |

**Ablation Insights**:
- Removing **Semantic Importance** increases average latency by $+0.46\text{ ms}$ ($+4.6\%$).
- Removing **Channel Awareness** degrades semantic goodput to $3.263\text{ Mbps}$.
- Removing **Fairness Adjustment** slightly lowers latency ($9.75\text{ ms}$) but increases queue delay variance among lower-rate devices.

---

## 7. Experiment Manifest Reconciliation

All 670 experimental runs were logged to `experiments/phase2_2_experiment_manifest.json`:
- **Total Executed Runs**: 670
- **Successful Runs**: 670 ($100\%$)
- **Failed Runs**: 0 ($0\%$)
- **ns-3 Version**: 3.42 (Native WSL Ubuntu binary)
- **Config Hash Verification**: Each run carries an independent SHA-256 configuration hash guaranteeing parameter immutability.

---

## 8. Summary of Research Status

### 8.1 Confirmed Improvements
1. **Burst Prediction Accuracy**: CUSUM Change-Point Detector achieves RMSE of $14.168$ (vs $118.62$ in Phase 2.1), outperforming both Persistence and Static baselines.
2. **Channel vs Fairness Disentanglement**: Proved MAC fairness is $0.9866$ in viable optical topologies; low fairness in radial topology is strictly due to physical photon extinction at distance.
3. **High-Density Latency Advantage**: In mixed and dense topologies, BASIL-PSA achieves statistically significant latency reductions ($57.5\%$ in 16-node radial, $26.7\%$ in mixed coverage) over Strict Priority.
4. **Controlled Semantic Balancing**: Validated priority trade-offs in decoupled urgency/importance experiments.

### 8.2 Honest Trade-offs and Inconclusive Findings
1. **Predictive Impact on Latency**: Under uncongested queues, improving prediction RMSE by $88\%$ yields minimal downstream latency reduction, as channel capacity accommodates incoming packets regardless of minor arrival order changes.
2. **Strict Priority Starvation Trade-off**: Strict Priority achieves fewer emergency deadline misses in sustained emergency scenarios ($16.4$ vs $104.0$) because it completely ignores best-effort traffic. BASIL-PSA explicitly trades off some emergency delay to prevent permanent starvation of best-effort nodes.
