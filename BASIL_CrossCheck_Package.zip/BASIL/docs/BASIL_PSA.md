# BASIL-PSA: Priority-Sensitive Adaptive Li-Fi Scheduler

---

## 1. Problem Statement

Visible Light Communication (Li-Fi) operates over a shared indoor broadcast medium characterized by:
- Strict Line-of-Sight (LOS) optical propagation and spatial signal attenuation.
- High modulation bandwidths coupled with strict delay bounds for interactive multimedia, AR/VR, and tactile IoT telemetry.
- Severe performance degradation under bursty traffic patterns when traditional scheduling strategies fail:
  - **FIFO (First-In, First-Out)** suffers from severe Head-of-Line (HoL) blocking where high-priority or urgent packets wait behind non-critical bulk frames.
  - **Round Robin (RR)** ensures device-level fairness but is latency-blind and deadline-agnostic, causing urgent packets in bursty queues to expire.
  - **Strict Priority (SP)** guarantees immediate delivery for high-priority streams but induces complete starvation for lower-priority or best-effort devices under persistent load.

**BASIL-PSA (Priority-Sensitive Adaptive)** addresses these challenges by combining dynamic burst detection, deadline-urgency classification, and dual-tier queuing (real-time priority queues alongside fair best-effort round-robin service).

---

## 2. Algorithm Architecture & Principles

BASIL-PSA decouples incoming network traffic into two operational tiers:
1. **Real-Time / Deadline-Constrained Flows** ($d \ge 0$): Handled across discrete priority queues ($P_2$ high, $P_1$ medium, $P_0$ low) evaluated via urgency metrics and burst thresholds.
2. **Best-Effort / Non-Deadline Flows** ($d < 0$): Handled across per-device queues served by round-robin scheduling to ensure starvation-free multi-user fairness.

### Burst-Detection Trigger
When queue occupancy exceeds the burst threshold $\theta_{\text{burst}}$ (default: 20 packets):
- High-occupancy bursts trigger priority drainage mode.
- Packets nearing critical deadlines are prioritized according to inverse slack time $U(p, t) = \frac{1}{\text{deadline} - t}$.

---

## 3. Algorithm Pseudocode

```text
Algorithm: BASIL-PSA Packet Scheduling

Constants:
  BURST_THRESHOLD = 20
  PRIORITY_LEVELS = [2 (High), 1 (Medium), 0 (Low)]

State:
  priority_queues[3]: Deque of Packet
  device_queues[num_devices]: Deque of Packet
  rr_index: Integer (initially 0)

Function Enqueue(packet p):
  if p.deadline >= 0 then
    pr = clamp(p.priority, 0, 2)
    priority_queues[pr].push_back(p)
  else
    dev = clamp(p.device_id, 0, num_devices - 1)
    device_queues[dev].push_back(p)
  end if

Function Dequeue() -> Optional[Packet]:
  // 1. Detect Burst Condition across priority queues
  burst_detected = False
  for pr in [0..2]:
    if priority_queues[pr].size() > BURST_THRESHOLD then
      burst_detected = True
      break
    end if
  end for

  // 2. Urgent / Deadline-driven service
  if burst_detected or not AllDeadlineQueuesEmpty() then
    for pr from 2 down to 0:
      if not priority_queues[pr].empty() then
        packet = priority_queues[pr].pop_front()
        return packet
      end if
    end for
  end if

  // 3. Fair Best-Effort Round-Robin across device queues
  for step from 0 to num_devices - 1:
    idx = (rr_index + step) % num_devices
    if not device_queues[idx].empty() then
      packet = device_queues[idx].pop_front()
      rr_index = (idx + 1) % num_devices
      return packet
    end if
  end for

  return None
```

---

## 4. Comparative Evaluation

| Feature / Metric | FIFO | Round Robin (RR) | Strict Priority (SP) | BASIL-PSA |
| :--- | :--- | :--- | :--- | :--- |
| **Complexity** | $O(1)$ | $O(1)$ | $O(K)$ | $O(K + N)$ |
| **Deadline Awareness** | None | None | Indirect | **Direct / Urgency-aware** |
| **Burst Resilience** | Poor (HoL delays) | Moderate | Uneven (high only) | **High (Adaptive drainage)** |
| **Starvation Prevention** | None (FIFO queue) | Guaranteed | None for low tier | **Guaranteed via Dual Tier** |
| **Multi-User Fairness** | Low | High | Low | **High (Device RR fallback)** |
| **Target Application** | Simple buffers | Homogeneous bulk | Static strict QoS | **Mixed Li-Fi multimedia** |

---

## 5. Future Roadmap: BASIL-OPT

The next evolution of the BASIL engine incorporates **BASIL-OPT**, an offline and online mathematical optimization module:
- **Convex Delay Minimization**: Joint user association and power allocation based on channel state SNR feedback.
- **Deep Reinforcement Learning (DRL)**: State-action policy networks trained on channel fading and dynamic human blockage patterns.
- **Semantic Priority Weighting**: Incorporating semantic packet importance metrics to adjust transmission urgency dynamically.
