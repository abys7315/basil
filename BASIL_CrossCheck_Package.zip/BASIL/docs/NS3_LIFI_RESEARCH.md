# Li-Fi Research Simulation Architecture & NS-3 Validation Report

## 1. Executive Summary

This document details the research architecture, physical assumptions, implementation specifics, and verification results for the **BASIL (Burst-Aware Semantic Intelligence for Li-Fi)** network simulation platform.

The system features two clearly distinguished simulation engines:
1. **ns-3.42 Li-Fi Simulator (`engine="ns3"`)**: Official ns-3 release (v3.42) executing inside WSL2 Ubuntu 24.04 via Linux ELF binary, utilizing the ns-3 discrete-event core (`ns3::Simulator`, `ns3::NodeContainer`, `ns3::Packet`, `ns3::Time`).
2. **Custom Standalone C++ Prototype (`engine="custom"`)**: A lightweight discrete-event C++17 prototype compiled with MinGW on Windows, preserved for quick local experimentation and baseline comparison.

Neither engine uses Wi-Fi abstractions: both explicitly model the optical wireless channel using Lambertian radiation, line-of-sight path loss, and photodiode noise models.

---

## 2. NS-3 Environment & Setup

- **NS-3 Version**: `ns-3.42` (Official release).
- **Environment**: WSL2 Ubuntu 24.04 LTS (x86_64).
- **Toolchain**: GCC / G++ 13.3.0, CMake 3.28.3, Ninja 1.11.1, Python 3.12.3.
- **NS-3 Location**: `/opt/ns3/ns-allinone-3.42/ns-3.42/`.
- **Enabled Modules**: `core`, `network`, `internet`, `applications`, `point-to-point`, `traffic-control`, `bridge`, `stats`.
- **Executable Location**: `/opt/ns3/ns-allinone-3.42/ns-3.42/build/scratch/ns3.42-basil-ns3-sim`.
- **Source Code**: [`ns3-lifi/scratch/basil-ns3-sim.cc`](file:///c:/Users/abys7/Downloads/BASIL-starter/BASIL/ns3-lifi/scratch/basil-ns3-sim.cc).

---

## 3. Investigation of Existing Open-Source Li-Fi Modules

Prior to implementing the BASIL ns-3 simulation module, existing community works were surveyed:
- **Aldalbahias/VLC (LiFi R&D Centre, Univ. of Edinburgh)**: Pioneer ns-3 VLC module focusing on IEEE 802.15.7 visible light communications, optical path loss, and Lambertian radiation patterns.
- **shakir01/LiFi-WiFi-Hybrid-System**: Extended VLC model combining Wi-Fi and Li-Fi with TDMA coordination.
- **abhaysheel/VLC-NS3-module**: Independent port focusing on optical channel attenuation.

### Physical Assumptions & Formulation

For the BASIL research scenario, the optical wireless channel models:
1. **Lambertian Emission Order**:
   $$m = \frac{-\ln(2)}{\ln(\cos \Phi_{1/2})}$$
   where $\Phi_{1/2}$ is the LED transmitter semi-angle at half power (typically $60^\circ \implies m = 1.0$).

2. **Line-of-Sight (LOS) Optical Path Gain**:
   $$H(0) = \begin{cases} \frac{(m + 1) A_r}{2\pi d^2} \cos^m(\phi) T_s(\psi) g(\psi) \cos(\psi), & 0 \le \psi \le \Psi_{\text{FoV}} \\ 0, & \psi > \Psi_{\text{FoV}} \end{cases}$$
   where:
   - $A_r$: Photodetector active area (default $1.0\text{ cm}^2 = 10^{-4}\text{ m}^2$)
   - $d$: 3D Euclidean distance between LED access point and user photodetector
   - $\phi$: Irradiance angle
   - $\psi$: Incidence angle
   - $T_s(\psi)$: Optical filter transmission coefficient ($1.0$)
   - $g(\psi)$: Optical concentrator gain ($1.0$)
   - $\Psi_{\text{FoV}}$: Receiver field of view semi-angle (default $70^\circ$)

3. **Noise and Electrical SNR (On-Off Keying)**:
   - **Ambient Shot Noise Variance**:
     $$\sigma_{\text{shot}}^2 = 2 q R P_r B$$
     where $q = 1.602 \times 10^{-19}\text{ C}$, responsivity $R = 0.53\text{ A/W}$, $P_r = P_t H(0)$, and bandwidth $B = 20\text{ MHz}$.
   - **Thermal Noise Variance**:
     $$\sigma_{\text{thermal}}^2 = \frac{4 k_B T B}{R_L}$$
     where $k_B = 1.381 \times 10^{-23}\text{ J/K}$, $T = 298\text{ K}$, and load resistance $R_L = 50\ \Omega$.
   - **Electrical SNR**:
     $$\text{SNR} = \frac{(R P_r)^2}{\sigma_{\text{shot}}^2 + \sigma_{\text{thermal}}^2}$$

4. **BER and Packet Error Rate (PER)**:
   $$\text{BER} = \frac{1}{2} \text{erfc}\left(\sqrt{\frac{\text{SNR}}{2}}\right)$$
   $$\text{PER} = 1 - (1 - \text{BER})^{8 \times \text{packet\_size}}$$

---

## 4. Implemented Schedulers in ns-3

The module implements 4 distinct scheduling algorithms operating at the optical MAC/transmission queue:
1. **FIFO**: Baseline single-queue first-in, first-out discipline.
2. **Round Robin (RR)**: Fair cyclical dispatch across per-device queues.
3. **Strict Priority (SP)**: 3-tier priority queues ($0 = \text{low}, 1 = \text{medium}, 2 = \text{high}$). High-priority traffic preemptively clears before lower priority tiers.
4. **BASIL-PSA (Burst-Aware Semantic Intelligence for Li-Fi)**:
   - Evaluates packet slack time $t_{\text{slack}} = t_{\text{deadline}} - t_{\text{now}}$.
   - Detects burst conditions when priority queue depth exceeds threshold $\theta_{\text{burst}} = 15$ packets.
   - Dynamically prioritizes minimum-slack packets during high load / burst periods while providing fair-share round-robin fallback for best-effort data streams.

---

## 5. Automated Verification & Testing

Tests in [`backend/tests/test_ns3_sim.py`](file:///c:/Users/abys7/Downloads/BASIL-starter/BASIL/backend/tests/test_ns3_sim.py) prove authentic execution of both engines:

1. **`test_ns3_simulation_execution`**:
   - Executes `/opt/ns3/ns-allinone-3.42/ns-3.42/build/scratch/ns3.42-basil-ns3-sim` inside WSL Ubuntu.
   - Validates JSON output signature: `"engine": "ns3"`, `"ns3_version": "3.42"`.
   - Validates physical optical attenuation: Device distances increase ($1.0\text{m} \to 1.4\text{m} \to 1.8\text{m}$), directly driving calculated SNR down ($26.4\text{dB} \to 20.4\text{dB} \to 15.8\text{dB}$).
   - Validates scheduler metrics: PDR, throughput, latency, Jain's fairness index, time series.

2. **`test_custom_simulation_execution`**:
   - Confirms that selecting `"custom"` executes the preserved standalone MinGW prototype `basil-sim.exe`.

### Test Results
```text
tests/test_api.py::test_health PASSED
tests/test_api.py::test_create_network_config PASSED
tests/test_api.py::test_create_traffic_config PASSED
tests/test_api.py::test_create_experiment PASSED
tests/test_api.py::test_list_algorithms PASSED
tests/test_ns3_sim.py::test_ns3_simulation_execution PASSED
tests/test_ns3_sim.py::test_custom_simulation_execution PASSED
======================== 7 passed, 1 warning in 3.22s =========================
```

---

## 6. User Interface Integration

1. **Algorithm Lab**: A dual-engine selector card allows researchers to pick:
   - **ns-3.42 Li-Fi Engine** *(Official ns-3 running in WSL)*
   - **Custom C++ Simulator** *(MinGW Standalone)*
2. **Results & Analytics**: Each experiment display card and comparison view explicitly labels the engine used (`ns-3.42 Li-Fi` vs `Custom C++`) alongside full Plotly graphs, per-device tables, and CSV exports.
