@echo off
echo ========================================================
echo   BASIL: Burst-Aware Semantic Intelligence for Li-Fi
echo   Launching Native Desktop Application (Tauri 2)...
echo ========================================================
echo.

set ROOT_DIR=%~dp0
set BASIL_BACKEND_DIR=%ROOT_DIR%backend

echo [1/3] Clearing any stale WebView2 locks...
powershell -NoProfile -Command "Get-CimInstance Win32_Process -Filter \"Name = 'msedgewebview2.exe'\" | Where-Object { $_.CommandLine -like '*org.basil.lifi.simulator*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }" >nul 2>&1

echo [2/3] Initializing Local FastAPI Backend...
start "BASIL Backend Service" /MIN cmd /c "cd /d ""%ROOT_DIR%backend"" && python -m uvicorn app.main:app --host 127.0.0.1 --port 8000"

echo [3/3] Launching BASIL Native Desktop GUI...
if exist "%ROOT_DIR%desktop-app\src-tauri\target\release\basil.exe" (
    start "" "%ROOT_DIR%desktop-app\src-tauri\target\release\basil.exe"
) else if exist "%ROOT_DIR%desktop-app\src-tauri\target\release\app.exe" (
    start "" "%ROOT_DIR%desktop-app\src-tauri\target\release\app.exe"
) else (
    echo Error: Compiled desktop binary not found.
    echo Please run 'npm --prefix desktop-app run tauri:build' first.
    pause
    exit /b 1
)

echo.
echo BASIL Desktop Application running!
