# BASIL Demo Runbook (v4.1.0)

A rapid, step-by-step evaluation guide for demonstrating the **BASIL (Burst-Aware Semantic Intelligence for Li-Fi)** desktop simulation platform, online **BASIL-PSA** scheduling, and offline **BASIL-OPT** optimization.

**Estimated Demo Time:** 5 to 8 minutes.

---

## 1. Quick-Start (Under 60 Seconds)

1. Launch BASIL using the Start Menu shortcut or by double-clicking:
   ```
   BASIL\start-desktop.bat
   ```
2. Verify that the **System Status Badge** in the top navigation bar displays a green **"Backend Online"** indicator (`http://127.0.0.1:8000`).

---

## 2. Scenario 1: Optical Cell & Traffic Setup

1. **Navigate to "Network Configuration"** in the sidebar:
   * **Room Dimensions:** 4.0 m (width) × 3.0 m (height).
   * **Access Point (AP):** Ceiling-mounted at (2.0 m, 1.5 m, 3.0 m).
   * **AP Optical Power:** Set to `100.0 W` (or `100,000 mW`).
   * **Semi-Angle at Half Power:** `60.0°`.
   * **Channel Data Rate:** `20.0 Mbps`.
   * **Number of User Devices:** `3` or `4` devices spaced across the room to observe the physical optical SNR and PER gradient.
   * Click **Save Network Configuration**.

2. **Navigate to "Traffic Configuration"**:
   * **Mode:** Select `Mixed Semantic Traffic`.
   * **Normal Packet Rate:** `50 packets/s`.
   * **Burst Packet Rate:** `200 packets/s`.
   * **Burst Ratio:** `0.30` (30% sudden burst phases).
   * **Packet Size:** `1024 bytes`.
   * **Deadline Horizon:** `50 ms`.
   * Click **Save Traffic Configuration**.

---

## 3. Scenario 2: Running Online Schedulers (FIFO vs. BASIL-PSA)

1. **Navigate to "Simulate"** in the sidebar.
2. Select your newly created Network and Traffic configurations.
3. **Run FIFO (Baseline):**
   * Select Algorithm: **FIFO**.
   * Simulation Duration: `2.0 s`.
   * Engine: **ns-3 (Hybrid WSL)**.
   * Click **Launch Simulation**.
   * The simulator executes ns-3.42 inside WSL Ubuntu. Note the progress bar and completion notification.
4. **Run BASIL-PSA (Semantic Burst-Aware):**
   * Switch Algorithm to **BASIL-PSA**.
   * Keep identical simulation duration and engine.
   * Click **Launch Simulation**.
   * Observe how BASIL-PSA adapts to sudden traffic bursts, prioritizing deadline-critical video/telemetry frames while adapting to optical attenuation.

---

## 4. Scenario 3: Offline Optimization Reference (BASIL-OPT)

1. Stay on the **Simulate** or **Algorithm Lab** page.
2. Select Algorithm: **BASIL-OPT**.
3. Click **Launch Simulation**.
4. **Behind the scenes:**
   * ns-3 extracts the exact packet arrival trace and physical optical channel PER for all devices.
   * The offline MILP optimization model executes using the **HiGHS 1.16.0** solver.
   * Proven global optimality is established with zero heuristic bias.
5. Review the optimization solve summary:
   * **Status:** `Optimal`
   * **MIP Relative Gap:** `< 0.001` (proven global optimum)
   * **Solver Time:** ~10–25 seconds.

---

## 5. Scenario 4: Results & Research Metric Analytics

1. **Navigate to "Results & Analytics"** in the sidebar.
2. Select the **BASIL-PSA** run from the experiment list.
3. Review the **Phase 3.5 Research Metric Cards**:
   * **Row 1 (Throughput & Delivery Parity):**
     * **Semantic Goodput:** Displays effective throughput weighted by semantic importance.
     * **Throughput (Raw):** Total delivered payload rate.
     * **Scheduling Coverage (%):** Total scheduled packets divided by offered packets.
     * **Realized Recv PDR (%):** Actually delivered packets divided by offered packets.
     * **Expected Recv PDR (%):** Analytical expectation based on physical channel PER.
   * **Row 2 (Strict Three-Way Accounting):**
     * **Scheduling Deadline Misses (A):** Packets scheduled past deadline.
     * **End-to-End Deadline Failures (B):** Total undelivered or late deadline packets.
     * **Optical Channel Losses (C):** Packets transmitted on time but corrupted by optical PER.
4. **Examine the Charts:**
   * **Throughput Over Time:** Interactive Plotly scatter plot showing burst dynamics.
   * **Per-Device Latency:** Bar chart illustrating fair queue delay across cell devices.
   * **Per-Device Statistics Table:** Physical distance, received SNR (dB), PER, and packet delivery counts.

---

## 6. Scenario 5: Multi-Algorithm Comparison & Data Export

1. Click **Compare Experiments** at the top right of the Results page.
2. Check the boxes for **FIFO**, **BASIL-PSA**, and **BASIL-OPT**.
3. Click **Compare Selected**.
4. Observe the comparative side-by-side performance table:
   * Observe BASIL-PSA's **Relative Semantic Goodput vs. BASIL-OPT (%)** approaching 90%–96% of the theoretical offline oracle.
5. **Export Research Datasets:**
   * Click **Export CSV** to download `experiment_<id>.csv`.
   * Click **Export JSON** to download `experiment_<id>.json`.
   * Inspect the CSV: all standardized Phase 3.5 metric column headers and per-device statistics are cleanly partitioned for paper reproduction.

---

## 7. Demo Reset

To clear demonstration artifacts or re-run tests from scratch:
* Close the desktop window (backend terminates automatically).
* Run `python backend/check_dependencies.py` to re-verify readiness at any time.
