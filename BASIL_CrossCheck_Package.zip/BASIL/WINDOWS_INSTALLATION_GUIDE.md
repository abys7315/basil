# BASIL Windows Installation Guide (v4.1.0 — Phase 4.2 Release)

This guide provides end-to-end instructions for installing, configuring, validating, and running the **BASIL (Burst-Aware Semantic Intelligence for Li-Fi)** desktop simulation platform on Windows 10/11 (64-bit).

---

## 1. System Requirements & Dependency Architecture

BASIL categorizes system requirements into three distinct tiers so users and evaluators know exactly what is required to launch the application versus running physical simulations or developing from source.

### Tier 1: Core Application Runtime (Required for App & Solver)
* **Operating System:** Windows 10 (version 1903+) or Windows 11 (64-bit x86_64)
* **Microsoft Edge WebView2 Runtime:** Typically pre-installed on Windows 10/11. If missing, download the [Evergreen Bootstrapper](https://developer.microsoft.com/en-us/microsoft-edge/webview2/).
* **Python 3.10+ (64-bit):** Required for the local simulation API and HiGHS MILP optimization solver. Available from [python.org](https://www.python.org/) or Microsoft Store. Ensure **"Add Python to PATH"** is checked during installation.
* **Core Python Backend Packages:** `fastapi`, `uvicorn`, `sqlalchemy`, `aiosqlite`, `pydantic`, `pandas`, `numpy`, `scipy`, `highspy`.
* **Storage & Application Data:** Writable directory at `%LOCALAPPDATA%\BASIL\data` for SQLite database and simulation artifacts.

### Tier 2: Simulation Subsystem (Required for ns-3.42 Simulations)
* **WSL2 Subsystem:** Windows Subsystem for Linux 2 enabled.
* **Ubuntu Distribution:** `Ubuntu 22.04 LTS` or `Ubuntu 24.04 LTS`.
* **ns-3.42 Li-Fi Simulator:** Compiled ns-3.42 Li-Fi simulator binary (located in `/opt/ns-allinone-3.42/ns-3.42/build/scratch/ns3-lifi-sim` inside Ubuntu).
* *(Fallback Mode: If WSL2 or ns-3 is not installed, BASIL falls back to its bundled standalone C++ DES simulator `resources/ns3-lifi/scratch/basil-sim.exe`).*

### Tier 3: Development & Testing Tools (Strictly Optional)
* **Pytest:** Only needed if running the backend automated test suite (`pytest backend/tests`). **NOT required to launch or use BASIL.**
* **Rust & Cargo (1.75+):** Only needed if recompiling the desktop Tauri shell from source. **NOT required at runtime.**

---

## 2. Installing BASIL via the NSIS Installer

The official Windows installer packages the frontend, native desktop shell, bundled backend service, seed database template, and standalone C++ simulation engine into a single executable.

* **Installer File:** `desktop-app/src-tauri/target/release/bundle/nsis/BASIL_4.1.0_x64-setup.exe`
* **File Size:** `3.23 MiB` (3,389,269 bytes)
* **SHA-256 Checksum:** `6F9781C663813C9CB81A94C95D7A1C1E9EEF1A6DDFC3EF05BCCCB05A42C3A542`
* **Default Install Location:** `%LOCALAPPDATA%\Programs\BASIL` (CurrentUser mode, no administrative UAC elevation required)
* **Packaged Bundled Resources:**
  * `resources/backend/app/` (FastAPI backend server code)
  * `resources/backend/requirements.txt` (Python package dependencies)
  * `resources/backend/check_dependencies.py` (Dependency validator)
  * `resources/backend/basil.db` (Seed SQLite database)
  * `resources/ns3-lifi/scratch/basil-sim.exe` (Standalone C++ DES simulator)

### Interactive GUI Installation
1. Double-click `BASIL_4.1.0_x64-setup.exe` to launch the installation wizard.
2. Review the destination folder (defaults to `%LOCALAPPDATA%\Programs\BASIL`).
3. Click **Install**. The wizard extracts all binaries, bundled backend resources, and registers the Start Menu shortcut under `BASIL`.
4. Click **Finish** to complete installation.

### Silent / Automated Installation
For automated deployment or lab installations, run in PowerShell or Command Prompt:
```powershell
.\BASIL_4.1.0_x64-setup.exe /S
```
To specify a custom installation directory silently:
```powershell
.\BASIL_4.1.0_x64-setup.exe /S /D=C:\CustomPath\BASIL
```
*(Note: standard NSIS syntax requires `/D=` to be the final parameter without enclosing quotation marks).*

---

## 3. Verifying System Dependencies

BASIL includes an automated startup dependency validator that checks all 17 host, simulation, and storage prerequisites across the 3 tiers:

```powershell
# From source or installed resources directory:
python check_dependencies.py
```

### Diagnostic Output Example
```
======================================================================
BASIL Runtime Dependency & Environment Validation (v4.1.0)
======================================================================

[Core Runtimes (Host OS)]
  [✓] WebView2 Runtime: INSTALLED (157.0.4341.46)
  [✓] Python Runtime: INSTALLED (3.10.11)

[Core Python Backend Packages]
  [✓] Python Package: fastapi: INSTALLED (0.109.2)
  [✓] Python Package: uvicorn: INSTALLED (0.27.1)
  [✓] Python Package: sqlalchemy: INSTALLED (2.0.25)
  [✓] Python Package: aiosqlite: INSTALLED (0.22.1)
  [✓] Python Package: pydantic: INSTALLED (2.13.5)
  [✓] Python Package: pandas: INSTALLED (2.2.0)
  [✓] Python Package: numpy: INSTALLED (1.26.4)
  [✓] Python Package: scipy: INSTALLED (1.15.3)
  [✓] Python Package: highspy: INSTALLED (1.16.0)

[Filesystem & Storage]
  [✓] Filesystem Writability: INSTALLED (R/W OK at %LOCALAPPDATA%\BASIL\data)

[WSL2 & ns-3.42 Li-Fi Simulator]
  [✓] WSL2 Subsystem: INSTALLED (WSL2)
  [✓] Ubuntu WSL Distribution: INSTALLED (Ubuntu 24.04.3 LTS)
  [✓] ns-3.42 Li-Fi Simulator: INSTALLED (ns-3.42 (Hybrid Li-Fi PHY/MAC))

[Development & Testing Tools (Optional)]
  [✓] Python Package: pytest: INSTALLED (9.1.1) (Optional / Not Required for End Users)
  [✓] Rust Toolchain (Runtime): NOT_REQUIRED (Build-Time Only)

======================================================================
Summary: 17/17 checks passed. Missing: 0, Incompatible: 0.
Status: ALL DEPENDENCIES OPERATIONAL. BASIL is ready to launch.
======================================================================
```

If any core Python package is reported as missing:
```powershell
pip install -r requirements.txt
```

---

## 4. Application Data Directory & Persistence

BASIL stores user data strictly in Windows-standard application directories:

* **Database File:** `%LOCALAPPDATA%\BASIL\data\basil.db`
* **Log Files:** `%LOCALAPPDATA%\BASIL\logs\backend.log`
* **Exports & Traces:** `%LOCALAPPDATA%\BASIL\data\exports\`

### Upgrade & Re-installation Safety
* Installing newer versions of BASIL or reinstalling into `%LOCALAPPDATA%\Programs\BASIL` replaces application binaries and UI bundles, but does **NOT** overwrite or delete your existing `%LOCALAPPDATA%\BASIL\data\basil.db`.
* Your experiment history, custom network topologies, and traffic patterns are preserved across updates.

### Complete Uninstallation Behavior
* The uninstaller (`uninstall.exe`) safely removes all executable binaries, bundled assets, and Start Menu shortcuts.
* To protect research data, user simulation records in `%LOCALAPPDATA%\BASIL\data` are intentionally retained. To perform a 100% clean purge, delete `%LOCALAPPDATA%\BASIL` after uninstalling.

---

## 5. Launching the Application

### Method 1: Start Menu Shortcut
* Open the Windows Start Menu and select **BASIL**.
* The desktop application will launch, automatically start the background simulation API on port 8000, and present the main dashboard.

### Method 2: Launching from Custom Installed Path
* Navigate to your installation folder (e.g., `C:\BASIL_CleanInstall` or `%LOCALAPPDATA%\Programs\BASIL`).
* Double-click `basil.exe`.
* The application automatically finds its bundled backend in `resources/backend`, initializes the `%LOCALAPPDATA%` database, and opens the interface.

---

## 6. Deployment Readiness Guide

* **Development Machine:** (Has Python 3.10+, WSL2, Ubuntu, ns-3.42, Node 18+, Rust/Cargo). Fully operational for running simulations, running 45 backend tests, and rebuilding the Tauri installer.
* **Prepared Machine:** (Standard Windows 10/11 with Python 3.10+ and WSL2 Ubuntu). Fully operational out of the box using `BASIL_4.1.0_x64-setup.exe`. No Node or Rust needed.
* **Clean Machine:** (Fresh Windows 10/11 without Python or WSL2). Requires installing Python 3.10+ (`Add Python to PATH`) and enabling WSL2 (`wsl --install -d Ubuntu`). The dependency checker guides the user on any missing component.

---

## 7. Troubleshooting

* **Port 8000 Conflict:**  
  If another local service is using port 8000, BASIL inspects the HTTP response signature (`GET /health`). If an authentic BASIL API signature is absent, BASIL will not interfere with or terminate the foreign process. Stop the conflicting service or reconfigure the port before launching.
* **WSL2 Not Installed:**  
  Run PowerShell as Administrator and execute:
  ```powershell
  wsl --install -d Ubuntu
  ```
  Restart your computer when prompted.
* **WebView2 Blank Window:**  
  If the application opens with a blank window, install the Microsoft Edge WebView2 Evergreen Runtime from Microsoft's developer portal.
