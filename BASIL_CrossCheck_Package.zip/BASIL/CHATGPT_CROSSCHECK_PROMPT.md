# BASIL Project — ChatGPT Cross-Check Guide & Prompt

Use the prompt below when uploading `BASIL_CrossCheck_Package.zip` to ChatGPT for independent peer review and cross-checking.

---

## Copy-Paste Prompt for ChatGPT

```markdown
Hi ChatGPT,

I am uploading the complete source code, mathematical specifications, research reports, simulation datasets, and desktop implementation of **BASIL** (Burst-Aware Semantic Intelligence for Li-Fi).

Please conduct an independent, rigorous research, algorithmic, and architectural cross-check of this project.

### 1. Project Background
BASIL investigates packet scheduling algorithms over indoor Visible Light Communication (VLC / Li-Fi) networks under heterogeneous, bursty traffic with strict latency deadlines.
The system implements five scheduling algorithms:
1. FIFO (First-In, First-Out)
2. Round Robin (RR)
3. Strict Priority (SP)
4. BASIL-PSA (Priority-Sensitive Adaptive: burst detection + dual-tier priority queue + starvation-free round-robin fallback)
5. BASIL-OPT (Offline slotted MILP upper-bound oracle solved via HiGHS with future arrival awareness)

### 2. Key Files to Inspect
- **Optical Wireless Physics & Channel Model:**
  - `BASIL/docs/LIFI_MODEL.md`
  - `BASIL/ns3-lifi/scratch/lifi_physics.h`
  - `BASIL/ns3-lifi/scratch/basil-ns3-sim.cc`
- **BASIL-PSA Mathematical Model & Implementation:**
  - `BASIL/docs/BASIL_PSA_MATHEMATICAL_MODEL.md`
  - `BASIL/ns3-lifi/scratch/basil-ns3-sim.cc` (lines ~120-350)
- **BASIL-OPT MILP Optimization Formulation & Implementation:**
  - `BASIL/docs/BASIL_OPT_MATHEMATICAL_MODEL.md`
  - `BASIL/docs/BASIL_OPT_IMPLEMENTATION.md`
  - `BASIL/backend/app/algorithms/basil_opt.py`
- **Metric Parity & Accounting Audit Reports:**
  - `BASIL/docs/PHASE3_3_METRIC_PARITY_AUDIT.md`
  - `BASIL/docs/PHASE3_5_PACKET_PARITY_AUDIT.md`
  - `BASIL/experiments/phase3_5_reconciled_benchmark_results.json`
- **Desktop Architecture & Deployment Acceptance:**
  - `BASIL/PHASE4_2_DEPLOYMENT_ACCEPTANCE_REPORT.md`
  - `BASIL/WINDOWS_INSTALLATION_GUIDE.md`
  - `BASIL/desktop-app/src-tauri/src/lib.rs`
  - `BASIL/backend/app/database.py`
  - `BASIL/tests/test_installed_gui_acceptance.py`

### 3. Questions to Cross-Check
1. **Mathematical Consistency:** Does the HiGHS MILP formulation in `basil_opt.py` strictly match the objective function and constraints described in `BASIL_OPT_MATHEMATICAL_MODEL.md`? Are all units (bits, seconds, watts, SNR) dimensionally sound?
2. **Li-Fi Channel Physics:** Does the Lambertian radiant intensity, line-of-sight channel DC gain $H(0)$, shot/thermal noise variance, and On-Off Keying (OOK) PER calculation in `lifi_physics.h` adhere to standard optical wireless literature (e.g., Kahn & Barry, Komine & Nakagawa)?
3. **Metric Parity & Research Integrity:** Did the project cleanly separate "Scheduling Coverage (%)" from "Received PDR (%)", and "Scheduling Deadline Misses" from "End-to-End Deadline Failures"? Does the packet accounting prevent double-counting of dropped vs expired vs channel-lost packets?
4. **Desktop Packaging & Data Architecture:** How does the application achieve repository independence when installed via the NSIS installer? Is the separation of static program assets (`%LOCALAPPDATA%\Programs\BASIL`) and persistent user databases (`%LOCALAPPDATA%\BASIL\data\basil.db`) properly designed according to Windows conventions?
5. **Critique & Limitations:** What are the theoretical and practical limitations of the current hybrid simulation approach? What edge cases could challenge the BASIL-PSA burst detector or the offline MILP formulation?

Please provide a structured, detailed assessment highlighting strengths, mathematical correctness, potential edge cases, and any recommendations.
```
