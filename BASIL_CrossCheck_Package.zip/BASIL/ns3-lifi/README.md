# BASIL Li-Fi Discrete-Event Simulator (`ns3-lifi`)

High-precision, standalone C++17 discrete-event simulation engine for visible light communication (Li-Fi). Models optical channel physics, multi-user contention, bursty traffic patterns, and packet scheduling algorithms without requiring external ns-3 installations.

---

## 1. Architecture

The simulator consists of three modular layers:
1. **Physical Layer (`scratch/lifi_physics.h`)**:
   - Computes Lambertian radiation mode $m$ from transmitter semi-angle.
   - Calculates Line-of-Sight (LOS) channel DC gain $H(0)$.
   - Evaluates shot noise and thermal noise to determine electrical SNR.
   - Computes Bit Error Rate (BER) for On-Off Keying (OOK) and derives Packet Error Rate (PER).
2. **Scheduling Engine (`scratch/scheduler.h`)**:
   - Implements `FIFO`, `RoundRobin`, `StrictPriority`, and `BASIL_PSA`.
3. **Discrete-Event Simulation (DES) Core (`scratch/basil-sim.cc`)**:
   - Priority queue event scheduler managing packet generation, transmission, channel propagation, and reception.
   - Outputs aggregated and per-device statistics in JSON format to stdout.

---

## 2. Building the Simulator

### Windows (MinGW g++)

Ensure MinGW is installed at `C:\MinGW\bin\g++.exe` or accessible via your system `PATH`:

```bat
cd ns3-lifi
build.bat
```

Or invoke g++ manually:

```cmd
cd scratch
g++ -std=c++17 -O2 -o basil-sim.exe basil-sim.cc
```

### Linux / WSL

```bash
cd scratch
g++ -std=c++17 -O2 -o basil-sim basil-sim.cc
```

---

## 3. Testing

The test suite validates physics formulas, noise calculations, and scheduler behaviors using Python:

```bash
cd ns3-lifi
python test/test_sim.py
```

Expected result:
```
6/6 tests passed:
  - test_lambertian_order
  - test_los_gain
  - test_snr_and_ber
  - test_per_formula
  - test_sim_execution
  - test_schedulers
```

---

## 4. Input & Output Format

### Execution
```cmd
basil-sim.exe <config.json>
```

### Sample Input JSON
```json
{
  "network": {
    "name": "Room_5x5",
    "num_devices": 4,
    "half_angle_deg": 60.0,
    "receiver_area_cm2": 1.0,
    "bandwidth_mhz": 100.0,
    "data_rate_mbps": 100.0,
    "tx_power_mw": 50.0
  },
  "traffic": {
    "name": "Bursty_Traffic",
    "scheduler": "BASIL_PSA",
    "normal_rate_pps": 100.0,
    "burst_rate_pps": 500.0,
    "burst_ratio": 0.2,
    "packet_size_bytes": 1024,
    "sim_time_s": 5.0
  }
}
```

### Sample Output JSON (stdout)
```json
{
  "scheduler": "BASIL_PSA",
  "simulation_time_s": 5.0,
  "metrics": {
    "avg_latency_ms": 1.15,
    "throughput_mbps": 1.84,
    "packet_delivery_ratio": 0.52,
    "packet_loss": 0.48,
    "deadline_misses": 0,
    "fairness_index": 0.74
  },
  "per_device": [
    {
      "device_id": 0,
      "distance_m": 1.0,
      "snr_db": 20.3,
      "ber": 0.0,
      "per": 0.0,
      "packets_sent": 600,
      "packets_received": 600,
      "pdr": 1.0,
      "avg_latency_ms": 0.95
    }
  ],
  "time_series": [
    {"time_s": 0.5, "throughput_mbps": 1.80},
    {"time_s": 1.0, "throughput_mbps": 1.85}
  ]
}
```
