"""
BASIL Li-Fi Simulation Tests
Tests basil-sim.exe with a temp config and validates the output JSON.
"""
import json
import os
import subprocess
import sys
import tempfile
import time
import pathlib

# Locate the simulator executable
SCRATCH_DIR = pathlib.Path(__file__).parent.parent / "scratch"
SIM_EXE = SCRATCH_DIR / "basil-sim.exe"


def make_config(
    num_devices=4,
    scheduler="FIFO",
    normal_rate_pps=50.0,
    burst_rate_pps=200.0,
    burst_duration_s=0.2,
    burst_interval_s=1.0,
    simulation_duration_s=2.0,
    deadline_ms=-1.0,
    seed=42,
):
    return {
        "network": {
            "name": "test-net",
            "num_devices": num_devices,
            "half_angle_deg": 60.0,
            "receiver_area_cm2": 1.0,
            "bandwidth_hz": 20e6,
            "data_rate_mbps": 10.0,
            "responsivity": 0.53,
            "tx_power_mw": 50.0,
        },
        "traffic": {
            "name": "test-traffic",
            "scheduler": scheduler,
            "normal_rate_pps": normal_rate_pps,
            "burst_rate_pps": burst_rate_pps,
            "burst_duration_s": burst_duration_s,
            "burst_interval_s": burst_interval_s,
            "packet_size_bytes": 1024,
            "priority": 1,
            "deadline_ms": deadline_ms,
            "simulation_duration_s": simulation_duration_s,
            "seed": seed,
        },
    }


def run_sim(config: dict) -> dict:
    """Write config to temp file, run sim, return parsed JSON output."""
    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".json", delete=False
    ) as f:
        json.dump(config, f)
        cfg_path = f.name
    try:
        cmd = [str(SIM_EXE), cfg_path]
        result = subprocess.run(
            cmd, capture_output=True, text=True, timeout=60
        )
        if result.returncode != 0:
            raise RuntimeError(
                f"Sim exited {result.returncode}:\nSTDOUT: {result.stdout[:500]}\nSTDERR: {result.stderr[:500]}"
            )
        return json.loads(result.stdout)
    finally:
        os.unlink(cfg_path)


REQUIRED_KEYS = [
    "scheduler",
    "simulation_duration_s",
    "num_devices",
    "total_packets_sent",
    "total_packets_delivered",
    "total_packets_dropped",
    "pdr",
    "avg_latency_ms",
    "throughput_mbps",
    "deadline_miss_rate",
    "jain_fairness_index",
    "total_deadline_misses",
    "per_device",
    "time_series",
]

DEVICE_KEYS = [
    "device_id",
    "distance_m",
    "snr_db",
    "ber",
    "per",
    "received_power_mw",
    "pkts_sent",
    "pkts_delivered",
    "pkts_dropped",
    "pdr",
    "avg_latency_ms",
    "throughput_mbps",
]


def validate_output(out: dict, scheduler: str, num_devices: int):
    """Check required fields and physical plausibility."""
    errors = []

    # Required top-level keys
    for k in REQUIRED_KEYS:
        if k not in out:
            errors.append(f"Missing key: {k}")

    if errors:
        raise AssertionError("Missing required fields: " + ", ".join(errors))

    # Scheduler name
    assert out["scheduler"] == scheduler, f"Scheduler mismatch: {out['scheduler']} != {scheduler}"

    # Physical plausibility
    assert 0.0 <= out["pdr"] <= 1.0, f"PDR out of range: {out['pdr']}"
    assert out["avg_latency_ms"] >= 0.0, f"Negative latency: {out['avg_latency_ms']}"
    assert out["throughput_mbps"] >= 0.0, f"Negative throughput: {out['throughput_mbps']}"
    assert 0.0 <= out["jain_fairness_index"] <= 1.0, f"Fairness out of range: {out['jain_fairness_index']}"
    assert 0.0 <= out["deadline_miss_rate"] <= 1.0, f"Deadline miss rate out of range"
    assert out["total_packets_sent"] >= out["total_packets_delivered"], "Delivered > sent"
    assert (
        out["total_packets_sent"]
        == out["total_packets_delivered"] + out["total_packets_dropped"]
    ), "Packet count mismatch"

    # Per-device
    assert len(out["per_device"]) == num_devices, f"Expected {num_devices} devices, got {len(out['per_device'])}"
    for d in out["per_device"]:
        for k in DEVICE_KEYS:
            assert k in d, f"Device missing key: {k}"
        assert d["snr_db"] > 0, f"Non-positive SNR for device {d['device_id']}"
        assert 0.0 <= d["ber"] <= 0.5, f"BER out of range: {d['ber']}"
        assert 0.0 <= d["per"] <= 1.0, f"PER out of range: {d['per']}"
        assert d["received_power_mw"] > 0, f"Zero received power for device {d['device_id']}"
        assert 0.0 <= d["pdr"] <= 1.0, f"Device PDR out of range: {d['pdr']}"

    # Time-series
    assert len(out["time_series"]) > 0, "Empty time series"
    for ts in out["time_series"]:
        assert "time_s" in ts and "throughput_mbps" in ts and "latency_ms" in ts


def test_fifo():
    print("TEST: FIFO scheduler...")
    cfg = make_config(scheduler="FIFO", num_devices=4, simulation_duration_s=2.0)
    out = run_sim(cfg)
    validate_output(out, "FIFO", 4)
    print(f"  PDR={out['pdr']:.4f} latency={out['avg_latency_ms']:.3f}ms "
          f"tput={out['throughput_mbps']:.4f}Mbps fairness={out['jain_fairness_index']:.4f}")
    print("  PASS")
    return out


def test_round_robin():
    print("TEST: RoundRobin scheduler...")
    cfg = make_config(scheduler="RoundRobin", num_devices=4, simulation_duration_s=2.0)
    out = run_sim(cfg)
    validate_output(out, "RoundRobin", 4)
    print(f"  PDR={out['pdr']:.4f} latency={out['avg_latency_ms']:.3f}ms "
          f"tput={out['throughput_mbps']:.4f}Mbps fairness={out['jain_fairness_index']:.4f}")
    print("  PASS")
    return out


def test_strict_priority():
    print("TEST: StrictPriority scheduler...")
    cfg = make_config(scheduler="StrictPriority", num_devices=4, simulation_duration_s=2.0)
    out = run_sim(cfg)
    validate_output(out, "StrictPriority", 4)
    print(f"  PDR={out['pdr']:.4f} latency={out['avg_latency_ms']:.3f}ms "
          f"tput={out['throughput_mbps']:.4f}Mbps fairness={out['jain_fairness_index']:.4f}")
    print("  PASS")
    return out


def test_basil_psa():
    print("TEST: BASIL_PSA scheduler...")
    cfg = make_config(
        scheduler="BASIL_PSA",
        num_devices=4,
        simulation_duration_s=2.0,
        deadline_ms=50.0,
    )
    out = run_sim(cfg)
    validate_output(out, "BASIL_PSA", 4)
    print(f"  PDR={out['pdr']:.4f} latency={out['avg_latency_ms']:.3f}ms "
          f"tput={out['throughput_mbps']:.4f}Mbps fairness={out['jain_fairness_index']:.4f}")
    print("  PASS")
    return out


def test_burst_traffic():
    print("TEST: Burst traffic (FIFO)...")
    cfg = make_config(
        scheduler="FIFO",
        num_devices=2,
        normal_rate_pps=20.0,
        burst_rate_pps=300.0,
        burst_duration_s=0.3,
        burst_interval_s=1.0,
        simulation_duration_s=3.0,
    )
    out = run_sim(cfg)
    validate_output(out, "FIFO", 2)
    assert out["total_packets_sent"] > 0, "No packets in burst scenario"
    print(f"  sent={out['total_packets_sent']} PDR={out['pdr']:.4f}")
    print("  PASS")
    return out


def test_physics():
    print("TEST: Physics plausibility (SNR decreases with distance)...")
    cfg = make_config(num_devices=4, simulation_duration_s=1.0)
    out = run_sim(cfg)
    devices = sorted(out["per_device"], key=lambda d: d["distance_m"])
    snrs = [d["snr_db"] for d in devices]
    # SNR should generally decrease with distance
    # Allow one inversion due to rounding but overall trend must be decreasing
    violations = sum(1 for i in range(len(snrs)-1) if snrs[i] < snrs[i+1])
    assert violations < len(snrs) - 1, f"SNR not decreasing with distance: {snrs}"
    print(f"  SNR values by distance: {[f'{s:.1f}dB' for s in snrs]}")
    print("  PASS")


def main():
    if not SIM_EXE.exists():
        print(f"ERROR: Simulator not found at {SIM_EXE}", file=sys.stderr)
        print("Run build.bat first.", file=sys.stderr)
        sys.exit(1)

    print(f"Using simulator: {SIM_EXE}\n")
    t0 = time.time()
    
    results = []
    failures = []

    tests = [
        ("FIFO", test_fifo),
        ("RoundRobin", test_round_robin),
        ("StrictPriority", test_strict_priority),
        ("BASIL_PSA", test_basil_psa),
        ("BurstTraffic", test_burst_traffic),
        ("Physics", test_physics),
    ]

    for name, fn in tests:
        try:
            r = fn()
            results.append((name, "PASS", r))
        except Exception as e:
            print(f"  FAIL: {e}")
            failures.append((name, str(e)))
        print()

    elapsed = time.time() - t0
    print(f"{'='*50}")
    print(f"Results: {len(results)}/{len(tests)} passed in {elapsed:.2f}s")
    if failures:
        print("Failures:")
        for name, msg in failures:
            print(f"  - {name}: {msg}")
        sys.exit(1)
    else:
        print("All tests PASSED!")
        # Print sample output
        if results:
            first = results[0][2]
            if first:
                print("\nSample output (FIFO):")
                print(json.dumps({k: v for k, v in first.items() if k != "time_series" and k != "per_device"}, indent=2))


if __name__ == "__main__":
    main()
