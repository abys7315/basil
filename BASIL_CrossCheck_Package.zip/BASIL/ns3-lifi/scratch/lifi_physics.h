#pragma once
#include <cmath>
#include <cstdint>

namespace lifi {
  constexpr double PI = 3.14159265358979323846;
  
  // Lambertian order from half-angle (degrees)
  inline double lambertian_order(double half_angle_deg) {
    double phi = half_angle_deg * PI / 180.0;
    return -std::log(2.0) / std::log(std::cos(phi));
  }

  // LOS path gain H(0)
  // m: Lambertian order, A_r: receiver area (cm^2), d: distance (m)
  // phi: emission angle (rad), psi: incidence angle (rad)
  // Ts: optical filter gain (1.0), g: concentrator gain (1.0)
  inline double los_path_gain(double m, double A_r_cm2, double d_m,
                               double phi_rad, double psi_rad,
                               double Ts = 1.0, double g = 1.0) {
    double A_r = A_r_cm2 * 1e-4; // convert cm^2 to m^2
    return ((m + 1.0) * A_r) / (2.0 * PI * d_m * d_m)
           * std::pow(std::cos(phi_rad), m)
           * Ts * g * std::cos(psi_rad);
  }

  // Received optical power (mW)
  inline double received_power(double P_t_mW, double H) {
    return P_t_mW * H;
  }

  // Shot noise variance (A^2)
  // P_r: received power (mW->W), B: bandwidth Hz, q: electron charge
  inline double shot_noise_variance(double P_r_mW, double B_hz,
                                     double responsivity = 0.53) {
    const double q = 1.602e-19;
    double P_r = P_r_mW * 1e-3;
    return 2.0 * q * responsivity * P_r * B_hz;
  }

  // Thermal noise variance (A^2)
  inline double thermal_noise_variance(double B_hz, double T_K = 298.0) {
    const double k_B = 1.381e-23;
    const double R_L = 50.0; // load resistance Ohm
    return 4.0 * k_B * T_K * B_hz / R_L;
  }

  // Electrical SNR for OOK
  inline double snr(double P_r_mW, double B_hz, double responsivity = 0.53) {
    double I_signal = responsivity * P_r_mW * 1e-3;
    double sigma2 = shot_noise_variance(P_r_mW, B_hz, responsivity)
                  + thermal_noise_variance(B_hz);
    return (I_signal * I_signal) / sigma2;
  }

  // BER for OOK: 0.5 * erfc(sqrt(SNR/2))
  inline double ber(double snr_val) {
    return 0.5 * std::erfc(std::sqrt(snr_val / 2.0));
  }

  // Packet error rate from BER and packet size (bits)
  inline double per(double ber_val, int pkt_size_bytes) {
    int bits = pkt_size_bytes * 8;
    return 1.0 - std::pow(1.0 - ber_val, bits);
  }
} // namespace lifi
