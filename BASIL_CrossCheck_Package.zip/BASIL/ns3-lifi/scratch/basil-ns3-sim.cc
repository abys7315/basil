/**
 * BASIL Li-Fi Simulation Module for ns-3
 * Built on ns-3.42 Discrete-Event Simulator Engine
 * 
 * Phase 2.2 Algorithm Improvement & Research Differentiation Update
 * 
 * Highlights:
 * - Window-level Discrete-Time Count EWMA & CUSUM Change-Point Detector
 * - Predictor Comparison: CUSUM vs EWMA (count-based) vs Persistence vs Static
 * - Controlled Semantic Experiments: Equal Deadlines, Equal Importance, Conflicting Urgency, Overload
 * - Coverage Separation: Dense Viable Optical Coverage vs Mixed Attenuation vs Radial Baseline
 * - Weight Sensitivity Analysis with Normalized Dynamic Invariant
 * - 5-Way Conservation Law Packet Accounting
 */

#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/simulator.h"
#include "ns3/nstime.h"
#include "ns3/packet.h"

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <map>
#include <queue>
#include <deque>
#include <array>
#include <cmath>
#include <algorithm>
#include <random>
#include <iomanip>
#include <cassert>

using namespace ns3;

// ============================================================
// Optical Physics Model (Li-Fi Lambertian Channel)
// ============================================================
namespace lifi {
  constexpr double PI = 3.14159265358979323846;

  inline double lambertian_order(double half_angle_deg) {
    double phi = half_angle_deg * PI / 180.0;
    return -std::log(2.0) / std::log(std::cos(phi));
  }

  inline double los_path_gain(double m, double A_r_cm2, double d_m,
                               double phi_rad, double psi_rad,
                               double Ts = 1.0, double g = 1.0,
                               double fov_deg = 70.0) {
    double fov_rad = fov_deg * PI / 180.0;
    if (std::abs(psi_rad) > fov_rad) return 0.0; // Outside FOV
    double A_r = A_r_cm2 * 1e-4; // cm^2 -> m^2
    double cos_phi = std::cos(phi_rad);
    if (cos_phi <= 0) return 0.0;
    double cos_psi = std::cos(psi_rad);
    if (cos_psi <= 0) return 0.0;

    return ((m + 1.0) * A_r) / (2.0 * PI * d_m * d_m)
           * std::pow(cos_phi, m)
           * Ts * g * cos_psi;
  }

  inline double shot_noise_variance(double P_r_mW, double B_hz, double responsivity = 0.53) {
    const double q = 1.602e-19;
    double P_r = P_r_mW * 1e-3;
    return 2.0 * q * responsivity * P_r * B_hz;
  }

  inline double thermal_noise_variance(double B_hz, double T_K = 298.0) {
    const double k_B = 1.381e-23;
    const double R_L = 50.0; // 50 Ohm load
    return 4.0 * k_B * T_K * B_hz / R_L;
  }

  inline double snr(double P_r_mW, double B_hz, double responsivity = 0.53) {
    double I_signal = responsivity * P_r_mW * 1e-3;
    double sigma2 = shot_noise_variance(P_r_mW, B_hz, responsivity)
                  + thermal_noise_variance(B_hz);
    if (sigma2 <= 0.0) return 1e9;
    return (I_signal * I_signal) / sigma2;
  }

  inline double ber(double snr_val) {
    return 0.5 * std::erfc(std::sqrt(snr_val / 2.0));
  }

  inline double per(double ber_val, int pkt_size_bytes) {
    int bits = pkt_size_bytes * 8;
    return 1.0 - std::pow(1.0 - ber_val, bits);
  }

  // Reproducible 64-bit SplitMix64 hash for scheduler-order-invariant channel draws
  inline double packet_channel_draw(uint64_t seed, uint64_t packet_id, int device_id) {
    uint64_t x = seed ^ (packet_id * 0x9e3779b97f4a7c15ULL) ^ ((uint64_t)device_id * 0xbf58476d1ce4e5b9ULL);
    x = (x ^ (x >> 30)) * 0xbf58476d1ce4e5b9ULL;
    x = (x ^ (x >> 27)) * 0x94d049bb133111ebULL;
    x = x ^ (x >> 31);
    return (double)(x >> 11) * (1.0 / (double)(1ULL << 53));
  }
} // namespace lifi

// ============================================================
// Packet Data Structure
// ============================================================
struct BasilPacket {
  uint64_t id = 0;
  int device_id = 0;
  int priority = 0;              // 0=best-effort, 1=interactive, 2=sensor, 3=emergency
  double semantic_importance = 0.20; // [0.0, 1.0]
  double arrive_time_s = 0.0;
  double deadline_s = -1.0;      // -1.0 = no deadline
  int size_bytes = 1024;
  Ptr<Packet> ns3_pkt;
};

// ============================================================
// Scheduler Base Interface & Baselines
// ============================================================
class LifiScheduler {
public:
  virtual ~LifiScheduler() = default;
  virtual bool enqueue(const BasilPacket& p) = 0;
  virtual bool dequeue(BasilPacket& out, double current_time_s) = 0;
  virtual bool empty() const = 0;
  virtual size_t size() const = 0;
  virtual std::vector<BasilPacket> drain_remaining() = 0;
  virtual std::string name() const = 0;
};

class FIFOScheduler : public LifiScheduler {
  std::deque<BasilPacket> q;
  size_t max_capacity = 2500;
public:
  FIFOScheduler(size_t cap = 2500) : max_capacity(cap) {}
  bool enqueue(const BasilPacket& p) override {
    if (q.size() >= max_capacity) return false;
    q.push_back(p);
    return true;
  }
  bool dequeue(BasilPacket& out, double current_time_s) override {
    if (q.empty()) return false;
    out = q.front(); q.pop_front(); return true;
  }
  bool empty() const override { return q.empty(); }
  size_t size() const override { return q.size(); }
  std::vector<BasilPacket> drain_remaining() override {
    std::vector<BasilPacket> res(q.begin(), q.end());
    q.clear();
    return res;
  }
  std::string name() const override { return "FIFO"; }
};

class RoundRobinScheduler : public LifiScheduler {
  std::vector<std::deque<BasilPacket>> queues;
  int num_devices;
  int current = 0;
  size_t per_device_capacity = 600;
public:
  RoundRobinScheduler(int nd, size_t cap = 600)
    : queues(std::max(1, nd)), num_devices(std::max(1, nd)), per_device_capacity(cap) {}
  bool enqueue(const BasilPacket& p) override {
    int d = std::max(0, std::min(p.device_id, num_devices - 1));
    if (queues[d].size() >= per_device_capacity) return false;
    queues[d].push_back(p);
    return true;
  }
  bool dequeue(BasilPacket& out, double current_time_s) override {
    for (int i = 0; i < num_devices; i++) {
      int idx = (current + i) % num_devices;
      if (!queues[idx].empty()) {
        out = queues[idx].front();
        queues[idx].pop_front();
        current = (idx + 1) % num_devices;
        return true;
      }
    }
    return false;
  }
  bool empty() const override {
    for (const auto& q : queues) if (!q.empty()) return false;
    return true;
  }
  size_t size() const override {
    size_t s = 0;
    for (const auto& q : queues) s += q.size();
    return s;
  }
  std::vector<BasilPacket> drain_remaining() override {
    std::vector<BasilPacket> res;
    for (auto& q : queues) {
      res.insert(res.end(), q.begin(), q.end());
      q.clear();
    }
    return res;
  }
  std::string name() const override { return "RoundRobin"; }
};

class StrictPriorityScheduler : public LifiScheduler {
  std::vector<std::deque<BasilPacket>> queues; // index = priority tier (0..3)
  size_t per_tier_capacity = 600;
public:
  StrictPriorityScheduler(size_t cap = 600) : queues(4), per_tier_capacity(cap) {}
  bool enqueue(const BasilPacket& p) override {
    int pr = std::max(0, std::min(p.priority, 3));
    if (queues[pr].size() >= per_tier_capacity) return false;
    queues[pr].push_back(p);
    return true;
  }
  bool dequeue(BasilPacket& out, double current_time_s) override {
    for (int pr = 3; pr >= 0; pr--) {
      if (!queues[pr].empty()) {
        out = queues[pr].front();
        queues[pr].pop_front();
        return true;
      }
    }
    return false;
  }
  bool empty() const override {
    for (int i = 0; i < 4; i++) if (!queues[i].empty()) return false;
    return true;
  }
  size_t size() const override {
    size_t s = 0;
    for (int i = 0; i < 4; i++) s += queues[i].size();
    return s;
  }
  std::vector<BasilPacket> drain_remaining() override {
    std::vector<BasilPacket> res;
    for (auto& q : queues) {
      res.insert(res.end(), q.begin(), q.end());
      q.clear();
    }
    return res;
  }
  std::string name() const override { return "StrictPriority"; }
};

// ============================================================
// BASIL-PSA Phase 2.2: Intelligent Scheduler Configuration
// ============================================================
struct BasilPsaConfig {
  // Nominal normalized priority weights strictly summing to 1.000:
  double w_s = 0.20; // Semantic importance weight
  double w_u = 0.25; // Deadline urgency weight
  double w_b = 0.15; // Predicted burst pressure weight
  double w_c = 0.15; // Optical channel quality weight
  double w_q = 0.15; // Queue pressure weight
  double w_f = 0.10; // Fairness anti-starvation boost
  
  // Predictor configuration
  std::string predictor_type = "cusum"; // "cusum", "ewma", "persistence", "static"
  double ewma_alpha = 0.25;
  double pred_window_s = 0.10; // 100ms forecast window
  double tau_urgency_s = 0.020; // 20ms slack decay constant
  double max_service_rate_pps = 1000.0;
  double nominal_rate = 80.0;
  double burst_rate = 400.0;
  
  size_t per_device_capacity = 600;

  // Ablation flags
  bool disable_prediction = false;
  bool disable_semantic = false;
  bool disable_channel = false;
  bool disable_fairness = false;
};

class BASILPSAScheduler : public LifiScheduler {
public:
  using Config = BasilPsaConfig;

private:
  int num_devices;
  BasilPsaConfig cfg;
  std::vector<std::deque<BasilPacket>> queues; // per-device FIFO queue
  std::vector<double> device_per;
  
  // Per-device arrival tracking & multi-predictor evaluation
  struct DevicePredictor {
    uint64_t arrivals_in_current_window = 0;
    double window_start_time = 0.0;
    
    // Forecasts for current window (made at window_start_time)
    double predicted_arrivals_ewma = 0.0;
    double predicted_arrivals_cusum = 0.0;
    double predicted_arrivals_persist = 0.0;
    double predicted_arrivals_static = 0.0;
    
    // CUSUM state variables
    double cusum_s_pos = 0.0;
    bool cusum_in_burst = false;
    
    // Error accumulators
    double total_abs_pred_error_ewma = 0.0;
    double total_sq_pred_error_ewma = 0.0;
    
    double total_abs_pred_error_cusum = 0.0;
    double total_sq_pred_error_cusum = 0.0;

    double total_abs_pred_error_persist = 0.0;
    double total_sq_pred_error_persist = 0.0;
    
    double total_abs_pred_error_static = 0.0;
    double total_sq_pred_error_static = 0.0;
    
    uint64_t evaluation_windows_count = 0;
  };
  std::vector<DevicePredictor> predictors;
  
  // Starvation tracking
  std::vector<double> last_service_time;

public:
  BASILPSAScheduler(int nd, const std::vector<double>& pers, BasilPsaConfig c = BasilPsaConfig())
    : num_devices(std::max(1, nd)), cfg(c), queues(std::max(1, nd)),
      device_per(pers), predictors(std::max(1, nd)), last_service_time(std::max(1, nd), 0.0)
  {
    double init_expected = cfg.nominal_rate * cfg.pred_window_s;
    for (int i = 0; i < num_devices; i++) {
      predictors[i].window_start_time = 0.0;
      predictors[i].predicted_arrivals_ewma = init_expected;
      predictors[i].predicted_arrivals_cusum = init_expected;
      predictors[i].predicted_arrivals_persist = init_expected;
      predictors[i].predicted_arrivals_static = init_expected;
    }
  }

  void update_prediction_window(int d, double now_s) {
    auto& pred = predictors[d];
    while (now_s - pred.window_start_time >= cfg.pred_window_s) {
      double actual = (double)pred.arrivals_in_current_window;
      
      // 1. EWMA (Discrete-Time Count EWMA) Error
      double err_ewma = pred.predicted_arrivals_ewma - actual;
      pred.total_abs_pred_error_ewma += std::abs(err_ewma);
      pred.total_sq_pred_error_ewma += (err_ewma * err_ewma);

      // 2. CUSUM Change-Point Detector Error
      double err_cusum = pred.predicted_arrivals_cusum - actual;
      pred.total_abs_pred_error_cusum += std::abs(err_cusum);
      pred.total_sq_pred_error_cusum += (err_cusum * err_cusum);
      
      // 3. Persistence Baseline Error
      double err_persist = pred.predicted_arrivals_persist - actual;
      pred.total_abs_pred_error_persist += std::abs(err_persist);
      pred.total_sq_pred_error_persist += (err_persist * err_persist);
      
      // 4. Static Baseline Error
      double err_static = pred.predicted_arrivals_static - actual;
      pred.total_abs_pred_error_static += std::abs(err_static);
      pred.total_sq_pred_error_static += (err_static * err_static);
      
      pred.evaluation_windows_count++;
      
      // Advance window strictly using past information:
      pred.window_start_time += cfg.pred_window_s;
      pred.arrivals_in_current_window = 0;
      
      // Forecast updates for NEXT window (strictly past-dependent):
      // A. Discrete-Time Count EWMA (eliminates 1/dt rate explosion)
      pred.predicted_arrivals_ewma = (1.0 - cfg.ewma_alpha) * pred.predicted_arrivals_ewma + cfg.ewma_alpha * actual;
      
      // B. Persistence Baseline
      pred.predicted_arrivals_persist = actual;
      
      // C. Static Baseline
      pred.predicted_arrivals_static = cfg.nominal_rate * cfg.pred_window_s;

      // D. CUSUM Change-Point Detection
      double mu0 = cfg.nominal_rate * cfg.pred_window_s;
      double mu1 = cfg.burst_rate * cfg.pred_window_s;
      double k = (mu0 + mu1) / 2.0;
      double h = 1.2 * mu0; // decision threshold
      
      pred.cusum_s_pos = std::max(0.0, pred.cusum_s_pos + (actual - k));
      if (pred.cusum_s_pos > h) {
        pred.cusum_in_burst = true;
      } else if (actual < k && pred.cusum_s_pos <= 0.0) {
        pred.cusum_in_burst = false;
      }
      
      if (pred.cusum_in_burst) {
        pred.predicted_arrivals_cusum = mu1;
      } else {
        pred.predicted_arrivals_cusum = mu0;
      }
    }
  }

  bool enqueue(const BasilPacket& p) override {
    int d = std::max(0, std::min(p.device_id, num_devices - 1));
    if (queues[d].size() >= cfg.per_device_capacity) return false;
    queues[d].push_back(p);
    
    auto& pred = predictors[d];
    pred.arrivals_in_current_window++;
    update_prediction_window(d, p.arrive_time_s);
    return true;
  }

  double compute_priority_score(const BasilPacket& p, double current_time_s) {
    int d = p.device_id;
    update_prediction_window(d, current_time_s);

    // 1. Semantic Importance: [0, 1]
    double i_semantic = cfg.disable_semantic ? 0.5 : std::max(0.0, std::min(1.0, p.semantic_importance));

    // 2. Deadline Urgency: [0, 1]
    double u_urgency = 0.0;
    if (p.deadline_s > 0.0) {
      double slack = p.deadline_s - current_time_s;
      if (slack <= 0.0) {
        u_urgency = 1.0; // Overdue or imminent
      } else {
        u_urgency = std::exp(-slack / cfg.tau_urgency_s);
      }
    }

    // 3. Predicted Burst Pressure: [0, 1]
    double b_pred = 0.0;
    if (!cfg.disable_prediction) {
      double forecast_count = 0.0;
      if (cfg.predictor_type == "cusum") {
        forecast_count = predictors[d].predicted_arrivals_cusum;
      } else if (cfg.predictor_type == "ewma") {
        forecast_count = predictors[d].predicted_arrivals_ewma;
      } else if (cfg.predictor_type == "persistence") {
        forecast_count = predictors[d].predicted_arrivals_persist;
      } else {
        forecast_count = predictors[d].predicted_arrivals_static;
      }
      
      double forecast_rate = forecast_count / cfg.pred_window_s;
      double forecast_load = forecast_rate / cfg.max_service_rate_pps;
      b_pred = 1.0 / (1.0 + std::exp(-5.0 * (forecast_load - 0.40))); // Sigmoid centered at 40% load
    }

    // 4. Optical Channel Quality: [0, 1]
    double c_channel = 1.0;
    if (!cfg.disable_channel) {
      double per_val = (d < (int)device_per.size()) ? device_per[d] : 0.0;
      c_channel = 1.0 - std::min(1.0, std::max(0.0, per_val));
    }

    // 5. Queue Pressure: [0, 1]
    double q_depth = (double)queues[d].size();
    double q_pressure = 1.0 - std::exp(-q_depth / 15.0);

    // 6. Fairness / Anti-Starvation Boost: [0, 1]
    double f_fairness = 0.0;
    if (!cfg.disable_fairness) {
      double wait_hol = current_time_s - p.arrive_time_s;
      double unserviced_time = current_time_s - last_service_time[d];
      f_fairness = 1.0 - std::exp(-std::max(wait_hol, unserviced_time) / 0.050); // 50ms characteristic saturation
    }

    // Dynamic weight normalization guaranteeing strict sum = 1.000
    double active_ws = cfg.disable_semantic   ? 0.0 : cfg.w_s;
    double active_wu = cfg.w_u;
    double active_wb = cfg.disable_prediction ? 0.0 : cfg.w_b;
    double active_wc = cfg.disable_channel    ? 0.0 : cfg.w_c;
    double active_wq = cfg.w_q;
    double active_wf = cfg.disable_fairness   ? 0.0 : cfg.w_f;

    double sum_w = active_ws + active_wu + active_wb + active_wc + active_wq + active_wf;
    if (sum_w <= 0.0) sum_w = 1.0;

    double score = (active_ws * i_semantic +
                    active_wu * u_urgency +
                    active_wb * b_pred +
                    active_wc * c_channel +
                    active_wq * q_pressure +
                    active_wf * f_fairness) / sum_w;

    return std::max(0.0, std::min(1.0, score));
  }

  bool dequeue(BasilPacket& out, double current_time_s) override {
    int best_device = -1;
    size_t best_pkt_idx = 0;
    double max_score = -1.0;

    for (int d = 0; d < num_devices; d++) {
      if (queues[d].empty()) continue;

      size_t check_count = std::min((size_t)4, queues[d].size());
      for (size_t i = 0; i < check_count; i++) {
        double score = compute_priority_score(queues[d][i], current_time_s);
        if (score > max_score) {
          max_score = score;
          best_device = d;
          best_pkt_idx = i;
        }
      }
    }

    if (best_device < 0) return false;

    out = queues[best_device][best_pkt_idx];
    queues[best_device].erase(queues[best_device].begin() + best_pkt_idx);
    last_service_time[best_device] = current_time_s;
    return true;
  }

  bool empty() const override {
    for (const auto& q : queues) if (!q.empty()) return false;
    return true;
  }

  size_t size() const override {
    size_t s = 0;
    for (const auto& q : queues) s += q.size();
    return s;
  }

  std::vector<BasilPacket> drain_remaining() override {
    std::vector<BasilPacket> res;
    for (auto& q : queues) {
      res.insert(res.end(), q.begin(), q.end());
      q.clear();
    }
    return res;
  }

  std::string name() const override { return "BASIL_PSA"; }

  // EWMA Error (Count EWMA)
  double get_ewma_mae() const {
    double sum = 0.0; uint64_t count = 0;
    for (const auto& p : predictors) { sum += p.total_abs_pred_error_ewma; count += p.evaluation_windows_count; }
    return count > 0 ? (sum / count) : 0.0;
  }
  double get_ewma_rmse() const {
    double sum = 0.0; uint64_t count = 0;
    for (const auto& p : predictors) { sum += p.total_sq_pred_error_ewma; count += p.evaluation_windows_count; }
    return count > 0 ? std::sqrt(sum / count) : 0.0;
  }

  // CUSUM Error
  double get_cusum_mae() const {
    double sum = 0.0; uint64_t count = 0;
    for (const auto& p : predictors) { sum += p.total_abs_pred_error_cusum; count += p.evaluation_windows_count; }
    return count > 0 ? (sum / count) : 0.0;
  }
  double get_cusum_rmse() const {
    double sum = 0.0; uint64_t count = 0;
    for (const auto& p : predictors) { sum += p.total_sq_pred_error_cusum; count += p.evaluation_windows_count; }
    return count > 0 ? std::sqrt(sum / count) : 0.0;
  }

  // Persistence Baseline Error
  double get_persist_mae() const {
    double sum = 0.0; uint64_t count = 0;
    for (const auto& p : predictors) { sum += p.total_abs_pred_error_persist; count += p.evaluation_windows_count; }
    return count > 0 ? (sum / count) : 0.0;
  }
  double get_persist_rmse() const {
    double sum = 0.0; uint64_t count = 0;
    for (const auto& p : predictors) { sum += p.total_sq_pred_error_persist; count += p.evaluation_windows_count; }
    return count > 0 ? std::sqrt(sum / count) : 0.0;
  }

  // Static Baseline Error
  double get_static_mae() const {
    double sum = 0.0; uint64_t count = 0;
    for (const auto& p : predictors) { sum += p.total_abs_pred_error_static; count += p.evaluation_windows_count; }
    return count > 0 ? (sum / count) : 0.0;
  }
  double get_static_rmse() const {
    double sum = 0.0; uint64_t count = 0;
    for (const auto& p : predictors) { sum += p.total_sq_pred_error_static; count += p.evaluation_windows_count; }
    return count > 0 ? std::sqrt(sum / count) : 0.0;
  }

  double get_active_mae() const {
    if (cfg.predictor_type == "cusum") return get_cusum_mae();
    if (cfg.predictor_type == "ewma") return get_ewma_mae();
    if (cfg.predictor_type == "persistence") return get_persist_mae();
    return get_static_mae();
  }

  double get_active_rmse() const {
    if (cfg.predictor_type == "cusum") return get_cusum_rmse();
    if (cfg.predictor_type == "ewma") return get_ewma_rmse();
    if (cfg.predictor_type == "persistence") return get_persist_rmse();
    return get_static_rmse();
  }
};

// ============================================================
// Simple JSON Parser
// ============================================================
struct JsonVal {
  enum Type { NUM, STR, BOOL_, NULL_, ARR, OBJ } type = NULL_;
  double num = 0;
  std::string str;
  bool b = false;
  std::vector<JsonVal> arr;
  std::map<std::string, JsonVal> obj;
  JsonVal() = default;
  JsonVal(double v) : type(NUM), num(v) {}
  JsonVal(const std::string& s) : type(STR), str(s) {}
  JsonVal(bool v) : type(BOOL_), b(v) {}
};

static void skip_ws(const std::string& s, size_t& i) {
  while (i < s.size() && (s[i]==' '||s[i]=='\t'||s[i]=='\n'||s[i]=='\r')) i++;
}
static JsonVal parse_value(const std::string& s, size_t& i);
static std::string parse_string(const std::string& s, size_t& i) {
  assert(s[i]=='"'); i++;
  std::string r;
  while (i < s.size() && s[i]!='"') {
    if (s[i]=='\\') { i++; r += s[i]; } else r += s[i];
    i++;
  }
  i++;
  return r;
}
static JsonVal parse_number(const std::string& s, size_t& i) {
  size_t start = i;
  if (i < s.size() && s[i]=='-') i++;
  while (i < s.size() && (std::isdigit(s[i])||s[i]=='.'||s[i]=='e'||s[i]=='E'||s[i]=='+'||s[i]=='-')) i++;
  return JsonVal(std::stod(s.substr(start, i-start)));
}
static JsonVal parse_array(const std::string& s, size_t& i) {
  assert(s[i]=='['); i++;
  JsonVal val; val.type = JsonVal::ARR;
  skip_ws(s, i);
  if (i < s.size() && s[i]==']') { i++; return val; }
  while (i < s.size()) {
    val.arr.push_back(parse_value(s, i));
    skip_ws(s, i);
    if (i < s.size() && s[i]==',') i++;
    else if (i < s.size() && s[i]==']') { i++; break; }
  }
  return val;
}
static JsonVal parse_object(const std::string& s, size_t& i) {
  assert(s[i]=='{'); i++;
  JsonVal val; val.type = JsonVal::OBJ;
  skip_ws(s, i);
  if (i < s.size() && s[i]=='}') { i++; return val; }
  while (i < s.size()) {
    skip_ws(s, i);
    if (i >= s.size() || s[i]!='\"') break;
    std::string key = parse_string(s, i);
    skip_ws(s, i);
    if (i < s.size() && s[i]==':') i++;
    val.obj[key] = parse_value(s, i);
    skip_ws(s, i);
    if (i < s.size() && s[i]==',') i++;
    else if (i < s.size() && s[i]=='}') { i++; break; }
  }
  return val;
}
static JsonVal parse_value(const std::string& s, size_t& i) {
  skip_ws(s, i);
  if (i >= s.size()) return JsonVal();
  if (s[i]=='\"') return JsonVal(parse_string(s, i));
  if (s[i]=='{') return parse_object(s, i);
  if (s[i]=='[') return parse_array(s, i);
  if (std::isdigit(s[i]) || s[i]=='-') return parse_number(s, i);
  if (s.substr(i, 4)=="true") { i+=4; return JsonVal(true); }
  if (s.substr(i, 5)=="false") { i+=5; return JsonVal(false); }
  if (s.substr(i, 4)=="null") { i+=4; return JsonVal(); }
  return JsonVal();
}
static JsonVal parse_json(const std::string& s) {
  size_t i = 0;
  return parse_value(s, i);
}
static double jget(const JsonVal& v, const std::string& key, double def=0.0) {
  auto it = v.obj.find(key);
  if (it == v.obj.end()) return def;
  return it->second.num;
}
static std::string jgets(const JsonVal& v, const std::string& key, const std::string& def="") {
  auto it = v.obj.find(key);
  if (it == v.obj.end()) return def;
  return it->second.str;
}

// ============================================================
// Simulation Execution State & Telemetry
// ============================================================
struct ClassStat {
  std::string name;
  double semantic_weight = 0.20;
  uint64_t generated = 0;
  uint64_t delivered_on_time = 0;
  uint64_t delivered_late = 0;
  uint64_t lost_channel = 0;
  uint64_t dropped_queue = 0;
  uint64_t pending_queue = 0;
  uint64_t generated_with_deadline = 0;
  double latency_ms_sum = 0.0;
};

struct DevStat {
  uint64_t generated = 0;
  uint64_t delivered_on_time = 0;
  uint64_t delivered_late = 0;
  uint64_t lost_channel = 0;
  uint64_t dropped_queue = 0;
  uint64_t pending_queue = 0;
  double latency_ms_sum = 0.0;
  double max_wait_ms = 0.0;
  uint64_t starvation_events = 0;
  double throughput_mbps = 0.0;
  double last_served_s = 0.0;
};

struct SimContext {
  std::unique_ptr<LifiScheduler> scheduler;
  BASILPSAScheduler* basil_psa_ptr = nullptr;
  
  std::vector<double> device_distances;
  std::vector<double> device_snr_db;
  std::vector<double> device_per;
  
  double tx_rate_bps = 10e6;
  double half_angle_deg = 60.0;
  double ap_power_mw = 100.0;
  int packet_size_bytes = 1024;
  
  // 5-way mutually exclusive global packet accounting
  uint64_t total_generated = 0;
  uint64_t total_delivered_on_time = 0;
  uint64_t total_delivered_late = 0;
  uint64_t total_lost_channel = 0;
  uint64_t total_dropped_queue = 0;
  uint64_t total_pending_queue = 0;
  
  uint64_t total_generated_with_deadline = 0;
  uint64_t total_pending_with_deadline_expired = 0;
  uint64_t total_lost_channel_late = 0;
  uint64_t total_dropped_queue_with_deadline = 0;
  
  double total_delivered_latency_ms = 0.0;
  double total_semantic_delivered_on_time_bits = 0.0;
  double total_raw_delivered_on_time_bits = 0.0;
  
  std::vector<double> delivered_latencies_ms;
  std::array<ClassStat, 4> class_stats;
  std::vector<DevStat> dev_stats;
  
  struct TSPair {
    double time_s;
    double throughput_mbps;
    double latency_ms;
    int queue_depth;
  };
  std::vector<TSPair> time_series;
  
  bool is_transmitting = false;
  BasilPacket in_flight_pkt;
  std::vector<BasilPacket> all_generated_packets;
  std::mt19937 rng{42};
  uint64_t seed = 42;
  double total_expected_delivered = 0.0;
};

static SimContext g_sim;

void TryTransmitNext();

void TransmitDone(BasilPacket pkt, bool success, double start_time_s) {
  g_sim.is_transmitting = false;
  double now_s = Simulator::Now().GetSeconds();
  double latency_ms = (now_s - pkt.arrive_time_s) * 1000.0;
  int pr = std::max(0, std::min(pkt.priority, 3));
  int dev = pkt.device_id;
  
  if (latency_ms > g_sim.dev_stats[dev].max_wait_ms) {
    g_sim.dev_stats[dev].max_wait_ms = latency_ms;
  }
  
  bool tx_on_time = (pkt.deadline_s <= 0.0 || now_s <= pkt.deadline_s);
  if (success) {
    if (tx_on_time) {
      g_sim.total_delivered_on_time++;
      g_sim.class_stats[pr].delivered_on_time++;
      g_sim.dev_stats[dev].delivered_on_time++;
      g_sim.total_semantic_delivered_on_time_bits += (pkt.size_bytes * 8.0 * pkt.semantic_importance);
      g_sim.total_raw_delivered_on_time_bits += (pkt.size_bytes * 8.0);
    } else {
      g_sim.total_delivered_late++;
      g_sim.class_stats[pr].delivered_late++;
      g_sim.dev_stats[dev].delivered_late++;
    }
    
    g_sim.total_delivered_latency_ms += latency_ms;
    g_sim.delivered_latencies_ms.push_back(latency_ms);
    g_sim.class_stats[pr].latency_ms_sum += latency_ms;
    g_sim.dev_stats[dev].latency_ms_sum += latency_ms;
    g_sim.dev_stats[dev].last_served_s = now_s;
  } else {
    g_sim.total_lost_channel++;
    g_sim.class_stats[pr].lost_channel++;
    g_sim.dev_stats[dev].lost_channel++;
    if (pkt.deadline_s > 0.0 && !tx_on_time) {
      g_sim.total_lost_channel_late++;
    }
  }
  
  TryTransmitNext();
}

void TryTransmitNext() {
  if (g_sim.is_transmitting || g_sim.scheduler->empty()) return;
  
  BasilPacket pkt;
  double now_s = Simulator::Now().GetSeconds();
  if (!g_sim.scheduler->dequeue(pkt, now_s)) return;
  
  g_sim.is_transmitting = true;
  g_sim.in_flight_pkt = pkt;
  
  double per_val = g_sim.device_per[pkt.device_id];
  double draw = lifi::packet_channel_draw(g_sim.seed, pkt.id, pkt.device_id);
  bool success = (draw >= per_val);
  g_sim.total_expected_delivered += (1.0 - per_val);
  
  double tx_duration_s = (double)(pkt.size_bytes * 8) / g_sim.tx_rate_bps;
  Simulator::Schedule(Seconds(tx_duration_s), &TransmitDone, pkt, success, now_s);
}

void PacketArrivalEvent(BasilPacket pkt) {
  g_sim.total_generated++;
  int pr = std::max(0, std::min(pkt.priority, 3));
  int dev = pkt.device_id;
  
  g_sim.class_stats[pr].generated++;
  g_sim.dev_stats[dev].generated++;
  if (pkt.deadline_s > 0.0) {
    g_sim.total_generated_with_deadline++;
    g_sim.class_stats[pr].generated_with_deadline++;
  }
  
  pkt.arrive_time_s = Simulator::Now().GetSeconds();
  g_sim.all_generated_packets.push_back(pkt);
  
  double now_s = pkt.arrive_time_s;
  if (g_sim.dev_stats[dev].last_served_s > 0.0 && (now_s - g_sim.dev_stats[dev].last_served_s) > 0.100) {
    g_sim.dev_stats[dev].starvation_events++;
  }
  
  bool enqueued = g_sim.scheduler->enqueue(pkt);
  if (!enqueued) {
    g_sim.total_dropped_queue++;
    g_sim.class_stats[pr].dropped_queue++;
    g_sim.dev_stats[dev].dropped_queue++;
    if (pkt.deadline_s > 0.0) {
      g_sim.total_dropped_queue_with_deadline++;
    }
  }
  
  TryTransmitNext();
}

void SampleTelemetry(double interval_s) {
  double now_s = Simulator::Now().GetSeconds();
  uint64_t total_delivered = g_sim.total_delivered_on_time + g_sim.total_delivered_late;
  double mbps = (total_delivered > 0 && now_s > 0)
    ? (total_delivered * g_sim.packet_size_bytes * 8.0) / (now_s * 1e6)
    : 0.0;
  double avg_lat = (total_delivered > 0)
    ? (g_sim.total_delivered_latency_ms / total_delivered)
    : 0.0;
    
  g_sim.time_series.push_back({now_s, mbps, avg_lat, (int)g_sim.scheduler->size()});
  Simulator::Schedule(Seconds(interval_s), &SampleTelemetry, interval_s);
}

// ============================================================
// Main Simulation Entrypoint
// ============================================================
int main(int argc, char* argv[]) {
  if (argc < 2) {
    std::cerr << "Usage: basil-ns3-sim <config.json>" << std::endl;
    return 1;
  }

  std::ifstream f(argv[1]);
  if (!f) {
    std::cerr << "Error: Could not open " << argv[1] << std::endl;
    return 1;
  }
  std::string raw((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>());
  f.close();

  JsonVal cfg = parse_json(raw);

  // Extract core simulation parameters
  int num_devices = (int)jget(cfg, "num_devices", 4);
  double sim_time_s = jget(cfg, "simulation_time", 2.0);
  double data_rate_mbps = jget(cfg, "data_rate", 10.0);
  std::string sched_name = jgets(cfg, "scheduler", "FIFO");
  std::string traffic_mode = jgets(cfg, "traffic_mode", "normal");
  std::string coverage_mode = jgets(cfg, "coverage_mode", "radial");
  double burst_ratio = jget(cfg, "burst_ratio", 0.2);
  double ap_power = jget(cfg, "ap_power", 100.0); // mW
  double half_angle = jget(cfg, "half_angle", 60.0);
  int pkt_size = (int)jget(cfg, "packet_size", 1024);
  double normal_rate = jget(cfg, "normal_rate", 80.0); // pkts/sec
  double burst_rate = jget(cfg, "burst_rate", 400.0);
  int seed_val = (int)jget(cfg, "seed", 1337);

  // BASIL-PSA Configuration & Weight Sensitivity
  BASILPSAScheduler::Config psa_cfg;
  psa_cfg.predictor_type = jgets(cfg, "predictor_type", "cusum");
  if (jget(cfg, "ewma_alpha", -1.0) > 0.0) psa_cfg.ewma_alpha = jget(cfg, "ewma_alpha", 0.25);
  psa_cfg.nominal_rate = normal_rate;
  psa_cfg.burst_rate   = burst_rate;

  if (jget(cfg, "w_s", -1.0) >= 0.0) psa_cfg.w_s = jget(cfg, "w_s", 0.20);
  if (jget(cfg, "w_u", -1.0) >= 0.0) psa_cfg.w_u = jget(cfg, "w_u", 0.25);
  if (jget(cfg, "w_b", -1.0) >= 0.0) psa_cfg.w_b = jget(cfg, "w_b", 0.15);
  if (jget(cfg, "w_c", -1.0) >= 0.0) psa_cfg.w_c = jget(cfg, "w_c", 0.15);
  if (jget(cfg, "w_q", -1.0) >= 0.0) psa_cfg.w_q = jget(cfg, "w_q", 0.15);
  if (jget(cfg, "w_f", -1.0) >= 0.0) psa_cfg.w_f = jget(cfg, "w_f", 0.10);

  // Ablation flags
  psa_cfg.disable_prediction = (jget(cfg, "ablation_no_prediction", 0.0) > 0.5);
  psa_cfg.disable_semantic   = (jget(cfg, "ablation_no_semantic", 0.0) > 0.5);
  psa_cfg.disable_channel    = (jget(cfg, "ablation_no_channel", 0.0) > 0.5);
  psa_cfg.disable_fairness   = (jget(cfg, "ablation_no_fairness", 0.0) > 0.5);

  // Initialize NS-3 Simulator
  Time::SetResolution(Time::NS);
  NodeContainer nodes;
  nodes.Create(num_devices + 1);

  // Initialize SimContext
  g_sim = SimContext();
  g_sim.seed = seed_val;
  g_sim.rng.seed(seed_val);
  g_sim.tx_rate_bps = data_rate_mbps * 1e6;
  g_sim.half_angle_deg = half_angle;
  g_sim.ap_power_mw = ap_power;
  g_sim.packet_size_bytes = pkt_size;
  g_sim.dev_stats.resize(num_devices);

  // Class metadata
  g_sim.class_stats[3].name = "Class 3 (Emergency)";
  g_sim.class_stats[3].semantic_weight = 1.00;
  g_sim.class_stats[2].name = "Class 2 (Sensor)";
  g_sim.class_stats[2].semantic_weight = 0.70;
  g_sim.class_stats[1].name = "Class 1 (Interactive)";
  g_sim.class_stats[1].semantic_weight = 0.50;
  g_sim.class_stats[0].name = "Class 0 (Best-effort)";
  g_sim.class_stats[0].semantic_weight = 0.20;

  // Calculate optical physics for each device based on coverage mode
  double m = lifi::lambertian_order(half_angle);
  g_sim.device_distances.resize(num_devices);
  g_sim.device_snr_db.resize(num_devices);
  g_sim.device_per.resize(num_devices);

  for (int i = 0; i < num_devices; i++) {
    double d = 1.0;
    double phi = 0.0;

    if (coverage_mode == "viable") {
      // All devices within dense viable coverage (0.90m to 2.00m, SNR > 16 dB, PER < 0.02)
      d = 0.90 + (1.10 / std::max(1, num_devices - 1)) * (double)i;
      phi = 0.012 * (double)i;
    } else if (coverage_mode == "mixed") {
      // Half clean (PER < 0.05), half moderately degraded (PER 0.40 - 0.70)
      bool clean = (i % 2 == 0);
      d = clean ? (1.0 + 0.06 * (double)i) : (2.18 + 0.02 * (double)i);
      phi = clean ? (0.015 * (double)i) : (0.24 + 0.01 * (double)i);
    } else {
      // Default radial dispersion (1.0m to 7.0m for 16 devices)
      d = 1.0 + (double)i * 0.4;
      phi = 0.1 * (double)i;
    }

    double psi = phi;
    double H = lifi::los_path_gain(m, 1.0, d, phi, psi, 1.0, 1.0, 70.0);
    double P_r = ap_power * H;
    double snr_val = lifi::snr(P_r, 20e6, 0.53);
    double ber_val = lifi::ber(snr_val);
    double per_val = lifi::per(ber_val, pkt_size);

    g_sim.device_distances[i] = d;
    g_sim.device_snr_db[i] = 10.0 * std::log10(std::max(1.0, snr_val));
    g_sim.device_per[i] = std::min(1.0, std::max(0.0, per_val));
  }

  // Scheduler selection
  if (sched_name == "RoundRobin" || sched_name == "RR") {
    g_sim.scheduler = std::make_unique<RoundRobinScheduler>(num_devices);
  } else if (sched_name == "StrictPriority" || sched_name == "SP") {
    g_sim.scheduler = std::make_unique<StrictPriorityScheduler>();
  } else if (sched_name == "BASIL_PSA" || sched_name == "BASIL-PSA") {
    auto psa = std::make_unique<BASILPSAScheduler>(num_devices, g_sim.device_per, psa_cfg);
    g_sim.basil_psa_ptr = psa.get();
    g_sim.scheduler = std::move(psa);
  } else {
    g_sim.scheduler = std::make_unique<FIFOScheduler>();
  }

  // Multi-Class Traffic Generation
  std::mt19937 gen(seed_val);
  uint64_t pkt_seq = 0;
  
  for (int d = 0; d < num_devices; d++) {
    double t = 0.001 * (d + 1);
    while (t < sim_time_s) {
      bool in_burst = (traffic_mode == "burst") && (std::fmod(t, 0.5) < 0.5 * burst_ratio);
      double current_rate = in_burst ? burst_rate : normal_rate;
      if (current_rate <= 0) current_rate = 1.0;

      std::exponential_distribution<double> exp_dist(current_rate);
      t += exp_dist(gen);
      if (t >= sim_time_s) break;

      BasilPacket p;
      p.id = ++pkt_seq;
      p.device_id = d;
      p.size_bytes = pkt_size;
      p.arrive_time_s = t;
      p.ns3_pkt = Create<Packet>(pkt_size);

      // Traffic Mode Class Mapping
      if (traffic_mode == "semantic_equal_deadlines") {
        // Controlled Exp 1: Equal Deadlines (30ms), Different Semantic Importance
        // Flow 0: Emergency (1.00, 30ms); Flow 1: Best-effort (0.20, 30ms)
        int cls = (d % 2 == 0) ? 3 : 0;
        p.priority = cls;
        p.semantic_importance = (cls == 3) ? 1.00 : 0.20;
        p.deadline_s = t + 0.030; // 30ms equal deadline
      } else if (traffic_mode == "semantic_equal_importance") {
        // Controlled Exp 2: Equal Semantic (0.70), Different Deadlines (15ms vs 50ms)
        p.priority = 2;
        p.semantic_importance = 0.70;
        p.deadline_s = (d % 2 == 0) ? (t + 0.015) : (t + 0.050);
      } else if (traffic_mode == "semantic_conflict_urgency") {
        // Controlled Exp 3: Conflicting Semantic vs Urgency
        // Flow 0: Low semantic (0.20), Tight deadline (15ms)
        // Flow 1: High semantic (1.00), Relaxed deadline (45ms)
        if (d % 2 == 0) {
          p.priority = 0;
          p.semantic_importance = 0.20;
          p.deadline_s = t + 0.015;
        } else {
          p.priority = 3;
          p.semantic_importance = 1.00;
          p.deadline_s = t + 0.045;
        }
      } else if (traffic_mode == "emergency_vs_bulk_overload") {
        // Controlled Exp 4: Heavy Best-effort vs Emergency Telemetry
        if (d == 0) {
          p.priority = 3;
          p.semantic_importance = 1.00;
          p.deadline_s = t + 0.020;
        } else {
          p.priority = 0;
          p.semantic_importance = 0.20;
          p.deadline_s = -1.0; // Best effort bulk
        }
      } else {
        // Standard Multi-Tier Heterogeneous Assignment
        int cls = (3 - (d % 4));
        p.priority = cls;
        if (cls == 3) {
          p.semantic_importance = 1.00;
          p.deadline_s = t + 0.025; // 25ms
        } else if (cls == 2) {
          p.semantic_importance = 0.70;
          p.deadline_s = t + 0.035; // 35ms
        } else if (cls == 1) {
          p.semantic_importance = 0.50;
          p.deadline_s = t + 0.060; // 60ms
        } else {
          p.priority = 0;
          p.semantic_importance = 0.20;
          p.deadline_s = -1.0;      // Best effort
        }
      }

      Simulator::Schedule(Seconds(t), &PacketArrivalEvent, p);
    }
  }

  // Periodic Telemetry Sampling
  Simulator::Schedule(Seconds(0.05), &SampleTelemetry, 0.05);

  // Run NS-3 Simulator
  Simulator::Stop(Seconds(sim_time_s));
  Simulator::Run();

  // Post-Simulation Drain & Pending Queue Audit
  if (g_sim.is_transmitting) {
    g_sim.total_pending_queue++;
    int pr = std::max(0, std::min(g_sim.in_flight_pkt.priority, 3));
    int dev = g_sim.in_flight_pkt.device_id;
    g_sim.class_stats[pr].pending_queue++;
    g_sim.dev_stats[dev].pending_queue++;
    if (g_sim.in_flight_pkt.deadline_s > 0.0 && g_sim.in_flight_pkt.deadline_s <= sim_time_s) {
      g_sim.total_pending_with_deadline_expired++;
    }
  }

  auto pending_packets = g_sim.scheduler->drain_remaining();
  for (const auto& p : pending_packets) {
    g_sim.total_pending_queue++;
    int pr = std::max(0, std::min(p.priority, 3));
    int dev = p.device_id;
    g_sim.class_stats[pr].pending_queue++;
    g_sim.dev_stats[dev].pending_queue++;
    
    if (p.deadline_s > 0.0 && p.deadline_s <= sim_time_s) {
      g_sim.total_pending_with_deadline_expired++;
    }
  }

  Simulator::Destroy();

  // Conservation Law Invariant Check
  uint64_t accounted_packets = g_sim.total_delivered_on_time +
                               g_sim.total_delivered_late +
                               g_sim.total_lost_channel +
                               g_sim.total_dropped_queue +
                               g_sim.total_pending_queue;
  assert(g_sim.total_generated == accounted_packets);

  uint64_t total_delivered = g_sim.total_delivered_on_time + g_sim.total_delivered_late;
  uint64_t total_transmitted = total_delivered + g_sim.total_lost_channel;
  double elapsed_s = sim_time_s;
  
  double pdr_gen = g_sim.total_generated > 0 ? (double)total_delivered / g_sim.total_generated : 0.0;
  double pdr_channel = total_transmitted > 0 ? (double)total_delivered / total_transmitted : 0.0;
  double packet_loss_rate = 1.0 - pdr_gen;
  double avg_lat_ms = total_delivered > 0 ? g_sim.total_delivered_latency_ms / total_delivered : 0.0;
  double throughput_mbps = elapsed_s > 0 ? (total_delivered * pkt_size * 8.0) / (elapsed_s * 1e6) : 0.0;
  double goodput_raw_mbps = elapsed_s > 0 ? (g_sim.total_raw_delivered_on_time_bits) / (elapsed_s * 1e6) : 0.0;
  double goodput_semantic_mbps = elapsed_s > 0 ? (g_sim.total_semantic_delivered_on_time_bits) / (elapsed_s * 1e6) : 0.0;

  // Calculate p95 and p99 latency
  double p95_lat_ms = 0.0, p99_lat_ms = 0.0;
  if (!g_sim.delivered_latencies_ms.empty()) {
    std::sort(g_sim.delivered_latencies_ms.begin(), g_sim.delivered_latencies_ms.end());
    size_t idx95 = (size_t)(0.95 * g_sim.delivered_latencies_ms.size());
    size_t idx99 = (size_t)(0.99 * g_sim.delivered_latencies_ms.size());
    p95_lat_ms = g_sim.delivered_latencies_ms[std::min(idx95, g_sim.delivered_latencies_ms.size() - 1)];
    p99_lat_ms = g_sim.delivered_latencies_ms[std::min(idx99, g_sim.delivered_latencies_ms.size() - 1)];
  }

  // Jain's Fairness Index
  double sum_tput = 0.0, sum_sq_tput = 0.0;
  for (int d = 0; d < num_devices; d++) {
    uint64_t dev_del = g_sim.dev_stats[d].delivered_on_time + g_sim.dev_stats[d].delivered_late;
    double dev_tput = elapsed_s > 0 ? (dev_del * pkt_size * 8.0) / (elapsed_s * 1e6) : 0.0;
    g_sim.dev_stats[d].throughput_mbps = dev_tput;
    sum_tput += dev_tput;
    sum_sq_tput += dev_tput * dev_tput;
  }
  double fairness = (sum_sq_tput > 0 && num_devices > 0)
    ? (sum_tput * sum_tput) / (num_devices * sum_sq_tput)
    : 1.0;

  // Three Separate Metrics for Cross-Algorithm Parity
  uint64_t scheduling_deadline_misses = g_sim.total_delivered_late +
                                       g_sim.total_lost_channel_late +
                                       g_sim.total_dropped_queue_with_deadline +
                                       g_sim.total_pending_with_deadline_expired;

  uint64_t end_to_end_deadline_failures = (g_sim.total_generated_with_deadline > g_sim.total_delivered_on_time)
    ? (g_sim.total_generated_with_deadline - g_sim.total_delivered_on_time)
    : 0;

  uint64_t optical_channel_losses = g_sim.total_lost_channel;

  double scheduling_success_rate = g_sim.total_generated_with_deadline > 0
    ? (double)(g_sim.total_generated_with_deadline - scheduling_deadline_misses) / g_sim.total_generated_with_deadline
    : 1.0;

  double end_to_end_success_rate = g_sim.total_generated_with_deadline > 0
    ? (double)g_sim.total_delivered_on_time / g_sim.total_generated_with_deadline
    : 1.0;

  uint64_t total_deadline_misses = scheduling_deadline_misses;
  double deadline_success_rate = scheduling_success_rate;

  // Multi-predictor accuracy results
  double active_mae = g_sim.basil_psa_ptr ? g_sim.basil_psa_ptr->get_active_mae() : 0.0;
  double active_rmse = g_sim.basil_psa_ptr ? g_sim.basil_psa_ptr->get_active_rmse() : 0.0;
  double ewma_mae = g_sim.basil_psa_ptr ? g_sim.basil_psa_ptr->get_ewma_mae() : 0.0;
  double ewma_rmse = g_sim.basil_psa_ptr ? g_sim.basil_psa_ptr->get_ewma_rmse() : 0.0;
  double cusum_mae = g_sim.basil_psa_ptr ? g_sim.basil_psa_ptr->get_cusum_mae() : 0.0;
  double cusum_rmse = g_sim.basil_psa_ptr ? g_sim.basil_psa_ptr->get_cusum_rmse() : 0.0;
  double persist_mae = g_sim.basil_psa_ptr ? g_sim.basil_psa_ptr->get_persist_mae() : 0.0;
  double persist_rmse = g_sim.basil_psa_ptr ? g_sim.basil_psa_ptr->get_persist_rmse() : 0.0;
  double static_mae = g_sim.basil_psa_ptr ? g_sim.basil_psa_ptr->get_static_mae() : 0.0;
  double static_rmse = g_sim.basil_psa_ptr ? g_sim.basil_psa_ptr->get_static_rmse() : 0.0;

  // Output JSON formatted for BASIL Analytics Engine
  std::cout << std::fixed << std::setprecision(6);
  std::cout << "{\n";
  std::cout << "  \"engine\": \"ns3\",\n";
  std::cout << "  \"ns3_version\": \"3.42\",\n";
  std::cout << "  \"scheduler\": \"" << g_sim.scheduler->name() << "\",\n";
  std::cout << "  \"coverage_mode\": \"" << coverage_mode << "\",\n";
  std::cout << "  \"active_predictor\": \"" << psa_cfg.predictor_type << "\",\n";
  std::cout << "  \"simulation_duration_s\": " << sim_time_s << ",\n";
  std::cout << "  \"num_devices\": " << num_devices << ",\n";
  
  // 5-way mutually exclusive packet accounting
  std::cout << "  \"total_packets_sent\": " << g_sim.total_generated << ",\n";
  std::cout << "  \"total_packets_generated\": " << g_sim.total_generated << ",\n";
  std::cout << "  \"total_packets_delivered\": " << total_delivered << ",\n";
  std::cout << "  \"delivered_on_time\": " << g_sim.total_delivered_on_time << ",\n";
  std::cout << "  \"delivered_late\": " << g_sim.total_delivered_late << ",\n";
  std::cout << "  \"lost_channel\": " << g_sim.total_lost_channel << ",\n";
  std::cout << "  \"dropped_queue\": " << g_sim.total_dropped_queue << ",\n";
  std::cout << "  \"pending_queue\": " << g_sim.total_pending_queue << ",\n";
  std::cout << "  \"total_packets_dropped\": " << (g_sim.total_lost_channel + g_sim.total_dropped_queue) << ",\n";
  
  // Ratios and Denominators
  uint64_t total_scheduled_pkts = g_sim.total_delivered_on_time + g_sim.total_delivered_late + g_sim.total_lost_channel;
  double scheduling_coverage = g_sim.total_generated > 0 ? (double)total_scheduled_pkts / g_sim.total_generated : 0.0;
  double expected_received_pdr = g_sim.total_generated > 0 ? g_sim.total_expected_delivered / g_sim.total_generated : 0.0;

  std::cout << "  \"pdr\": " << pdr_gen << ",\n";
  std::cout << "  \"packet_delivery_ratio\": " << pdr_gen << ",\n";
  std::cout << "  \"scheduling_coverage\": " << scheduling_coverage << ",\n";
  std::cout << "  \"scheduling_coverage_pct\": " << (scheduling_coverage * 100.0) << ",\n";
  std::cout << "  \"scheduled_pdr\": " << scheduling_coverage << ",\n";
  std::cout << "  \"scheduled_packets_count\": " << total_scheduled_pkts << ",\n";
  std::cout << "  \"realized_received_pdr\": " << pdr_gen << ",\n";
  std::cout << "  \"realized_received_pdr_pct\": " << (pdr_gen * 100.0) << ",\n";
  std::cout << "  \"expected_received_pdr\": " << expected_received_pdr << ",\n";
  std::cout << "  \"expected_received_pdr_pct\": " << (expected_received_pdr * 100.0) << ",\n";
  std::cout << "  \"channel_pdr\": " << pdr_channel << ",\n";
  std::cout << "  \"packet_loss\": " << packet_loss_rate << ",\n";
  std::cout << "  \"packet_loss_rate\": " << packet_loss_rate << ",\n";
  std::cout << "  \"ap_power_unit\": \"mW\",\n";
  std::cout << "  \"ap_power_mw\": " << g_sim.ap_power_mw << ",\n";
  std::cout << "  \"ap_power_w\": " << (g_sim.ap_power_mw * 1e-3) << ",\n";
  
  // Latency & Goodput
  std::cout << "  \"avg_latency_ms\": " << avg_lat_ms << ",\n";
  std::cout << "  \"p95_latency_ms\": " << p95_lat_ms << ",\n";
  std::cout << "  \"p99_latency_ms\": " << p99_lat_ms << ",\n";
  std::cout << "  \"throughput_mbps\": " << throughput_mbps << ",\n";
  std::cout << "  \"goodput_raw_mbps\": " << goodput_raw_mbps << ",\n";
  std::cout << "  \"goodput_semantic_mbps\": " << goodput_semantic_mbps << ",\n";
  std::cout << "  \"semantic_goodput_mbps\": " << goodput_semantic_mbps << ",\n";
  
  // Deadlines and Parity Metrics
  std::cout << "  \"total_packets_with_deadline\": " << g_sim.total_generated_with_deadline << ",\n";
  std::cout << "  \"scheduling_deadline_misses\": " << scheduling_deadline_misses << ",\n";
  std::cout << "  \"end_to_end_deadline_failures\": " << end_to_end_deadline_failures << ",\n";
  std::cout << "  \"optical_channel_losses\": " << optical_channel_losses << ",\n";
  std::cout << "  \"scheduling_success_rate\": " << scheduling_success_rate << ",\n";
  std::cout << "  \"end_to_end_success_rate\": " << end_to_end_success_rate << ",\n";
  std::cout << "  \"deadline_misses\": " << scheduling_deadline_misses << ",\n";
  std::cout << "  \"total_deadline_misses\": " << scheduling_deadline_misses << ",\n";
  std::cout << "  \"deadline_success_rate\": " << scheduling_success_rate << ",\n";
  
  // Fairness
  std::cout << "  \"fairness_index\": " << fairness << ",\n";
  std::cout << "  \"jain_fairness_index\": " << fairness << ",\n";
  
  // Multi-predictor accuracy comparison
  std::cout << "  \"burst_prediction_mae\": " << active_mae << ",\n";
  std::cout << "  \"burst_prediction_rmse\": " << active_rmse << ",\n";
  std::cout << "  \"cusum_mae\": " << cusum_mae << ",\n";
  std::cout << "  \"cusum_rmse\": " << cusum_rmse << ",\n";
  std::cout << "  \"ewma_count_mae\": " << ewma_mae << ",\n";
  std::cout << "  \"ewma_count_rmse\": " << ewma_rmse << ",\n";
  std::cout << "  \"persistence_baseline_mae\": " << persist_mae << ",\n";
  std::cout << "  \"persistence_baseline_rmse\": " << persist_rmse << ",\n";
  std::cout << "  \"static_baseline_mae\": " << static_mae << ",\n";
  std::cout << "  \"static_baseline_rmse\": " << static_rmse << ",\n";

  // Per-Class Statistics
  std::cout << "  \"per_class_stats\": [\n";
  for (int c = 3; c >= 0; c--) {
    const auto& cs = g_sim.class_stats[c];
    uint64_t class_del = cs.delivered_on_time + cs.delivered_late;
    double class_pdr = cs.generated > 0 ? (double)class_del / cs.generated : 0.0;
    double class_lat = class_del > 0 ? cs.latency_ms_sum / class_del : 0.0;
    double class_deadline_succ = cs.generated_with_deadline > 0 ? (double)cs.delivered_on_time / cs.generated_with_deadline : 1.0;
    
    std::cout << "    {\n";
    std::cout << "      \"class_id\": " << c << ",\n";
    std::cout << "      \"class_name\": \"" << cs.name << "\",\n";
    std::cout << "      \"semantic_weight\": " << cs.semantic_weight << ",\n";
    std::cout << "      \"generated\": " << cs.generated << ",\n";
    std::cout << "      \"delivered_on_time\": " << cs.delivered_on_time << ",\n";
    std::cout << "      \"delivered_late\": " << cs.delivered_late << ",\n";
    std::cout << "      \"lost_channel\": " << cs.lost_channel << ",\n";
    std::cout << "      \"dropped_queue\": " << cs.dropped_queue << ",\n";
    std::cout << "      \"pending_queue\": " << cs.pending_queue << ",\n";
    std::cout << "      \"pdr\": " << class_pdr << ",\n";
    std::cout << "      \"deadline_success_rate\": " << class_deadline_succ << ",\n";
    std::cout << "      \"avg_latency_ms\": " << class_lat << "\n";
    std::cout << "    }" << (c > 0 ? "," : "") << "\n";
  }
  std::cout << "  ],\n";

  // Per-Device Statistics
  std::cout << "  \"per_device_stats\": [\n";
  for (int d = 0; d < num_devices; d++) {
    const auto& ds = g_sim.dev_stats[d];
    uint64_t dev_del = ds.delivered_on_time + ds.delivered_late;
    double dev_lat = dev_del > 0 ? ds.latency_ms_sum / dev_del : 0.0;
    std::cout << "    {\n";
    std::cout << "      \"device_id\": " << d << ",\n";
    std::cout << "      \"distance_m\": " << g_sim.device_distances[d] << ",\n";
    std::cout << "      \"snr_db\": " << g_sim.device_snr_db[d] << ",\n";
    std::cout << "      \"per\": " << g_sim.device_per[d] << ",\n";
    std::cout << "      \"packets_generated\": " << ds.generated << ",\n";
    std::cout << "      \"packets_sent\": " << ds.generated << ",\n";
    std::cout << "      \"packets_delivered\": " << dev_del << ",\n";
    std::cout << "      \"delivered_on_time\": " << ds.delivered_on_time << ",\n";
    std::cout << "      \"delivered_late\": " << ds.delivered_late << ",\n";
    std::cout << "      \"lost_channel\": " << ds.lost_channel << ",\n";
    std::cout << "      \"dropped_queue\": " << ds.dropped_queue << ",\n";
    std::cout << "      \"pending_queue\": " << ds.pending_queue << ",\n";
    std::cout << "      \"avg_latency_ms\": " << dev_lat << ",\n";
    std::cout << "      \"latency_ms\": " << dev_lat << ",\n";
    std::cout << "      \"max_wait_ms\": " << ds.max_wait_ms << ",\n";
    std::cout << "      \"starvation_events\": " << ds.starvation_events << ",\n";
    std::cout << "      \"throughput_mbps\": " << ds.throughput_mbps << "\n";
    std::cout << "    }" << (d + 1 < num_devices ? "," : "") << "\n";
  }
  std::cout << "  ],\n";

  // Time series
  std::cout << "  \"time_series\": [\n";
  for (size_t i = 0; i < g_sim.time_series.size(); i++) {
    std::cout << "    {\"time_s\": " << g_sim.time_series[i].time_s
              << ", \"throughput_mbps\": " << g_sim.time_series[i].throughput_mbps
              << ", \"latency_ms\": " << g_sim.time_series[i].latency_ms
              << ", \"queue_depth\": " << g_sim.time_series[i].queue_depth
              << "}" << (i + 1 < g_sim.time_series.size() ? "," : "") << "\n";
  }
  std::cout << "  ]";

  if (jget(cfg, "export_trace", 0.0) > 0.5) {
    std::cout << ",\n  \"packet_trace\": [\n";
    for (size_t i = 0; i < g_sim.all_generated_packets.size(); i++) {
      const auto& p = g_sim.all_generated_packets[i];
      std::cout << "    {\"id\": " << p.id
                << ", \"device_id\": " << p.device_id
                << ", \"size_bytes\": " << p.size_bytes
                << ", \"arrive_time_s\": " << p.arrive_time_s
                << ", \"deadline_s\": " << p.deadline_s
                << ", \"priority\": " << p.priority
                << ", \"semantic_importance\": " << p.semantic_importance << "}"
                << (i + 1 < g_sim.all_generated_packets.size() ? ",\n" : "\n");
    }
    std::cout << "  ]\n";
  } else {
    std::cout << "\n";
  }
  std::cout << "}\n";

  return 0;
}
