#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include <iostream>

using namespace ns3;

int main(int argc, char* argv[]) {
    Time::SetResolution(Time::NS);
    std::cout << "NS3 Test Build OK: " << Simulator::Now().GetSeconds() << "s" << std::endl;
    return 0;
}
