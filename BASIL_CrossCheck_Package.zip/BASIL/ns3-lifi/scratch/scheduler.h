#pragma once
#include <queue>
#include <vector>
#include <deque>
#include <cstdint>
#include <string>
#include <array>
#include <algorithm>

namespace lifi {

struct Packet {
  uint64_t id;
  int device_id;
  int priority;       // 0=low, 1=medium, 2=high
  double arrive_time; // simulation seconds
  double deadline;    // simulation seconds (-1 = no deadline)
  int size_bytes;
};

// Abstract base
class Scheduler {
public:
  virtual ~Scheduler() = default;
  virtual void enqueue(Packet p) = 0;
  virtual bool dequeue(Packet& out) = 0;
  virtual bool empty() const = 0;
  virtual size_t size() const = 0;
  virtual std::string name() const = 0;
};

// FIFO
class FIFOScheduler : public Scheduler {
  std::queue<Packet> q;
public:
  void enqueue(Packet p) override { q.push(p); }
  bool dequeue(Packet& out) override {
    if (q.empty()) return false;
    out = q.front(); q.pop(); return true;
  }
  bool empty() const override { return q.empty(); }
  size_t size() const override { return q.size(); }
  std::string name() const override { return "FIFO"; }
};

// Round Robin (per device)
class RoundRobinScheduler : public Scheduler {
  std::vector<std::deque<Packet>> queues;
  int num_devices;
  int current = 0;
public:
  RoundRobinScheduler(int nd) : queues(nd), num_devices(nd) {}
  void enqueue(Packet p) override {
    int d = std::max(0, std::min(p.device_id, num_devices - 1));
    queues[d].push_back(p);
  }
  bool dequeue(Packet& out) override {
    for (int i = 0; i < num_devices; i++) {
      int idx = (current + i) % num_devices;
      if (!queues[idx].empty()) {
        out = queues[idx].front();
        queues[idx].pop_front();
        current = (idx + 1) % num_devices;
        return true;
      }
    }
    return false;
  }
  bool empty() const override {
    for (auto& q : queues) if (!q.empty()) return false; return true;
  }
  size_t size() const override {
    size_t s = 0; for (auto& q : queues) s += q.size(); return s;
  }
  std::string name() const override { return "RoundRobin"; }
};

// Strict Priority (3 levels: 0=low, 1=med, 2=high)
class StrictPriorityScheduler : public Scheduler {
  std::queue<Packet> queues[3]; // index = priority
public:
  void enqueue(Packet p) override {
    int pr = std::max(0, std::min(p.priority, 2));
    queues[pr].push(p);
  }
  bool dequeue(Packet& out) override {
    for (int pr = 2; pr >= 0; pr--) {
      if (!queues[pr].empty()) {
        out = queues[pr].front();
        queues[pr].pop();
        return true;
      }
    }
    return false;
  }
  bool empty() const override {
    for (auto& q : queues) if (!q.empty()) return false; return true;
  }
  size_t size() const override {
    size_t s = 0; for (auto& q : queues) s += q.size(); return s;
  }
  std::string name() const override { return "StrictPriority"; }
};

// BASIL-PSA: Priority-Sensitive Adaptive scheduler
// Uses urgency = (deadline - now) / remaining_service_time
// Falls back to weighted round-robin for no-deadline traffic
// Rebalances when burst detected (queue depth > threshold)
class BASILPSAScheduler : public Scheduler {
  std::vector<std::deque<Packet>> device_queues;
  std::array<std::deque<Packet>, 3> priority_queues; // for deadline traffic
  int num_devices;
  int rr_index = 0;
  static constexpr int BURST_THRESHOLD = 20;
  static constexpr double SERVICE_TIME_MS = 0.1; // per-packet service estimate

  double compute_urgency(const Packet& p, double now) const {
    if (p.deadline < 0) return -1.0;
    double slack = p.deadline - now;
    if (slack <= 0) return 1e9; // overdue - highest urgency
    return 1.0 / slack; // higher urgency = less slack
  }

public:
  BASILPSAScheduler(int nd) : device_queues(nd), num_devices(nd) {}

  void enqueue(Packet p) override {
    if (p.deadline >= 0) {
      int pr = std::max(0, std::min(p.priority, 2));
      priority_queues[pr].push_back(p);
    } else {
      int d = std::max(0, std::min(p.device_id, num_devices - 1));
      device_queues[d].push_back(p);
    }
  }

  bool dequeue(Packet& out) override {
    // Check for burst condition in deadline queues
    bool burst = false;
    for (auto& q : priority_queues) if (q.size() > BURST_THRESHOLD) { burst = true; break; }

    if (burst || !all_deadline_empty()) {
      // Serve highest-urgency deadline packet
      int best_pr = -1;
      for (int pr = 2; pr >= 0; pr--) {
        if (!priority_queues[pr].empty()) { best_pr = pr; break; }
      }
      if (best_pr >= 0) {
        out = priority_queues[best_pr].front();
        priority_queues[best_pr].pop_front();
        return true;
      }
    }

    // Weighted round-robin for best-effort traffic
    for (int i = 0; i < num_devices; i++) {
      int idx = (rr_index + i) % num_devices;
      if (!device_queues[idx].empty()) {
        out = device_queues[idx].front();
        device_queues[idx].pop_front();
        rr_index = (idx + 1) % num_devices;
        return true;
      }
    }
    return false;
  }

  bool all_deadline_empty() const {
    for (auto& q : priority_queues) if (!q.empty()) return false; return true;
  }

  bool empty() const override {
    if (!all_deadline_empty()) return false;
    for (auto& q : device_queues) if (!q.empty()) return false;
    return true;
  }

  size_t size() const override {
    size_t s = 0;
    for (auto& q : priority_queues) s += q.size();
    for (auto& q : device_queues) s += q.size();
    return s;
  }

  std::string name() const override { return "BASIL_PSA"; }
};

} // namespace lifi
