/**
 * BASIL Li-Fi Discrete-Event Simulator
 * Standalone C++17, no ns-3 required.
 * 
 * Usage: basil-sim.exe <config.json>
 * Output: JSON to stdout
 */

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <map>
#include <queue>
#include <functional>
#include <random>
#include <cmath>
#include <algorithm>
#include <memory>
#include <cassert>
#include <iomanip>
#include <stdexcept>

#include "lifi_physics.h"
#include "scheduler.h"

// ============================================================
// Minimal JSON parser (key-value flat + nested objects)
// ============================================================
struct JsonVal {
  enum Type { NUM, STR, BOOL_, NULL_, ARR, OBJ } type;
  double num = 0;
  std::string str;
  bool b = false;
  std::vector<JsonVal> arr;
  std::map<std::string, JsonVal> obj;
  JsonVal() : type(NULL_) {}
  JsonVal(double v) : type(NUM), num(v) {}
  JsonVal(const std::string& s) : type(STR), str(s) {}
  JsonVal(bool v) : type(BOOL_), b(v) {}
};

static void skip_ws(const std::string& s, size_t& i) {
  while (i < s.size() && (s[i]==' '||s[i]=='\t'||s[i]=='\n'||s[i]=='\r')) i++;
}
static JsonVal parse_value(const std::string& s, size_t& i);
static std::string parse_string(const std::string& s, size_t& i) {
  assert(s[i]=='"'); i++;
  std::string r;
  while (i < s.size() && s[i]!='"') {
    if (s[i]=='\\') { i++; r += s[i]; } else r += s[i];
    i++;
  }
  i++; // closing "
  return r;
}
static JsonVal parse_number(const std::string& s, size_t& i) {
  size_t start = i;
  if (i < s.size() && s[i]=='-') i++;
  while (i < s.size() && (std::isdigit(s[i])||s[i]=='.'||s[i]=='e'||s[i]=='E'||s[i]=='+'||s[i]=='-')) i++;
  return JsonVal(std::stod(s.substr(start, i-start)));
}
static JsonVal parse_array(const std::string& s, size_t& i) {
  assert(s[i]=='['); i++;
  JsonVal v; v.type = JsonVal::ARR;
  skip_ws(s, i);
  while (i < s.size() && s[i]!=']') {
    v.arr.push_back(parse_value(s, i));
    skip_ws(s, i);
    if (i < s.size() && s[i]==',') i++;
    skip_ws(s, i);
  }
  if (i < s.size()) i++;
  return v;
}
static JsonVal parse_object(const std::string& s, size_t& i) {
  assert(s[i]=='{'); i++;
  JsonVal v; v.type = JsonVal::OBJ;
  skip_ws(s, i);
  while (i < s.size() && s[i]!='}') {
    skip_ws(s, i);
    std::string key = parse_string(s, i);
    skip_ws(s, i);
    assert(s[i]==':'); i++;
    skip_ws(s, i);
    v.obj[key] = parse_value(s, i);
    skip_ws(s, i);
    if (i < s.size() && s[i]==',') i++;
    skip_ws(s, i);
  }
  if (i < s.size()) i++;
  return v;
}
static JsonVal parse_value(const std::string& s, size_t& i) {
  skip_ws(s, i);
  if (i >= s.size()) return JsonVal();
  char c = s[i];
  if (c=='"') return JsonVal(parse_string(s, i));
  if (c=='{') return parse_object(s, i);
  if (c=='[') return parse_array(s, i);
  if (c=='t') { i+=4; return JsonVal(true); }
  if (c=='f') { i+=5; return JsonVal(false); }
  if (c=='n') { i+=4; return JsonVal(); }
  return parse_number(s, i);
}
static JsonVal parse_json(const std::string& s) {
  size_t i = 0;
  return parse_value(s, i);
}

static double jget(const JsonVal& v, const std::string& key, double def=0.0) {
  auto it = v.obj.find(key);
  if (it == v.obj.end()) return def;
  return it->second.num;
}
static std::string jgets(const JsonVal& v, const std::string& key, const std::string& def="") {
  auto it = v.obj.find(key);
  if (it == v.obj.end()) return def;
  return it->second.str;
}
static bool jgetb(const JsonVal& v, const std::string& key, bool def=false) {
  auto it = v.obj.find(key);
  if (it == v.obj.end()) return def;
  if (it->second.type == JsonVal::BOOL_) return it->second.b;
  return (bool)it->second.num;
}

// ============================================================
// Config structures
// ============================================================
struct DeviceConfig {
  int id;
  double distance_m;       // from AP
  double emission_angle_deg;
  double incidence_angle_deg;
  double tx_power_mw;
};

struct NetworkConfig {
  std::string name;
  int num_devices;
  double half_angle_deg;        // LED half-angle
  double receiver_area_cm2;
  double bandwidth_hz;
  double data_rate_mbps;
  double responsivity;
  std::vector<DeviceConfig> devices;
};

struct TrafficConfig {
  std::string name;
  std::string scheduler;        // FIFO | RoundRobin | StrictPriority | BASIL_PSA
  double normal_rate_pps;       // packets per second per device
  double burst_rate_pps;        // during burst
  double burst_duration_s;
  double burst_interval_s;      // time between bursts
  int packet_size_bytes;
  int priority;                 // default priority for generated packets
  double deadline_ms;           // -1 = no deadline
  double simulation_duration_s;
  int seed;
};

// ============================================================
// DES Event Engine
// ============================================================
struct Event {
  double time;
  int type; // 0=arrive, 1=transmit_done
  uint64_t pkt_id;
  int device_id;
  bool operator>(const Event& o) const { return time > o.time; }
};

using EventQueue = std::priority_queue<Event, std::vector<Event>, std::greater<Event>>;

// ============================================================
// Per-device stats
// ============================================================
struct DeviceStats {
  int device_id;
  uint64_t pkts_sent = 0;
  uint64_t pkts_delivered = 0;
  uint64_t pkts_dropped = 0;
  uint64_t deadline_misses = 0;
  double total_latency_s = 0.0;
  double total_bytes_delivered = 0.0;
  double snr_db = 0.0;
  double ber = 0.0;
  double per_val = 0.0;
  double received_power_mw = 0.0;
};

// ============================================================
// Time-series sample
// ============================================================
struct TSSample {
  double time_s;
  double throughput_mbps;
  double latency_ms;
  size_t queue_depth;
};

// ============================================================
// JSON output helpers
// ============================================================
static std::string json_escape(const std::string& s) {
  std::string r;
  for (char c : s) {
    if (c=='"') r += "\\\"";
    else if (c=='\\') r += "\\\\";
    else if (c=='\n') r += "\\n";
    else r += c;
  }
  return r;
}

// ============================================================
// Simulation
// ============================================================
int main(int argc, char* argv[]) {
  if (argc < 2) {
    std::cerr << "Usage: basil-sim <config.json>\n";
    return 1;
  }

  // Load config
  std::ifstream f(argv[1]);
  if (!f) { std::cerr << "Cannot open config: " << argv[1] << "\n"; return 1; }
  std::string raw((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>());
  f.close();

  JsonVal cfg = parse_json(raw);

  // Parse network config
  NetworkConfig net;
  JsonVal& nc = cfg.obj.count("network") ? cfg.obj["network"] : cfg;
  net.name             = jgets(nc, "name", "default");
  net.num_devices      = (int)jget(nc, "num_devices", 4);
  net.half_angle_deg   = jget(nc, "half_angle_deg", 60.0);
  net.receiver_area_cm2 = jget(nc, "receiver_area_cm2", 1.0);
  net.bandwidth_hz     = jget(nc, "bandwidth_hz", 20e6);
  net.data_rate_mbps   = jget(nc, "data_rate_mbps", 10.0);
  net.responsivity     = jget(nc, "responsivity", 0.53);

  // Build devices (use defaults if not specified)
  if (nc.obj.count("devices") && nc.obj["devices"].type == JsonVal::ARR) {
    for (auto& dv : nc.obj["devices"].arr) {
      DeviceConfig dc;
      dc.id                   = (int)jget(dv, "id", net.devices.size());
      dc.distance_m           = jget(dv, "distance_m", 2.0);
      dc.emission_angle_deg   = jget(dv, "emission_angle_deg", 0.0);
      dc.incidence_angle_deg  = jget(dv, "incidence_angle_deg", 0.0);
      dc.tx_power_mw          = jget(dv, "tx_power_mw", 50.0);
      net.devices.push_back(dc);
    }
  } else {
    // Generate default devices at varying distances
    double tx_power = jget(nc, "tx_power_mw", 50.0);
    for (int i = 0; i < net.num_devices; i++) {
      DeviceConfig dc;
      dc.id = i;
      dc.distance_m = 1.0 + i * 0.5;  // 1.0, 1.5, 2.0, 2.5 ...
      dc.emission_angle_deg  = 0.0;
      dc.incidence_angle_deg = 0.0;
      dc.tx_power_mw = tx_power;
      net.devices.push_back(dc);
    }
  }
  net.num_devices = (int)net.devices.size();

  // Parse traffic config
  TrafficConfig tc;
  JsonVal& trc = cfg.obj.count("traffic") ? cfg.obj["traffic"] : cfg;
  tc.name                  = jgets(trc, "name", "default");
  tc.scheduler             = jgets(trc, "scheduler", "FIFO");
  tc.normal_rate_pps       = jget(trc, "normal_rate_pps", 100.0);
  tc.burst_rate_pps        = jget(trc, "burst_rate_pps", 500.0);
  tc.burst_duration_s      = jget(trc, "burst_duration_s", 0.1);
  tc.burst_interval_s      = jget(trc, "burst_interval_s", 1.0);
  tc.packet_size_bytes     = (int)jget(trc, "packet_size_bytes", 1024);
  tc.priority              = (int)jget(trc, "priority", 1);
  tc.deadline_ms           = jget(trc, "deadline_ms", -1.0);
  tc.simulation_duration_s = jget(trc, "simulation_duration_s", 5.0);
  tc.seed                  = (int)jget(trc, "seed", 42);

  // ===== Compute Li-Fi channel parameters per device =====
  double m = lifi::lambertian_order(net.half_angle_deg);
  std::vector<DeviceStats> dev_stats(net.num_devices);
  for (int i = 0; i < net.num_devices; i++) {
    dev_stats[i].device_id = i;
    auto& dc = net.devices[i];
    double phi = dc.emission_angle_deg  * lifi::PI / 180.0;
    double psi = dc.incidence_angle_deg * lifi::PI / 180.0;
    double H   = lifi::los_path_gain(m, net.receiver_area_cm2, dc.distance_m,
                                      phi, psi, 1.0, 1.0);
    double P_r = lifi::received_power(dc.tx_power_mw, H);
    double snr_val = lifi::snr(P_r, net.bandwidth_hz, net.responsivity);
    double ber_val = lifi::ber(snr_val);
    double per_val = lifi::per(ber_val, tc.packet_size_bytes);
    dev_stats[i].snr_db          = 10.0 * std::log10(std::max(snr_val, 1e-30));
    dev_stats[i].ber             = ber_val;
    dev_stats[i].per_val         = per_val;
    dev_stats[i].received_power_mw = P_r;
  }

  // ===== Build scheduler =====
  std::unique_ptr<lifi::Scheduler> sched;
  if (tc.scheduler == "RoundRobin")
    sched = std::make_unique<lifi::RoundRobinScheduler>(net.num_devices);
  else if (tc.scheduler == "StrictPriority")
    sched = std::make_unique<lifi::StrictPriorityScheduler>();
  else if (tc.scheduler == "BASIL_PSA")
    sched = std::make_unique<lifi::BASILPSAScheduler>(net.num_devices);
  else
    sched = std::make_unique<lifi::FIFOScheduler>();

  // ===== DES =====
  EventQueue events;
  std::mt19937 rng(tc.seed);

  // Per-device Poisson arrival processes
  // Compute inter-arrival times from rate; burst superimposed via multiplier
  double data_rate_bps = net.data_rate_mbps * 1e6;
  double bit_time_s    = 1.0 / data_rate_bps; // time per bit
  double tx_time_s     = tc.packet_size_bytes * 8.0 * bit_time_s; // per packet

  // Schedule initial arrivals for each device
  std::vector<std::exponential_distribution<double>> arr_dists;
  for (int i = 0; i < net.num_devices; i++) {
    double rate = tc.normal_rate_pps;
    arr_dists.emplace_back(rate);
  }

  uint64_t pkt_id_counter = 0;
  // Packet info map (id -> packet) for in-flight lookup
  std::map<uint64_t, lifi::Packet> pkt_map;

  // Schedule first arrival per device
  for (int d = 0; d < net.num_devices; d++) {
    double t = arr_dists[d](rng);
    if (t < tc.simulation_duration_s) {
      events.push({t, 0, pkt_id_counter, d});
      // Create placeholder - will be fully created when processed
      lifi::Packet p;
      p.id = pkt_id_counter++;
      p.device_id = d;
      p.priority = tc.priority;
      p.arrive_time = t;
      p.deadline = (tc.deadline_ms > 0) ? (t + tc.deadline_ms * 1e-3) : -1.0;
      p.size_bytes = tc.packet_size_bytes;
      pkt_map[p.id] = p;
    }
  }

  // Channel is shared; track when it's free
  double channel_free_at = 0.0;

  // Time-series data
  std::vector<TSSample> ts_samples;
  double sample_interval = 0.1;
  double next_sample_time = sample_interval;

  // Per-interval accounting for throughput
  double interval_bytes = 0.0;
  double interval_latency_sum = 0.0;
  int    interval_delivered = 0;

  // Burst schedule
  // burst starts at t=burst_interval_s, lasts burst_duration_s, repeats
  auto is_burst = [&](double t) -> bool {
    if (tc.burst_interval_s <= 0) return false;
    double phase = std::fmod(t, tc.burst_interval_s);
    return phase < tc.burst_duration_s;
  };

  double sim_time = 0.0;

  while (!events.empty()) {
    Event ev = events.top(); events.pop();
    sim_time = ev.time;

    // Sample time-series
    while (next_sample_time <= sim_time && next_sample_time <= tc.simulation_duration_s) {
      double tp = interval_bytes * 8.0 / sample_interval / 1e6; // Mbps
      double lat = interval_delivered > 0 ? (interval_latency_sum / interval_delivered * 1000.0) : 0.0;
      ts_samples.push_back({next_sample_time, tp, lat, sched->size()});
      next_sample_time += sample_interval;
      interval_bytes = 0.0;
      interval_latency_sum = 0.0;
      interval_delivered = 0;
    }

    if (ev.time > tc.simulation_duration_s) break;

    if (ev.type == 0) {
      // Arrival event
      int d = ev.device_id;
      auto& p = pkt_map[ev.pkt_id];
      dev_stats[d].pkts_sent++;
      sched->enqueue(p);

      // Schedule next arrival for this device
      double rate = is_burst(ev.time) ? tc.burst_rate_pps : tc.normal_rate_pps;
      std::exponential_distribution<double> next_arr(rate);
      double next_t = ev.time + next_arr(rng);
      if (next_t < tc.simulation_duration_s) {
        uint64_t nid = pkt_id_counter++;
        lifi::Packet np;
        np.id = nid;
        np.device_id = d;
        np.priority  = tc.priority;
        np.arrive_time = next_t;
        np.deadline   = (tc.deadline_ms > 0) ? (next_t + tc.deadline_ms * 1e-3) : -1.0;
        np.size_bytes = tc.packet_size_bytes;
        pkt_map[nid] = np;
        events.push({next_t, 0, nid, d});
      }

      // If channel is free, immediately try to transmit
      if (channel_free_at <= ev.time) {
        lifi::Packet out;
        if (sched->dequeue(out)) {
          double done_t = ev.time + tx_time_s;
          channel_free_at = done_t;
          events.push({done_t, 1, out.id, out.device_id});
        }
      }

    } else {
      // Transmit done event
      int d = ev.device_id;
      auto it = pkt_map.find(ev.pkt_id);
      if (it != pkt_map.end()) {
        auto& p = it->second;
        // Check PER (probabilistic drop)
        double per_d = dev_stats[d].per_val;
        std::uniform_real_distribution<double> udist(0.0, 1.0);
        bool dropped = (udist(rng) < per_d);

        if (!dropped) {
          double latency = ev.time - p.arrive_time;
          bool deadline_miss = (p.deadline >= 0 && ev.time > p.deadline);
          dev_stats[d].pkts_delivered++;
          dev_stats[d].total_latency_s += latency;
          dev_stats[d].total_bytes_delivered += p.size_bytes;
          if (deadline_miss) dev_stats[d].deadline_misses++;
          interval_bytes += p.size_bytes;
          interval_latency_sum += latency;
          interval_delivered++;
        } else {
          dev_stats[d].pkts_dropped++;
        }
        pkt_map.erase(it);
      }

      // Schedule next transmission from queue
      lifi::Packet next_out;
      if (sched->dequeue(next_out)) {
        double done_t = ev.time + tx_time_s;
        channel_free_at = done_t;
        events.push({done_t, 1, next_out.id, next_out.device_id});
      } else {
        channel_free_at = ev.time;
      }
    }
  }

  // Final sample
  if (interval_delivered > 0 || next_sample_time <= tc.simulation_duration_s) {
    double tp = interval_bytes * 8.0 / sample_interval / 1e6;
    double lat = interval_delivered > 0 ? (interval_latency_sum / interval_delivered * 1000.0) : 0.0;
    ts_samples.push_back({tc.simulation_duration_s, tp, lat, sched->size()});
  }

  // ===== Compute aggregate statistics =====
  uint64_t total_sent = 0, total_delivered = 0, total_dropped = 0, total_deadline_misses = 0;
  double total_latency = 0.0, total_bytes = 0.0;
  for (auto& ds : dev_stats) {
    total_sent      += ds.pkts_sent;
    total_delivered += ds.pkts_delivered;
    total_dropped   += ds.pkts_dropped;
    total_deadline_misses += ds.deadline_misses;
    total_latency   += ds.total_latency_s;
    total_bytes     += ds.total_bytes_delivered;
  }

  double pdr = total_sent > 0 ? (double)total_delivered / total_sent : 0.0;
  double avg_latency_ms = total_delivered > 0 ? (total_latency / total_delivered * 1000.0) : 0.0;
  double throughput_mbps = total_bytes * 8.0 / tc.simulation_duration_s / 1e6;
  double deadline_miss_rate = total_delivered > 0 ? (double)total_deadline_misses / total_delivered : 0.0;

  // Jain fairness index on per-device throughput
  std::vector<double> dev_tput(net.num_devices, 0.0);
  for (int i = 0; i < net.num_devices; i++) {
    dev_tput[i] = dev_stats[i].total_bytes_delivered * 8.0 / tc.simulation_duration_s / 1e6;
  }
  double sum_x = 0.0, sum_x2 = 0.0;
  for (double x : dev_tput) { sum_x += x; sum_x2 += x*x; }
  double n = net.num_devices;
  double fairness = (sum_x2 > 0) ? (sum_x * sum_x) / (n * sum_x2) : 1.0;

  // ===== Output JSON =====
  std::cout << std::fixed << std::setprecision(6);
  std::cout << "{\n";
  std::cout << "  \"scheduler\": \"" << json_escape(sched->name()) << "\",\n";
  std::cout << "  \"simulation_duration_s\": " << tc.simulation_duration_s << ",\n";
  std::cout << "  \"num_devices\": " << net.num_devices << ",\n";
  std::cout << "  \"total_packets_sent\": " << total_sent << ",\n";
  std::cout << "  \"total_packets_delivered\": " << total_delivered << ",\n";
  std::cout << "  \"total_packets_dropped\": " << total_dropped << ",\n";
  std::cout << "  \"pdr\": " << pdr << ",\n";
  std::cout << "  \"avg_latency_ms\": " << avg_latency_ms << ",\n";
  std::cout << "  \"throughput_mbps\": " << throughput_mbps << ",\n";
  std::cout << "  \"deadline_miss_rate\": " << deadline_miss_rate << ",\n";
  std::cout << "  \"jain_fairness_index\": " << fairness << ",\n";
  std::cout << "  \"total_deadline_misses\": " << total_deadline_misses << ",\n";

  // Per-device stats
  std::cout << "  \"per_device\": [\n";
  for (int i = 0; i < net.num_devices; i++) {
    auto& ds = dev_stats[i];
    double dev_pdr = ds.pkts_sent > 0 ? (double)ds.pkts_delivered / ds.pkts_sent : 0.0;
    double dev_lat = ds.pkts_delivered > 0 ? (ds.total_latency_s / ds.pkts_delivered * 1000.0) : 0.0;
    std::cout << "    {\n";
    std::cout << "      \"device_id\": " << ds.device_id << ",\n";
    std::cout << "      \"distance_m\": " << net.devices[i].distance_m << ",\n";
    std::cout << "      \"snr_db\": " << ds.snr_db << ",\n";
    std::cout << "      \"ber\": " << ds.ber << ",\n";
    std::cout << "      \"per\": " << ds.per_val << ",\n";
    std::cout << "      \"received_power_mw\": " << ds.received_power_mw << ",\n";
    std::cout << "      \"pkts_sent\": " << ds.pkts_sent << ",\n";
    std::cout << "      \"pkts_delivered\": " << ds.pkts_delivered << ",\n";
    std::cout << "      \"pkts_dropped\": " << ds.pkts_dropped << ",\n";
    std::cout << "      \"deadline_misses\": " << ds.deadline_misses << ",\n";
    std::cout << "      \"pdr\": " << dev_pdr << ",\n";
    std::cout << "      \"avg_latency_ms\": " << dev_lat << ",\n";
    std::cout << "      \"throughput_mbps\": " << dev_tput[i] << "\n";
    std::cout << "    }";
    if (i < net.num_devices - 1) std::cout << ",";
    std::cout << "\n";
  }
  std::cout << "  ],\n";

  // Time-series
  std::cout << "  \"time_series\": [\n";
  for (size_t i = 0; i < ts_samples.size(); i++) {
    auto& ts = ts_samples[i];
    std::cout << "    {\"time_s\": " << ts.time_s
              << ", \"throughput_mbps\": " << ts.throughput_mbps
              << ", \"latency_ms\": " << ts.latency_ms
              << ", \"queue_depth\": " << ts.queue_depth << "}";
    if (i + 1 < ts_samples.size()) std::cout << ",";
    std::cout << "\n";
  }
  std::cout << "  ]\n";
  std::cout << "}\n";

  return 0;
}
