@echo off
cd /d %~dp0
cd scratch
"C:\MinGW\bin\g++.exe" -std=c++17 -O2 -o basil-sim.exe basil-sim.cc
if %ERRORLEVEL%==0 (echo Build successful: basil-sim.exe) else (echo Build FAILED)
