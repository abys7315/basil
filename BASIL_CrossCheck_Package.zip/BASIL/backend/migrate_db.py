import sqlite3

def migrate():
    db_path = r'c:\Users\abys7\Downloads\BASIL-starter\BASIL\experiments\basil.db'
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()
    cur.execute("PRAGMA table_info(experiments);")
    columns = [col[1] for col in cur.fetchall()]
    if "engine" not in columns:
        cur.execute("ALTER TABLE experiments ADD COLUMN engine TEXT DEFAULT 'ns3';")
        conn.commit()
        print("Engine column added successfully.")
    else:
        print("Engine column already exists.")
    conn.close()

if __name__ == '__main__':
    migrate()
