from datetime import datetime
from typing import Optional
from pydantic import BaseModel


class NetworkConfigCreate(BaseModel):
    name: str
    num_devices: int
    room_width: float
    room_height: float
    ap_power: float
    half_angle: float
    data_rate_mbps: float


class NetworkConfigResponse(BaseModel):
    id: int
    name: str
    num_devices: int
    room_width: float
    room_height: float
    ap_power: float
    half_angle: float
    data_rate_mbps: float
    created_at: Optional[str] = None

    model_config = {"from_attributes": True}
