from typing import Optional, List, Any, Dict
from pydantic import BaseModel, model_validator


class ExperimentCreate(BaseModel):
    name: str
    network_config_id: int
    traffic_config_id: int
    scheduler: str
    simulation_time: Optional[float] = None
    sim_time: Optional[float] = None
    engine: Optional[str] = "ns3"

    @model_validator(mode="after")
    def resolve_time(self):
        if self.simulation_time is None and self.sim_time is not None:
            self.simulation_time = self.sim_time
        elif self.simulation_time is None and self.sim_time is None:
            self.simulation_time = 1.0
        if self.sim_time is None and self.simulation_time is not None:
            self.sim_time = self.simulation_time
        return self


class ExperimentResponse(BaseModel):
    id: int
    name: str
    network_config_id: int
    traffic_config_id: int
    scheduler: str
    simulation_time: float
    sim_time: Optional[float] = None
    engine: Optional[str] = "ns3"
    status: str
    created_at: Optional[str] = None
    completed_at: Optional[str] = None
    error_msg: Optional[str] = None

    @model_validator(mode="after")
    def populate_sim_time(self):
        if self.sim_time is None:
            self.sim_time = self.simulation_time
        return self

    model_config = {"from_attributes": True}


class SimulationResultResponse(BaseModel):
    id: int
    experiment_id: int
    avg_latency_ms: Optional[float] = None
    throughput_mbps: Optional[float] = None
    packet_delivery_ratio: Optional[float] = None
    packet_loss: Optional[float] = None
    deadline_misses: Optional[int] = None
    fairness_index: Optional[float] = None
    simulation_duration_s: Optional[float] = None
    raw_json: Optional[str] = None
    created_at: Optional[str] = None
    per_device_stats: List[Dict[str, Any]] = []
    time_series: List[Dict[str, Any]] = []

    # Phase 3.5 & 4.0 Standard Metrics
    goodput_semantic_mbps: Optional[float] = None
    scheduling_coverage: Optional[float] = None
    scheduling_coverage_pct: Optional[float] = None
    expected_received_pdr: Optional[float] = None
    expected_received_pdr_pct: Optional[float] = None
    realized_received_pdr: Optional[float] = None
    realized_received_pdr_pct: Optional[float] = None
    relative_semantic_goodput_vs_basil_opt_pct: Optional[float] = None
    scheduling_deadline_misses: Optional[int] = None
    end_to_end_deadline_failures: Optional[int] = None
    optical_channel_losses: Optional[float] = None
    scheduled_packets_count: Optional[int] = None
    delivered_on_time: Optional[int] = None
    delivered_late: Optional[int] = None
    lost_channel: Optional[int] = None
    dropped_queue: Optional[int] = None
    pending_queue: Optional[int] = None
    total_packets_generated: Optional[int] = None
    is_optimal: Optional[bool] = None
    status: Optional[str] = None
    mip_gap: Optional[float] = None
    solver: Optional[str] = None
    execution_time_s: Optional[float] = None
    ap_power_unit: Optional[str] = "mW"
    ap_power_mw: Optional[float] = None
    p95_latency_ms: Optional[float] = None

    model_config = {"from_attributes": True}
