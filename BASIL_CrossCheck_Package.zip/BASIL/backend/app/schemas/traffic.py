from typing import Optional
from pydantic import BaseModel


class TrafficConfigCreate(BaseModel):
    name: str
    traffic_mode: str
    normal_rate: float
    burst_rate: float
    burst_ratio: float
    packet_size: int


class TrafficConfigResponse(BaseModel):
    id: int
    name: str
    traffic_mode: str
    normal_rate: float
    burst_rate: float
    burst_ratio: float
    packet_size: int
    created_at: Optional[str] = None

    model_config = {"from_attributes": True}
