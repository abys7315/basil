import logging
from typing import Any, Dict

logger = logging.getLogger(__name__)

REQUIRED_KEYS = [
    "avg_latency_ms",
    "throughput_mbps",
    "packet_delivery_ratio",
    "packet_loss",
    "deadline_misses",
    "fairness_index",
]

OPTIONAL_DEFAULTS: Dict[str, Any] = {
    "per_device_stats": [],
    "time_series": [],
    "simulation_duration_s": 0.0,
}


class ResultsParser:
    """Validates simulation JSON output and fills defaults for missing optional keys."""

    def parse(self, raw: Dict[str, Any]) -> Dict[str, Any]:
        # Map alternative simulator output keys if present
        if "pdr" in raw and "packet_delivery_ratio" not in raw:
            raw["packet_delivery_ratio"] = raw["pdr"]
        if "packet_loss" not in raw and "pdr" in raw and raw["pdr"] is not None:
            raw["packet_loss"] = 1.0 - float(raw["pdr"])
        if "total_deadline_misses" in raw and "deadline_misses" not in raw:
            raw["deadline_misses"] = raw["total_deadline_misses"]
        if "jain_fairness_index" in raw and "fairness_index" not in raw:
            raw["fairness_index"] = raw["jain_fairness_index"]

        missing = [k for k in REQUIRED_KEYS if k not in raw]
        if missing:
            logger.warning("Simulation output missing required keys: %s", missing)
            # Fill with None so the caller can still store the result
            for k in missing:
                raw[k] = None

        for key, default in OPTIONAL_DEFAULTS.items():
            if key not in raw:
                raw[key] = default

        # Coerce types where possible
        try:
            if raw.get("avg_latency_ms") is not None:
                raw["avg_latency_ms"] = float(raw["avg_latency_ms"])
            if raw.get("throughput_mbps") is not None:
                raw["throughput_mbps"] = float(raw["throughput_mbps"])
            if raw.get("packet_delivery_ratio") is not None:
                raw["packet_delivery_ratio"] = float(raw["packet_delivery_ratio"])
            if raw.get("packet_loss") is not None:
                raw["packet_loss"] = float(raw["packet_loss"])
            if raw.get("deadline_misses") is not None:
                raw["deadline_misses"] = int(raw["deadline_misses"])
            if raw.get("fairness_index") is not None:
                raw["fairness_index"] = float(raw["fairness_index"])
            if raw.get("simulation_duration_s") is not None:
                raw["simulation_duration_s"] = float(raw["simulation_duration_s"])
        except (TypeError, ValueError) as exc:
            logger.error("Type coercion error in simulation results: %s", exc)

        return raw
