import asyncio
import json
import os
import tempfile
import logging
import time
from pathlib import Path

logger = logging.getLogger(__name__)


class SimulationRunner:
    def __init__(self):
        # Path to the custom MinGW executable (prototype)
        self.project_root = Path(__file__).resolve().parent.parent.parent.parent
        self.sim_exe_win = self.project_root / "ns3-lifi" / "scratch" / "basil-sim.exe"
        if not self.sim_exe_win.exists():
            for alt in [
                Path(__file__).resolve().parent.parent.parent / "ns3-lifi" / "scratch" / "basil-sim.exe",
                Path(__file__).resolve().parent.parent.parent / "resources" / "ns3-lifi" / "scratch" / "basil-sim.exe",
                Path.cwd() / "resources" / "ns3-lifi" / "scratch" / "basil-sim.exe",
                Path.cwd() / "ns3-lifi" / "scratch" / "basil-sim.exe",
            ]:
                if alt.exists():
                    self.sim_exe_win = alt
                    break

        self.sim_exe_wsl = (
            "/mnt/c"
            + str(self.sim_exe_win)
            .replace("\\", "/")
            .replace("C:", "")
        )
        # Path to the actual ns-3.42 Li-Fi simulation binary in WSL Ubuntu
        self.ns3_bin_wsl = "/opt/ns3/ns-allinone-3.42/ns-3.42/build/scratch/ns3.42-basil-ns3-sim"
        self.ns3_lib_dir = "/opt/ns3/ns-allinone-3.42/ns-3.42/build/lib"

    async def run(self, config: dict, engine: str = "ns3") -> dict:
        """Write config to temp file, run chosen simulation engine (ns3 or custom), parse output."""
        if config.get("scheduler") == "BASIL_OPT":
            # Offline Oracle: run ns-3 to extract identical packet arrival trace and physical optical PER
            trace_cfg = dict(config)
            trace_cfg["scheduler"] = "FIFO"
            trace_cfg["export_trace"] = 1.0
            ns3_res = await self.run(trace_cfg, engine="ns3")
            
            trace_packets = ns3_res.get("packet_trace", [])
            dev_stats = ns3_res.get("per_device_stats", [])
            device_per = [d.get("per", 0.0) for d in dev_stats]
            num_devs = int(config.get("num_devices", len(dev_stats) or 4))
            sim_time = float(config.get("simulation_time", 2.0))
            data_rate = float(config.get("data_rate", 10.0))
            pkt_size = int(config.get("packet_size", 1024))
            
            from app.algorithms.basil_opt import BasilOptSolver
            solver = BasilOptSolver(
                time_limit_s=float(config.get("time_limit_s", 30.0)),
                mip_rel_gap=float(config.get("mip_rel_gap", 0.001))
            )
            opt_res = solver.solve_slotted(
                packets=trace_packets,
                num_devices=num_devs,
                simulation_time_s=sim_time,
                data_rate_mbps=data_rate,
                packet_size_bytes=pkt_size,
                device_per=device_per,
                replay_seed=int(config.get("seed", 42)),
            )
            
            # Merge physical optical telemetry from ns-3 (per device SNR, distance, power)
            opt_res["per_device_stats"] = dev_stats
            opt_res["per_class_stats"] = ns3_res.get("per_class_stats", [])
            opt_res["time_series"] = ns3_res.get("time_series", [])
            opt_res["coverage_mode"] = config.get("coverage_mode", "radial")
            return opt_res

        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            json.dump(config, f)
            config_path = f.name
        try:
            wsl_config_path = "/mnt/c" + config_path.replace("\\", "/").replace("C:", "")
            
            if engine == "ns3":
                # Run actual ns-3 simulation inside WSL Ubuntu
                cmd = [
                    "wsl",
                    "-d",
                    "Ubuntu",
                    "--",
                    "bash",
                    "-c",
                    f"LD_LIBRARY_PATH={self.ns3_lib_dir} {self.ns3_bin_wsl} {wsl_config_path}",
                ]
                use_wsl = True
                exec_name = self.ns3_bin_wsl
            else:
                # Custom standalone C++ prototype (MinGW on Windows or fallback to WSL)
                if self.sim_exe_win.exists():
                    cmd = [str(self.sim_exe_win), config_path]
                    use_wsl = False
                    exec_name = str(self.sim_exe_win)
                else:
                    cmd = [
                        "wsl",
                        "-d",
                        "Ubuntu",
                        "--",
                        "bash",
                        "-c",
                        f"{self.sim_exe_wsl} {wsl_config_path}",
                    ]
                    use_wsl = True
                    exec_name = self.sim_exe_wsl

            logger.info(
                "Starting simulation: engine=%s exe=%s wsl=%s",
                engine,
                exec_name,
                use_wsl,
            )

            start = time.time()
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=300)
            elapsed = time.time() - start

            if proc.returncode != 0:
                raise RuntimeError(
                    f"Simulation failed (rc={proc.returncode}): {stderr.decode()[:500]}"
                )

            result = json.loads(stdout.decode())
            result["simulation_duration_s"] = elapsed
            return result
        finally:
            try:
                os.unlink(config_path)
            except OSError:
                pass
