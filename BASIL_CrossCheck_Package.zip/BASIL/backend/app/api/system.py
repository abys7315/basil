from fastapi import APIRouter
from app.services.dependency_checker import run_all_dependency_checks

router = APIRouter(prefix="/system", tags=["system"])


@router.get("/dependencies")
async def get_system_dependencies():
    """Returns diagnostic report of all host and simulation dependencies."""
    return run_all_dependency_checks()
