import io
import json
from typing import List

import pandas as pd
from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import StreamingResponse
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.schemas.experiment import SimulationResultResponse
from app.services import experiment_service as svc

router = APIRouter(prefix="/results", tags=["results"])


def _build_result_response(result_obj) -> SimulationResultResponse:
    per_device: list = []
    time_series: list = []
    raw: dict = {}
    if result_obj.raw_json:
        try:
            raw = json.loads(result_obj.raw_json)
            per_device = raw.get("per_device_stats", [])
            time_series = raw.get("time_series", [])
        except (json.JSONDecodeError, TypeError):
            pass

    # Extract Phase 3.5 & 4.0 standard metrics
    goodput_sem = raw.get("goodput_semantic_mbps")
    sched_cov = raw.get("scheduling_coverage", raw.get("scheduled_pdr"))
    sched_cov_pct = raw.get("scheduling_coverage_pct", sched_cov * 100.0 if sched_cov is not None else None)
    exp_pdr = raw.get("expected_received_pdr", raw.get("expected_pdr"))
    exp_pdr_pct = raw.get("expected_received_pdr_pct", exp_pdr * 100.0 if exp_pdr is not None else None)
    real_pdr = raw.get("realized_received_pdr", raw.get("pdr", result_obj.packet_delivery_ratio))
    real_pdr_pct = raw.get("realized_received_pdr_pct", real_pdr * 100.0 if real_pdr is not None else None)
    rel_goodput = raw.get("relative_semantic_goodput_vs_basil_opt_pct", raw.get("ratio_to_optimal_pct"))

    sched_misses = raw.get("scheduling_deadline_misses", result_obj.deadline_misses)
    e2e_failures = raw.get("end_to_end_deadline_failures", result_obj.deadline_misses)
    opt_losses = raw.get("optical_channel_losses", raw.get("lost_channel"))

    sched_pkts = raw.get("scheduled_packets_count")
    del_on_time = raw.get("delivered_on_time")
    del_late = raw.get("delivered_late")
    lost_ch = raw.get("lost_channel")
    drop_q = raw.get("dropped_queue")
    pend_q = raw.get("pending_queue")
    tot_gen = raw.get("total_packets_generated")

    is_opt = raw.get("is_optimal")
    status_str = raw.get("status")
    mip_gap = raw.get("mip_gap")
    solver_str = raw.get("solver")
    exec_time = raw.get("execution_time_s")
    ap_unit = raw.get("ap_power_unit", "mW")
    ap_mw = raw.get("ap_power_mw")
    p95_lat = raw.get("p95_latency_ms")

    return SimulationResultResponse(
        id=result_obj.id,
        experiment_id=result_obj.experiment_id,
        avg_latency_ms=result_obj.avg_latency_ms,
        throughput_mbps=result_obj.throughput_mbps,
        packet_delivery_ratio=result_obj.packet_delivery_ratio,
        packet_loss=result_obj.packet_loss,
        deadline_misses=result_obj.deadline_misses,
        fairness_index=result_obj.fairness_index,
        simulation_duration_s=result_obj.simulation_duration_s,
        raw_json=result_obj.raw_json,
        created_at=result_obj.created_at,
        per_device_stats=per_device,
        time_series=time_series,
        goodput_semantic_mbps=goodput_sem,
        scheduling_coverage=sched_cov,
        scheduling_coverage_pct=sched_cov_pct,
        expected_received_pdr=exp_pdr,
        expected_received_pdr_pct=exp_pdr_pct,
        realized_received_pdr=real_pdr,
        realized_received_pdr_pct=real_pdr_pct,
        relative_semantic_goodput_vs_basil_opt_pct=rel_goodput,
        scheduling_deadline_misses=sched_misses,
        end_to_end_deadline_failures=e2e_failures,
        optical_channel_losses=opt_losses,
        scheduled_packets_count=sched_pkts,
        delivered_on_time=del_on_time,
        delivered_late=del_late,
        lost_channel=lost_ch,
        dropped_queue=drop_q,
        pending_queue=pend_q,
        total_packets_generated=tot_gen,
        is_optimal=is_opt,
        status=status_str,
        mip_gap=mip_gap,
        solver=solver_str,
        execution_time_s=exec_time,
        ap_power_unit=ap_unit,
        ap_power_mw=ap_mw,
        p95_latency_ms=p95_lat,
    )


@router.get("/compare", response_model=List[SimulationResultResponse])
async def compare_results(
    ids: str = Query(..., description="Comma-separated experiment IDs, e.g. 1,2,3"),
    db: AsyncSession = Depends(get_db),
):
    """Return results for multiple experiments for side-by-side comparison."""
    try:
        id_list = [int(i.strip()) for i in ids.split(",") if i.strip()]
    except ValueError:
        raise HTTPException(status_code=422, detail="ids must be comma-separated integers")
    results = await svc.compare_results(db, id_list)
    return [_build_result_response(r) for r in results]


@router.get("/{experiment_id}", response_model=SimulationResultResponse)
async def get_result(experiment_id: int, db: AsyncSession = Depends(get_db)):
    """Return simulation result for a single experiment."""
    result_obj = await svc.get_result(db, experiment_id)
    if result_obj is None:
        raise HTTPException(status_code=404, detail="Result not found for this experiment")
    return _build_result_response(result_obj)


@router.get("/{experiment_id}/export/json")
async def export_result_json(experiment_id: int, db: AsyncSession = Depends(get_db)):
    """Export simulation result as JSON."""
    result_obj = await svc.get_result(db, experiment_id)
    if result_obj is None:
        raise HTTPException(status_code=404, detail="Result not found for this experiment")
    
    resp = _build_result_response(result_obj)
    json_bytes = json.dumps(resp.model_dump(), indent=2).encode("utf-8")
    return StreamingResponse(
        io.BytesIO(json_bytes),
        media_type="application/json",
        headers={
            "Content-Disposition": f"attachment; filename=experiment_{experiment_id}.json"
        },
    )


@router.get("/{experiment_id}/export")
@router.get("/{experiment_id}/export/csv")
async def export_result_csv(
    experiment_id: int,
    format: str = Query("csv", description="Export format: 'csv' or 'json'"),
    db: AsyncSession = Depends(get_db)
):
    """Export simulation result as CSV or JSON."""
    if format.lower() == "json":
        return await export_result_json(experiment_id, db)

    result_obj = await svc.get_result(db, experiment_id)
    if result_obj is None:
        raise HTTPException(status_code=404, detail="Result not found for this experiment")

    resp = _build_result_response(result_obj)

    summary_data = {
        "Experiment ID": [resp.experiment_id],
        "Scheduling Coverage (%)": [resp.scheduling_coverage_pct],
        "Realized Received PDR (%)": [resp.realized_received_pdr_pct],
        "Expected Received PDR (%)": [resp.expected_received_pdr_pct],
        "Realized Goodput Efficiency (%)": [resp.relative_semantic_goodput_vs_basil_opt_pct],
        "Scheduling Deadline Misses": [resp.scheduling_deadline_misses],
        "End-to-End Deadline Failures": [resp.end_to_end_deadline_failures],
        "Optical Channel Losses": [resp.optical_channel_losses],
        "Throughput (Mbps)": [resp.throughput_mbps],
        "Semantic Goodput (Mbps)": [resp.goodput_semantic_mbps],
        "Average Latency (ms)": [resp.avg_latency_ms],
        "P95 Latency (ms)": [resp.p95_latency_ms],
        "Fairness Index": [resp.fairness_index],
        "Scheduled Packets Count": [resp.scheduled_packets_count],
        "Delivered On Time": [resp.delivered_on_time],
        "Lost Channel": [resp.lost_channel],
        "Total Packets Generated": [resp.total_packets_generated],
        "Simulation Duration (s)": [resp.simulation_duration_s],
        "AP Power Unit": [resp.ap_power_unit],
        "AP Power (mW)": [resp.ap_power_mw],
        "Created At": [resp.created_at],
        # Backward-compatibility snake_case keys
        "experiment_id": [resp.experiment_id],
        "goodput_semantic_mbps": [resp.goodput_semantic_mbps],
        "throughput_mbps": [resp.throughput_mbps],
        "scheduling_coverage_pct": [resp.scheduling_coverage_pct],
        "expected_received_pdr_pct": [resp.expected_received_pdr_pct],
        "realized_received_pdr_pct": [resp.realized_received_pdr_pct],
        "packet_delivery_ratio": [resp.packet_delivery_ratio],
        "packet_loss": [resp.packet_loss],
        "scheduling_deadline_misses": [resp.scheduling_deadline_misses],
        "end_to_end_deadline_failures": [resp.end_to_end_deadline_failures],
        "optical_channel_losses": [resp.optical_channel_losses],
        "avg_latency_ms": [resp.avg_latency_ms],
    }
    df = pd.DataFrame(summary_data)

    # Append per-device stats if present
    if resp.per_device_stats:
        df_devices = pd.DataFrame(resp.per_device_stats)
        buf = io.StringIO()
        df.to_csv(buf, index=False)
        buf.write("\nPer-Device Stats\n")
        df_devices.to_csv(buf, index=False)
        buf.seek(0)
        return StreamingResponse(
            iter([buf.read()]),
            media_type="text/csv",
            headers={
                "Content-Disposition": f"attachment; filename=experiment_{experiment_id}.csv"
            },
        )

    buf = io.StringIO()
    df.to_csv(buf, index=False)
    buf.seek(0)
    return StreamingResponse(
        iter([buf.read()]),
        media_type="text/csv",
        headers={
            "Content-Disposition": f"attachment; filename=experiment_{experiment_id}.csv"
        },
    )
