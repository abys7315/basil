from typing import List

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.schemas.traffic import TrafficConfigCreate, TrafficConfigResponse
from app.services import experiment_service as svc

router = APIRouter(prefix="/traffic-configs", tags=["traffic-configs"])


@router.get("", response_model=List[TrafficConfigResponse])
async def list_traffic_configs(db: AsyncSession = Depends(get_db)):
    return await svc.list_traffic_configs(db)


@router.post("", response_model=TrafficConfigResponse, status_code=201)
async def create_traffic_config(data: TrafficConfigCreate, db: AsyncSession = Depends(get_db)):
    return await svc.create_traffic_config(db, data)


@router.get("/{config_id}", response_model=TrafficConfigResponse)
async def get_traffic_config(config_id: int, db: AsyncSession = Depends(get_db)):
    obj = await svc.get_traffic_config(db, config_id)
    if obj is None:
        raise HTTPException(status_code=404, detail="Traffic config not found")
    return obj


@router.delete("/{config_id}", status_code=204)
async def delete_traffic_config(config_id: int, db: AsyncSession = Depends(get_db)):
    deleted = await svc.delete_traffic_config(db, config_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Traffic config not found")
