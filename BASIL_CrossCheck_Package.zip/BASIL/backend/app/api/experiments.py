from typing import List

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.schemas.experiment import ExperimentCreate, ExperimentResponse
from app.services import experiment_service as svc

router = APIRouter(prefix="/experiments", tags=["experiments"])


@router.get("", response_model=List[ExperimentResponse])
async def list_experiments(db: AsyncSession = Depends(get_db)):
    return await svc.list_experiments(db)


@router.post("", response_model=ExperimentResponse, status_code=201)
async def create_experiment(data: ExperimentCreate, db: AsyncSession = Depends(get_db)):
    return await svc.create_experiment(db, data)


@router.get("/{experiment_id}", response_model=ExperimentResponse)
async def get_experiment(experiment_id: int, db: AsyncSession = Depends(get_db)):
    obj = await svc.get_experiment(db, experiment_id)
    if obj is None:
        raise HTTPException(status_code=404, detail="Experiment not found")
    return obj


@router.delete("/{experiment_id}", status_code=204)
async def delete_experiment(experiment_id: int, db: AsyncSession = Depends(get_db)):
    deleted = await svc.delete_experiment(db, experiment_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Experiment not found")
