from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.schemas.experiment import ExperimentResponse, SimulationResultResponse
from app.services import experiment_service as svc
from app.simulation.parser import ResultsParser

import json

router = APIRouter(prefix="/simulate", tags=["simulate"])
_parser = ResultsParser()


def _build_result_response(result_obj) -> SimulationResultResponse:
    per_device = []
    time_series = []
    if result_obj.raw_json:
        try:
            raw = json.loads(result_obj.raw_json)
            per_device = raw.get("per_device_stats", [])
            time_series = raw.get("time_series", [])
        except (json.JSONDecodeError, TypeError):
            pass
    return SimulationResultResponse(
        id=result_obj.id,
        experiment_id=result_obj.experiment_id,
        avg_latency_ms=result_obj.avg_latency_ms,
        throughput_mbps=result_obj.throughput_mbps,
        packet_delivery_ratio=result_obj.packet_delivery_ratio,
        packet_loss=result_obj.packet_loss,
        deadline_misses=result_obj.deadline_misses,
        fairness_index=result_obj.fairness_index,
        simulation_duration_s=result_obj.simulation_duration_s,
        raw_json=result_obj.raw_json,
        created_at=result_obj.created_at,
        per_device_stats=per_device,
        time_series=time_series,
    )


@router.post("/{experiment_id}", response_model=SimulationResultResponse)
async def run_simulation(experiment_id: int, db: AsyncSession = Depends(get_db)):
    """Run simulation for an experiment; returns the result."""
    try:
        result_obj = await svc.run_experiment(db, experiment_id)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    except RuntimeError as exc:
        raise HTTPException(status_code=500, detail=str(exc))
    return _build_result_response(result_obj)


@router.get("/{experiment_id}/status", response_model=ExperimentResponse)
async def get_simulation_status(experiment_id: int, db: AsyncSession = Depends(get_db)):
    """Return the current status of an experiment."""
    obj = await svc.get_experiment(db, experiment_id)
    if obj is None:
        raise HTTPException(status_code=404, detail="Experiment not found")
    return obj
