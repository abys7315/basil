from typing import List, Any, Dict

from fastapi import APIRouter

from app.algorithms.registry import ALGORITHMS

router = APIRouter(prefix="/algorithms", tags=["algorithms"])


@router.get("", response_model=List[Dict[str, Any]])
async def list_algorithms():
    """Return all available scheduling algorithms with their parameters."""
    return [
        {"id": key, **value}
        for key, value in ALGORITHMS.items()
    ]
