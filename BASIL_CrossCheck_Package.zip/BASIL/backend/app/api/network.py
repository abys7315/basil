from typing import List

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.schemas.network import NetworkConfigCreate, NetworkConfigResponse
from app.services import experiment_service as svc

router = APIRouter(prefix="/network-configs", tags=["network-configs"])


@router.get("", response_model=List[NetworkConfigResponse])
async def list_network_configs(db: AsyncSession = Depends(get_db)):
    return await svc.list_network_configs(db)


@router.post("", response_model=NetworkConfigResponse, status_code=201)
async def create_network_config(data: NetworkConfigCreate, db: AsyncSession = Depends(get_db)):
    return await svc.create_network_config(db, data)


@router.get("/{config_id}", response_model=NetworkConfigResponse)
async def get_network_config(config_id: int, db: AsyncSession = Depends(get_db)):
    obj = await svc.get_network_config(db, config_id)
    if obj is None:
        raise HTTPException(status_code=404, detail="Network config not found")
    return obj


@router.delete("/{config_id}", status_code=204)
async def delete_network_config(config_id: int, db: AsyncSession = Depends(get_db)):
    deleted = await svc.delete_network_config(db, config_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Network config not found")
