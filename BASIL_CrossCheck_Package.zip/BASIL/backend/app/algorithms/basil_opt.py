import time
import math
from typing import Dict, List, Any, Optional, Tuple
import numpy as np

try:
    import highspy
    HAS_HIGHS = True
except ImportError:
    HAS_HIGHS = False

from scipy.optimize import milp, LinearConstraint, Bounds

def packet_channel_draw(seed: int, packet_id: int, device_id: int) -> float:
    """
    Reproducible 64-bit SplitMix64 hash for scheduler-order-invariant channel draws.
    Bit-for-bit identical to C++ lifi::packet_channel_draw(seed, packet_id, device_id).
    """
    MASK = 0xFFFFFFFFFFFFFFFF
    x = (seed ^ ((packet_id * 0x9e3779b97f4a7c15) & MASK) ^ ((device_id * 0xbf58476d1ce4e5b9) & MASK)) & MASK
    x = ((x ^ (x >> 30)) * 0xbf58476d1ce4e5b9) & MASK
    x = ((x ^ (x >> 27)) * 0x94d049bb133111eb) & MASK
    x = (x ^ (x >> 31)) & MASK
    return (x >> 11) * (1.0 / (1 << 53))

class BasilOptSolver:
    """
    BASIL-OPT: Offline Optimization Reference Solver for Li-Fi scheduling.
    Formulated as a Mixed-Integer Linear Program (MILP) solved via HiGHS.
    Maximizes on-time semantic goodput subject to single-channel transmission exclusivity,
    arrival causality, deadline satisfaction, and optical channel reliability.
    """

    def __init__(self, time_limit_s: float = 30.0, mip_rel_gap: float = 0.001):
        self.time_limit_s = time_limit_s
        self.mip_rel_gap = mip_rel_gap

    def solve_slotted(
        self,
        packets: List[Dict[str, Any]],
        num_devices: int,
        simulation_time_s: float,
        data_rate_mbps: float = 10.0,
        packet_size_bytes: int = 1024,
        device_per: Optional[List[float]] = None,
        lambda_fair: float = 0.0,
        max_queue_wait_s: float = 0.100,
        replay_seed: Optional[int] = None,
    ) -> Dict[str, Any]:
        """
        Solve offline packet scheduling via Slotted Maximum-Weight Matching / MILP.
        Guarantees global optimality with polynomial/slotted scaling.
        """
        start_wall_time = time.time()
        
        K = len(packets)
        if K == 0:
            return self._empty_result(num_devices, simulation_time_s)

        # Transmission duration per packet in seconds
        tx_duration_s = (packet_size_bytes * 8.0) / (data_rate_mbps * 1e6)
        M = max(1, int(math.floor(simulation_time_s / tx_duration_s)))

        # Default PER to 0.0 if not provided
        if device_per is None:
            device_per = [0.0] * num_devices
        elif isinstance(device_per, dict):
            device_per = [device_per.get(d, 0.0) for d in range(num_devices)]

        # Device transmission reliability q_d = 1.0 - PER_d
        device_rel = [max(0.0, min(1.0, 1.0 - per)) for per in device_per]

        # Extract packet properties
        arrivals = [p["arrive_time_s"] for p in packets]
        deadlines = [p.get("deadline_s", -1.0) for p in packets]
        weights = [p.get("semantic_importance", 0.50) for p in packets]
        dev_ids = [p.get("device_id", 0) for p in packets]
        pkt_sizes = [p.get("size_bytes", packet_size_bytes) for p in packets]

        # Slot boundaries: slot m spans [m * tx_duration_s, (m+1) * tx_duration_s]
        slot_starts = [m * tx_duration_s for m in range(M)]
        slot_ends = [(m + 1) * tx_duration_s for m in range(M)]

        # Eligible (k, m) pairs: packet k can be scheduled in slot m if:
        # 1. slot_starts[m] >= arrivals[k] (arrived before slot starts)
        # 2. slot_ends[m] <= effective_deadline (completes before deadline or buffer horizon)
        # 3. slot_ends[m] <= simulation_time_s
        eligible_pairs = []
        for k in range(K):
            arr = arrivals[k]
            ddl = deadlines[k]
            eff_ddl = ddl if ddl > 0.0 else min(simulation_time_s, arr + max_queue_wait_s)
            start_m = max(0, int(math.ceil(arr / tx_duration_s - 1e-9)))
            end_m = min(M, int(math.floor(min(eff_ddl, simulation_time_s) / tx_duration_s + 1e-9)))
            for m in range(start_m, end_m):
                eligible_pairs.append((k, m))

        P = len(eligible_pairs)
        if P == 0:
            # No feasible transmissions possible within deadlines
            exec_time = time.time() - start_wall_time
            return {
                "status": "InfeasibleOrEmpty",
                "is_optimal": True,
                "objective_value": 0.0,
                "execution_time_s": exec_time,
                "mip_gap": 0.0,
                "scheduled_packets_count": 0,
                "total_packets_generated": K,
                "delivered_on_time": 0,
                "delivered_late": 0,
                "lost_channel": 0,
                "dropped_queue": 0,
                "pending_queue": K,
                "pdr": 0.0,
                "goodput_semantic_mbps": 0.0,
                "goodput_raw_mbps": 0.0,
                "avg_latency_ms": 0.0,
                "p95_latency_ms": 0.0,
                "total_deadline_misses": sum(1 for d in deadlines if d > 0),
                "jain_fairness_index": 0.0,
                "schedule": [],
            }

        # Solve via highspy if available
        if HAS_HIGHS:
            return self._solve_highspy_slotted(
                packets, K, M, P, eligible_pairs, slot_starts, slot_ends,
                arrivals, deadlines, weights, dev_ids, pkt_sizes, device_rel,
                num_devices, simulation_time_s, tx_duration_s, start_wall_time,
                replay_seed=replay_seed
            )
        else:
            return self._solve_scipy_slotted(
                packets, K, M, P, eligible_pairs, slot_starts, slot_ends,
                arrivals, deadlines, weights, dev_ids, pkt_sizes, device_rel,
                num_devices, simulation_time_s, tx_duration_s, start_wall_time,
                replay_seed=replay_seed
            )

    def _solve_highspy_slotted(
        self, packets, K, M, P, eligible_pairs, slot_starts, slot_ends,
        arrivals, deadlines, weights, dev_ids, pkt_sizes, device_rel,
        num_devices, simulation_time_s, tx_duration_s, start_wall_time,
        replay_seed: Optional[int] = None
    ) -> Dict[str, Any]:
        h = highspy.Highs()
        h.setOptionValue("output_flag", False)
        h.setOptionValue("time_limit", self.time_limit_s)
        h.setOptionValue("mip_rel_gap", self.mip_rel_gap)

        # Variables: x_p in {0, 1} for p in 0..P-1
        col_cost = np.zeros(P)
        col_lower = np.zeros(P)
        col_upper = np.ones(P)
        integrality = [highspy.HighsVarType.kInteger] * P

        epsilon = 1e-6 # small latency penalty to break ties in favor of earlier dispatch
        for p_idx, (k, m) in enumerate(eligible_pairs):
            d = dev_ids[k]
            rel = device_rel[d]
            sem_bits = weights[k] * (pkt_sizes[k] * 8.0) * rel
            latency = slot_ends[m] - arrivals[k]
            # Maximize: negate for minimization in HiGHS
            col_cost[p_idx] = - (sem_bits - epsilon * latency)

        h.addVars(P, col_lower, col_upper)
        col_indices = np.arange(P, dtype=np.int32)
        h.changeColsCost(P, col_indices, col_cost)
        h.changeColsIntegrality(P, col_indices, integrality)

        # Build CSR matrix for batched addRows (Constraints 1 & 2):
        # Row 0..K-1: Packet uniqueness sum_{m} y_{k, m} <= 1
        # Row K..K+M-1: Channel exclusivity sum_{k} y_{k, m} <= 1
        pkt_to_pairs = [[] for _ in range(K)]
        slot_to_pairs = [[] for _ in range(M)]
        for p_idx, (k, m) in enumerate(eligible_pairs):
            pkt_to_pairs[k].append(p_idx)
            slot_to_pairs[m].append(p_idx)

        num_rows = K + M
        row_lower = np.zeros(num_rows, dtype=np.float64)
        row_upper = np.ones(num_rows, dtype=np.float64)
        row_lens = [len(pkt_to_pairs[k]) for k in range(K)] + [len(slot_to_pairs[m]) for m in range(M)]
        num_nz = sum(row_lens)

        a_start = np.zeros(num_rows + 1, dtype=np.int32)
        a_start[1:] = np.cumsum(row_lens, dtype=np.int32)
        a_index = np.empty(num_nz, dtype=np.int32)
        curr = 0
        for k in range(K):
            l = len(pkt_to_pairs[k])
            if l > 0:
                a_index[curr:curr + l] = pkt_to_pairs[k]
                curr += l
        for m in range(M):
            l = len(slot_to_pairs[m])
            if l > 0:
                a_index[curr:curr + l] = slot_to_pairs[m]
                curr += l
        a_value = np.ones(num_nz, dtype=np.float64)

        h.addRows(num_rows, row_lower, row_upper, num_nz, a_start, a_index, a_value)

        h.run()
        exec_time = time.time() - start_wall_time
        status = h.getModelStatus()
        status_str = h.modelStatusToString(status)
        info = h.getInfo()
        sol = h.getSolution()

        is_optimal = (status == highspy.HighsModelStatus.kOptimal)
        mip_gap = getattr(info, "mip_gap", 0.0)

        # Reconstruct schedule
        scheduled_packets = []
        scheduled_indices = set()
        delivered_latencies_ms = []
        dev_delivered_bits = [0.0] * num_devices
        dev_delivered_count = [0] * num_devices
        class_stats = {c: {"delivered_on_time": 0, "missed": 0, "latencies": []} for c in range(4)}

        for p_idx, (k, m) in enumerate(eligible_pairs):
            if sol.col_value[p_idx] > 0.5:
                scheduled_indices.add(k)
                d = dev_ids[k]
                cls = packets[k].get("priority", 0)
                lat_ms = (slot_ends[m] - arrivals[k]) * 1000.0
                delivered_latencies_ms.append(lat_ms)
                dev_delivered_count[d] += 1
                dev_delivered_bits[d] += pkt_sizes[k] * 8.0 * device_rel[d]
                if cls in class_stats:
                    class_stats[cls]["delivered_on_time"] += 1
                    class_stats[cls]["latencies"].append(lat_ms)

                scheduled_packets.append({
                    "packet_id": packets[k].get("id", k + 1),
                    "device_id": d,
                    "slot_index": m,
                    "scheduled_start_s": slot_starts[m],
                    "scheduled_end_s": slot_ends[m],
                    "latency_ms": lat_ms,
                    "semantic_importance": weights[k],
                    "priority": cls,
                    "size_bytes": pkt_sizes[k],
                })

        # Sort schedule by start time
        scheduled_packets.sort(key=lambda x: x["scheduled_start_s"])

        # Compute summary metrics
        N_del_on_time = len(scheduled_packets)
        N_gen = K
        K_with_deadline = sum(1 for ddl in deadlines if ddl > 0.0)

        # Three Separate Parity Metrics
        # 1. Scheduling Deadline Misses: deadline packets not scheduled on time
        scheduling_deadline_misses = sum(1 for k in range(K) if deadlines[k] > 0.0 and k not in scheduled_indices)
        
        # 2. Expected End-to-End Deadline Failures:
        # unscheduled deadline packets (1.0) + expected channel losses of scheduled deadline packets (1 - rel)
        expected_e2e_deadline_failures = float(
            sum(1.0 for k in range(K) if deadlines[k] > 0.0 and k not in scheduled_indices) +
            sum((1.0 - device_rel[dev_ids[k]]) for k in scheduled_indices if deadlines[k] > 0.0)
        )

        # 3. Expected Optical Channel Losses: sum of (1 - rel) for all scheduled packets
        expected_channel_losses = float(sum((1.0 - device_rel[dev_ids[k]]) for k in scheduled_indices))

        # Channel-discounted expected delivery metrics
        expected_del_pkts = float(sum(device_rel[dev_ids[k]] for k in scheduled_indices))
        expected_pdr = (expected_del_pkts / N_gen) if N_gen > 0 else 0.0

        # Optional Stochastic Monte Carlo Replay using reproducible seed & keyed hash
        realized_delivered_on_time = 0
        realized_lost_channel = 0
        realized_lost_channel_deadline = 0
        realized_delivered_bits = 0.0
        realized_sem_bits = 0.0
        has_replay = (replay_seed is not None)

        if has_replay:
            for p in scheduled_packets:
                dev = p["device_id"]
                per_val = 1.0 - device_rel[dev]
                pid = p.get("packet_id", p.get("id", 0))
                draw = packet_channel_draw(replay_seed, pid, dev)
                success = bool(draw >= per_val)
                if success:
                    realized_delivered_on_time += 1
                    realized_delivered_bits += p["size_bytes"] * 8.0
                    realized_sem_bits += p["size_bytes"] * 8.0 * p["semantic_importance"]
                else:
                    realized_lost_channel += 1
                    if p.get("priority", 0) > 0:
                        realized_lost_channel_deadline += 1

            realized_e2e_deadline_failures = scheduling_deadline_misses + realized_lost_channel_deadline
            realized_pdr = (realized_delivered_on_time / N_gen) if N_gen > 0 else 0.0
            realized_sem_goodput_mbps = (realized_sem_bits / (simulation_time_s * 1e6))
            realized_raw_goodput_mbps = (realized_delivered_bits / (simulation_time_s * 1e6))
        
        sem_goodput_mbps = sum(
            p["semantic_importance"] * (p["size_bytes"] * 8.0) * device_rel[p["device_id"]]
            for p in scheduled_packets
        ) / (simulation_time_s * 1e6)

        raw_goodput_mbps = sum(
            (p["size_bytes"] * 8.0) * device_rel[p["device_id"]]
            for p in scheduled_packets
        ) / (simulation_time_s * 1e6)

        avg_lat_ms = float(np.mean(delivered_latencies_ms)) if delivered_latencies_ms else 0.0
        p95_lat_ms = float(np.percentile(delivered_latencies_ms, 95)) if delivered_latencies_ms else 0.0

        # Jain's fairness index across all devices
        dev_throughputs = [
            (dev_delivered_bits[d] / (simulation_time_s * 1e6)) for d in range(num_devices)
        ]
        sum_th = sum(dev_throughputs)
        sum_sq = sum(t * t for t in dev_throughputs)
        jain_index = (sum_th * sum_th) / (num_devices * sum_sq) if sum_sq > 0 else 0.0

        pdr = N_del_on_time / N_gen if N_gen > 0 else 0.0

        res_dict = {
            "engine": "opt_oracle",
            "scheduler": "BASIL_OPT",
            "solver": "HiGHS-1.16.0",
            "status": status_str,
            "is_optimal": is_optimal,
            "objective_value": float(-info.objective_function_value) if hasattr(info, "objective_function_value") else sem_goodput_mbps,
            "execution_time_s": exec_time,
            "mip_gap": float(mip_gap),
            "total_packets_generated": N_gen,
            "total_packets_sent": N_gen,

            # Three Separate Parity Metrics:
            "scheduling_deadline_misses": scheduling_deadline_misses,
            "end_to_end_deadline_failures": expected_e2e_deadline_failures,
            "expected_end_to_end_deadline_failures": expected_e2e_deadline_failures,
            "optical_channel_losses": expected_channel_losses,
            "expected_optical_channel_losses": expected_channel_losses,
            "expected_channel_losses": expected_channel_losses,

            # Success rates:
            "scheduling_success_rate": ((K_with_deadline - scheduling_deadline_misses) / K_with_deadline) if K_with_deadline > 0 else 1.0,
            "expected_end_to_end_success_rate": ((K_with_deadline - expected_e2e_deadline_failures) / K_with_deadline) if K_with_deadline > 0 else 1.0,
            "deadline_success_rate": ((K_with_deadline - scheduling_deadline_misses) / K_with_deadline) if K_with_deadline > 0 else 1.0,
            "total_deadline_misses": scheduling_deadline_misses,
            "deadline_misses": scheduling_deadline_misses,

            # Precise Packet Accounting and Canonical Terminology:
            "scheduled_packets_count": N_del_on_time,
            "scheduling_coverage": pdr,
            "scheduling_coverage_pct": pdr * 100.0,
            "scheduled_pdr": pdr,
            "total_packets_delivered": N_del_on_time,
            "delivered_on_time": N_del_on_time,
            "delivered_late": 0,
            "lost_channel": 0,
            "dropped_queue": 0,
            "pending_queue": N_gen - N_del_on_time,
            "pdr": pdr,
            "packet_delivery_ratio": pdr,
            "expected_delivered_packets": expected_del_pkts,
            "expected_delivered_on_time": expected_del_pkts,
            "expected_pdr": expected_pdr,
            "expected_received_pdr": expected_pdr,
            "expected_received_pdr_pct": expected_pdr * 100.0,
            "ap_power_unit": "mW",

            # Goodput and Latency:
            "goodput_semantic_mbps": sem_goodput_mbps,
            "goodput_raw_mbps": raw_goodput_mbps,
            "throughput_mbps": raw_goodput_mbps,
            "avg_latency_ms": avg_lat_ms,
            "p95_latency_ms": p95_lat_ms,
            "jain_fairness_index": jain_index,
            "per_device_throughputs_mbps": dev_throughputs,
            "schedule": scheduled_packets,
        }

        if has_replay:
            res_dict.update({
                "realized_delivered_on_time": realized_delivered_on_time,
                "realized_lost_channel": realized_lost_channel,
                "realized_end_to_end_deadline_failures": realized_e2e_deadline_failures,
                "realized_pdr": realized_pdr,
                "realized_received_pdr": realized_pdr,
                "realized_received_pdr_pct": realized_pdr * 100.0,
                "pdr": realized_pdr,
                "packet_delivery_ratio": realized_pdr,
                "realized_goodput_semantic_mbps": realized_sem_goodput_mbps,
                "realized_throughput_mbps": realized_raw_goodput_mbps,
            })

        return res_dict

    def _solve_scipy_slotted(
        self, packets, K, M, P, eligible_pairs, slot_starts, slot_ends,
        arrivals, deadlines, weights, dev_ids, pkt_sizes, device_rel,
        num_devices, simulation_time_s, tx_duration_s, start_wall_time,
        replay_seed: Optional[int] = None
    ) -> Dict[str, Any]:
        """Fallback solver using scipy.optimize.milp (HiGHS wrapper)."""
        c = np.zeros(P)
        epsilon = 1e-6
        for p_idx, (k, m) in enumerate(eligible_pairs):
            d = dev_ids[k]
            rel = device_rel[d]
            sem_bits = weights[k] * (pkt_sizes[k] * 8.0) * rel
            latency = slot_ends[m] - arrivals[k]
            c[p_idx] = - (sem_bits - epsilon * latency)

        integrality = np.ones(P, dtype=int)
        bounds = Bounds(np.zeros(P), np.ones(P))

        # Constraints matrix:
        # 1. Packet uniqueness (K rows): sum_m y_{k, m} <= 1
        # 2. Slot exclusivity (M rows): sum_k y_{k, m} <= 1
        num_rows = K + M
        A = np.zeros((num_rows, P))
        for p_idx, (k, m) in enumerate(eligible_pairs):
            A[k, p_idx] = 1.0
            A[K + m, p_idx] = 1.0

        b_u = np.ones(num_rows)
        b_l = np.zeros(num_rows)
        constraints = LinearConstraint(A, b_l, b_u)

        res = milp(c=c, integrality=integrality, constraints=constraints, bounds=bounds)
        exec_time = time.time() - start_wall_time

        is_optimal = (res.status == 0)
        sol_x = res.x if res.success else np.zeros(P)

        scheduled_packets = []
        scheduled_indices = set()
        delivered_latencies_ms = []
        dev_delivered_bits = [0.0] * num_devices

        for p_idx, (k, m) in enumerate(eligible_pairs):
            if sol_x[p_idx] > 0.5:
                scheduled_indices.add(k)
                d = dev_ids[k]
                cls = packets[k].get("priority", 0)
                lat_ms = (slot_ends[m] - arrivals[k]) * 1000.0
                delivered_latencies_ms.append(lat_ms)
                dev_delivered_bits[d] += pkt_sizes[k] * 8.0 * device_rel[d]
                scheduled_packets.append({
                    "packet_id": packets[k].get("id", k + 1),
                    "device_id": d,
                    "slot_index": m,
                    "scheduled_start_s": slot_starts[m],
                    "scheduled_end_s": slot_ends[m],
                    "latency_ms": lat_ms,
                    "semantic_importance": weights[k],
                    "priority": cls,
                    "size_bytes": pkt_sizes[k],
                })

        scheduled_packets.sort(key=lambda x: x["scheduled_start_s"])
        N_del = len(scheduled_packets)
        K_with_deadline = sum(1 for ddl in deadlines if ddl > 0.0)

        # Three Separate Parity Metrics
        scheduling_deadline_misses = sum(1 for k in range(K) if deadlines[k] > 0.0 and k not in scheduled_indices)
        expected_e2e_deadline_failures = float(
            sum(1.0 for k in range(K) if deadlines[k] > 0.0 and k not in scheduled_indices) +
            sum((1.0 - device_rel[dev_ids[k]]) for k in scheduled_indices if deadlines[k] > 0.0)
        )
        expected_channel_losses = float(sum((1.0 - device_rel[dev_ids[k]]) for k in scheduled_indices))

        expected_del_pkts = float(sum(device_rel[dev_ids[k]] for k in scheduled_indices))
        expected_pdr = (expected_del_pkts / K) if K > 0 else 0.0

        # Optional Stochastic Monte Carlo Replay using reproducible seed & keyed hash
        realized_delivered_on_time = 0
        realized_lost_channel = 0
        realized_lost_channel_deadline = 0
        realized_delivered_bits = 0.0
        realized_sem_bits = 0.0
        has_replay = (replay_seed is not None)

        if has_replay:
            for p in scheduled_packets:
                dev = p["device_id"]
                per_val = 1.0 - device_rel[dev]
                pid = p.get("packet_id", p.get("id", 0))
                draw = packet_channel_draw(replay_seed, pid, dev)
                success = bool(draw >= per_val)
                if success:
                    realized_delivered_on_time += 1
                    realized_delivered_bits += p["size_bytes"] * 8.0
                    realized_sem_bits += p["size_bytes"] * 8.0 * p["semantic_importance"]
                else:
                    realized_lost_channel += 1
                    if p.get("priority", 0) > 0:
                        realized_lost_channel_deadline += 1

            realized_e2e_deadline_failures = scheduling_deadline_misses + realized_lost_channel_deadline
            realized_pdr = (realized_delivered_on_time / K) if K > 0 else 0.0
            realized_sem_goodput_mbps = (realized_sem_bits / (simulation_time_s * 1e6))
            realized_raw_goodput_mbps = (realized_delivered_bits / (simulation_time_s * 1e6))

        sem_goodput_mbps = sum(
            p["semantic_importance"] * (p["size_bytes"] * 8.0) * device_rel[p["device_id"]]
            for p in scheduled_packets
        ) / (simulation_time_s * 1e6)

        raw_goodput_mbps = sum(
            (p["size_bytes"] * 8.0) * device_rel[p["device_id"]]
            for p in scheduled_packets
        ) / (simulation_time_s * 1e6)

        avg_lat_ms = float(np.mean(delivered_latencies_ms)) if delivered_latencies_ms else 0.0
        p95_lat_ms = float(np.percentile(delivered_latencies_ms, 95)) if delivered_latencies_ms else 0.0

        dev_throughputs = [
            (dev_delivered_bits[d] / (simulation_time_s * 1e6)) for d in range(num_devices)
        ]
        sum_th = sum(dev_throughputs)
        sum_sq = sum(t * t for t in dev_throughputs)
        jain_index = (sum_th * sum_th) / (num_devices * sum_sq) if sum_sq > 0 else 0.0

        res_dict = {
            "engine": "opt_oracle",
            "scheduler": "BASIL_OPT",
            "solver": "HiGHS-SciPy",
            "status": res.message,
            "is_optimal": is_optimal,
            "objective_value": float(-res.fun) if res.success else 0.0,
            "execution_time_s": exec_time,
            "mip_gap": float(getattr(res, "mip_gap", 0.0)),
            "total_packets_generated": K,
            "total_packets_sent": K,

            # Three Separate Parity Metrics:
            "scheduling_deadline_misses": scheduling_deadline_misses,
            "end_to_end_deadline_failures": expected_e2e_deadline_failures,
            "expected_end_to_end_deadline_failures": expected_e2e_deadline_failures,
            "optical_channel_losses": expected_channel_losses,
            "expected_optical_channel_losses": expected_channel_losses,
            "expected_channel_losses": expected_channel_losses,

            # Success rates:
            "scheduling_success_rate": ((K_with_deadline - scheduling_deadline_misses) / K_with_deadline) if K_with_deadline > 0 else 1.0,
            "expected_end_to_end_success_rate": ((K_with_deadline - expected_e2e_deadline_failures) / K_with_deadline) if K_with_deadline > 0 else 1.0,
            "deadline_success_rate": ((K_with_deadline - scheduling_deadline_misses) / K_with_deadline) if K_with_deadline > 0 else 1.0,
            "total_deadline_misses": scheduling_deadline_misses,
            "deadline_misses": scheduling_deadline_misses,

            # Terminology and Conservation:
            "scheduled_packets_count": N_del,
            "scheduling_coverage": N_del / K if K > 0 else 0.0,
            "scheduling_coverage_pct": (N_del / K if K > 0 else 0.0) * 100.0,
            "scheduled_pdr": N_del / K if K > 0 else 0.0,
            "total_packets_delivered": N_del,
            "delivered_on_time": N_del,
            "delivered_late": 0,
            "lost_channel": 0,
            "dropped_queue": 0,
            "pending_queue": K - N_del,
            "pdr": N_del / K if K > 0 else 0.0,
            "packet_delivery_ratio": N_del / K if K > 0 else 0.0,
            "expected_pdr": expected_pdr,
            "expected_received_pdr": expected_pdr,
            "expected_received_pdr_pct": expected_pdr * 100.0,
            "expected_delivered_packets": expected_del_pkts,
            "expected_delivered_on_time": expected_del_pkts,
            "ap_power_unit": "mW",
            "goodput_semantic_mbps": sem_goodput_mbps,
            "goodput_raw_mbps": raw_goodput_mbps,
            "throughput_mbps": raw_goodput_mbps,
            "avg_latency_ms": avg_lat_ms,
            "p95_latency_ms": p95_lat_ms,
            "jain_fairness_index": jain_index,
            "per_device_throughputs_mbps": dev_throughputs,
            "schedule": scheduled_packets,
        }

        if has_replay:
            res_dict.update({
                "realized_delivered_on_time": realized_delivered_on_time,
                "realized_lost_channel": realized_lost_channel,
                "realized_end_to_end_deadline_failures": realized_e2e_deadline_failures,
                "realized_pdr": realized_pdr,
                "realized_received_pdr": realized_pdr,
                "realized_received_pdr_pct": realized_pdr * 100.0,
                "pdr": realized_pdr,
                "packet_delivery_ratio": realized_pdr,
                "realized_goodput_semantic_mbps": realized_sem_goodput_mbps,
                "realized_throughput_mbps": realized_raw_goodput_mbps,
            })

        return res_dict

    def solve_continuous(
        self,
        packets: List[Dict[str, Any]],
        simulation_time_s: float,
        data_rate_mbps: float = 10.0,
        packet_size_bytes: int = 1024,
        device_per: Optional[List[float]] = None,
    ) -> Dict[str, Any]:
        """
        Solve continuous-time disjunctive scheduling MILP.
        Ideal for small validation instances with continuous arrival times.
        """
        start_time = time.time()
        K = len(packets)
        if K == 0:
            return self._empty_result(2, simulation_time_s)

        tx_durations = [
            (packets[k].get("size_bytes", packet_size_bytes) * 8.0) / (data_rate_mbps * 1e6)
            for k in range(K)
        ]
        M_big = simulation_time_s + 10.0

        if device_per is None:
            max_dev = max(p.get("device_id", 0) for p in packets) + 1
            device_per = [0.0] * max_dev
        device_rel = [max(0.0, min(1.0, 1.0 - per)) for per in device_per]

        h = highspy.Highs()
        h.setOptionValue("output_flag", False)
        h.setOptionValue("time_limit", self.time_limit_s)
        h.setOptionValue("mip_rel_gap", self.mip_rel_gap)

        # Variables:
        # x_k in {0, 1} for k in 0..K-1 (index: 0..K-1)
        # t_k in [0, T_sim] for k in 0..K-1 (index: K..2K-1)
        # z_{j, k} in {0, 1} for j < k (index: 2K .. 2K + K*(K-1)/2 - 1)
        pair_map = {}
        pair_idx = 2 * K
        for j in range(K):
            for k in range(j + 1, K):
                pair_map[(j, k)] = pair_idx
                pair_idx += 1
        num_vars = pair_idx

        col_lower = np.zeros(num_vars)
        col_upper = np.ones(num_vars)
        for k in range(K):
            col_upper[K + k] = simulation_time_s # t_k upper bound

        integrality = [highspy.HighsVarType.kInteger] * num_vars
        for k in range(K):
            integrality[K + k] = highspy.HighsVarType.kContinuous # t_k is continuous

        col_cost = np.zeros(num_vars)
        epsilon = 1e-6
        for k in range(K):
            d = packets[k].get("device_id", 0)
            rel = device_rel[d] if d < len(device_rel) else 1.0
            w = packets[k].get("semantic_importance", 0.50)
            sz = packets[k].get("size_bytes", packet_size_bytes)
            # Maximize semantic value of x_k:
            col_cost[k] = - (w * sz * 8.0 * rel)
            # Minimize start time t_k:
            col_cost[K + k] = epsilon

        h.addVars(num_vars, col_lower, col_upper)
        for i in range(num_vars):
            h.changeColIntegrality(i, integrality[i])
            h.changeColCost(i, col_cost[i])

        # Constraints:
        # 1. Arrival causality: t_k - a_k * x_k >= 0
        for k in range(K):
            arr = packets[k]["arrive_time_s"]
            indices = np.array([K + k, k], dtype=np.int32)
            values = np.array([1.0, -arr], dtype=np.float64)
            h.addRow(0.0, highspy.kHighsInf, 2, indices, values)

        # 2. Deadline compliance: t_k + tau_k + M_big * x_k <= D_k + M_big  => t_k + M_big * x_k <= D_k + M_big - tau_k
        for k in range(K):
            ddl = packets[k].get("deadline_s", -1.0)
            if ddl > 0.0:
                indices = np.array([K + k, k], dtype=np.int32)
                values = np.array([1.0, M_big], dtype=np.float64)
                upper = ddl + M_big - tx_durations[k]
                h.addRow(-highspy.kHighsInf, upper, 2, indices, values)

        # 3. Horizon limit: t_k + M_big * x_k <= T_sim + M_big - tau_k
        for k in range(K):
            indices = np.array([K + k, k], dtype=np.int32)
            values = np.array([1.0, M_big], dtype=np.float64)
            upper = simulation_time_s + M_big - tx_durations[k]
            h.addRow(-highspy.kHighsInf, upper, 2, indices, values)

        # 4. Disjunctive non-overlapping constraints for all pairs j < k:
        for j in range(K):
            for k in range(j + 1, K):
                z_var = pair_map[(j, k)]
                
                # Equation 4a: if x_j=1, x_k=1, and z_{j,k}=1, then t_j + tau_j <= t_k
                # t_j - t_k + M * z_{j,k} + M * x_j + M * x_k <= 3*M - tau_j
                indices1 = np.array([K + j, K + k, z_var, j, k], dtype=np.int32)
                values1 = np.array([1.0, -1.0, M_big, M_big, M_big], dtype=np.float64)
                h.addRow(-highspy.kHighsInf, 3.0 * M_big - tx_durations[j], 5, indices1, values1)

                # Equation 4b: if x_j=1, x_k=1, and z_{j,k}=0, then t_k + tau_k <= t_j
                # t_k - t_j - M * z_{j,k} + M * x_j + M * x_k <= 2*M - tau_k
                indices2 = np.array([K + k, K + j, z_var, j, k], dtype=np.int32)
                values2 = np.array([1.0, -1.0, -M_big, M_big, M_big], dtype=np.float64)
                h.addRow(-highspy.kHighsInf, 2.0 * M_big - tx_durations[k], 5, indices2, values2)

        h.run()
        exec_time = time.time() - start_time
        status = h.getModelStatus()
        status_str = h.modelStatusToString(status)
        is_optimal = (status == highspy.HighsModelStatus.kOptimal)
        sol = h.getSolution()

        scheduled = []
        scheduled_indices = set()
        for k in range(K):
            if sol.col_value[k] > 0.5:
                scheduled_indices.add(k)
                scheduled.append({
                    "packet_id": packets[k].get("id", k + 1),
                    "device_id": packets[k].get("device_id", 0),
                    "scheduled_start_s": sol.col_value[K + k],
                    "scheduled_end_s": sol.col_value[K + k] + tx_durations[k],
                    "latency_ms": (sol.col_value[K + k] + tx_durations[k] - packets[k]["arrive_time_s"]) * 1000.0,
                    "semantic_importance": packets[k].get("semantic_importance", 0.50),
                    "size_bytes": packets[k].get("size_bytes", packet_size_bytes),
                })
        scheduled.sort(key=lambda p: p["scheduled_start_s"])

        deadline_misses = sum(
            1 for k in range(K)
            if packets[k].get("deadline_s", -1.0) > 0.0 and k not in scheduled_indices
        )

        return {
            "status": status_str,
            "is_optimal": is_optimal,
            "execution_time_s": exec_time,
            "scheduled_packets_count": len(scheduled),
            "delivered_on_time": len(scheduled),
            "delivered_late": 0,
            "lost_channel": 0,
            "dropped_queue": 0,
            "pending_queue": K - len(scheduled),
            "total_packets_generated": K,
            "total_deadline_misses": deadline_misses,
            "schedule": scheduled,
        }

    def _empty_result(self, num_devices: int, simulation_time_s: float) -> Dict[str, Any]:
        return {
            "engine": "opt_oracle",
            "scheduler": "BASIL_OPT",
            "solver": "HiGHS",
            "status": "EmptyProblem",
            "is_optimal": True,
            "objective_value": 0.0,
            "execution_time_s": 0.0,
            "mip_gap": 0.0,
            "total_packets_generated": 0,
            "total_packets_delivered": 0,
            "scheduling_deadline_misses": 0,
            "end_to_end_deadline_failures": 0.0,
            "expected_end_to_end_deadline_failures": 0.0,
            "optical_channel_losses": 0.0,
            "expected_optical_channel_losses": 0.0,
            "expected_channel_losses": 0.0,
            "scheduling_success_rate": 1.0,
            "expected_end_to_end_success_rate": 1.0,
            "deadline_success_rate": 1.0,
            "scheduled_packets_count": 0,
            "scheduling_coverage": 0.0,
            "scheduling_coverage_pct": 0.0,
            "scheduled_pdr": 0.0,
            "expected_delivered_packets": 0.0,
            "expected_delivered_on_time": 0.0,
            "expected_pdr": 0.0,
            "expected_received_pdr": 0.0,
            "expected_received_pdr_pct": 0.0,
            "realized_received_pdr": 0.0,
            "realized_received_pdr_pct": 0.0,
            "ap_power_unit": "mW",
            "delivered_on_time": 0,
            "delivered_late": 0,
            "lost_channel": 0,
            "dropped_queue": 0,
            "pending_queue": 0,
            "pdr": 0.0,
            "goodput_semantic_mbps": 0.0,
            "goodput_raw_mbps": 0.0,
            "avg_latency_ms": 0.0,
            "p95_latency_ms": 0.0,
            "total_deadline_misses": 0,
            "jain_fairness_index": 1.0,
            "schedule": [],
        }
