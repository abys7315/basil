ALGORITHMS = {
    "FIFO": {
        "name": "FIFO",
        "description": (
            "First-In, First-Out scheduler. Packets are served in the order they arrive. "
            "Simple and fair under light load, but provides no priority differentiation."
        ),
        "params": [],
    },
    "RoundRobin": {
        "name": "Round Robin",
        "description": (
            "Round-Robin scheduler. Each device gets an equal time slot in a cyclic order, "
            "ensuring per-device fairness regardless of traffic intensity."
        ),
        "params": [
            {
                "name": "quantum_ms",
                "type": "float",
                "default": 1.0,
                "description": "Time quantum (ms) allocated to each device per round.",
            }
        ],
    },
    "StrictPriority": {
        "name": "Strict Priority",
        "description": (
            "Strict-Priority scheduler. Packets are assigned to priority classes (0=low, "
            "1=medium, 2=high). Higher-priority traffic is always served first; lower-priority "
            "traffic is served only when higher queues are empty."
        ),
        "params": [
            {
                "name": "num_classes",
                "type": "int",
                "default": 3,
                "description": "Number of priority classes (1–8).",
            }
        ],
    },
    "BASIL_PSA": {
        "name": "BASIL-PSA",
        "description": (
            "BASIL Priority-Sensitive Allocation scheduler. Combines deadline-aware priority "
            "with per-device fairness. Dynamically adjusts service rates based on deadline "
            "proximity and channel quality, minimising latency and deadline misses for "
            "time-critical Li-Fi traffic."
        ),
        "params": [
            {
                "name": "alpha",
                "type": "float",
                "default": 0.7,
                "description": "Weight for deadline urgency in the scheduling score (0–1).",
            },
            {
                "name": "beta",
                "type": "float",
                "default": 0.3,
                "description": "Weight for channel quality in the scheduling score (0–1).",
            },
            {
                "name": "deadline_margin_ms",
                "type": "float",
                "default": 5.0,
                "description": "Deadline slack (ms) below which a packet is promoted to highest urgency.",
            },
        ],
    },
    "BASIL_OPT": {
        "name": "BASIL-OPT (Offline Oracle)",
        "description": (
            "BASIL Offline Optimization Reference. Formulates packet scheduling as a Mixed-Integer Linear "
            "Program (MILP) solved via HiGHS with full future knowledge of arrivals, deadlines, and channel states. "
            "Provides the theoretical upper bound on achievable semantic goodput."
        ),
        "params": [
            {
                "name": "time_limit_s",
                "type": "float",
                "default": 30.0,
                "description": "Maximum solver execution time (seconds).",
            },
            {
                "name": "mip_rel_gap",
                "type": "float",
                "default": 0.001,
                "description": "Target relative MIP optimality gap tolerance.",
            },
        ],
    },
}
