import json
import logging
from datetime import datetime
from typing import List, Optional

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.models import Experiment, NetworkConfig, SimulationResult, TrafficConfig
from app.schemas.experiment import ExperimentCreate, SimulationResultResponse
from app.schemas.network import NetworkConfigCreate, NetworkConfigResponse
from app.schemas.traffic import TrafficConfigCreate, TrafficConfigResponse
from app.simulation.runner import SimulationRunner
from app.simulation.parser import ResultsParser

logger = logging.getLogger(__name__)
_runner = SimulationRunner()
_parser = ResultsParser()


# ---------------------------------------------------------------------------
# Network configs
# ---------------------------------------------------------------------------

async def create_network_config(db: AsyncSession, data: NetworkConfigCreate) -> NetworkConfig:
    obj = NetworkConfig(**data.model_dump(), created_at=datetime.utcnow().isoformat())
    db.add(obj)
    await db.commit()
    await db.refresh(obj)
    return obj


async def get_network_config(db: AsyncSession, config_id: int) -> Optional[NetworkConfig]:
    result = await db.execute(select(NetworkConfig).where(NetworkConfig.id == config_id))
    return result.scalar_one_or_none()


async def list_network_configs(db: AsyncSession) -> List[NetworkConfig]:
    result = await db.execute(select(NetworkConfig))
    return list(result.scalars().all())


async def delete_network_config(db: AsyncSession, config_id: int) -> bool:
    obj = await get_network_config(db, config_id)
    if obj is None:
        return False
    await db.delete(obj)
    await db.commit()
    return True


# ---------------------------------------------------------------------------
# Traffic configs
# ---------------------------------------------------------------------------

async def create_traffic_config(db: AsyncSession, data: TrafficConfigCreate) -> TrafficConfig:
    obj = TrafficConfig(**data.model_dump(), created_at=datetime.utcnow().isoformat())
    db.add(obj)
    await db.commit()
    await db.refresh(obj)
    return obj


async def get_traffic_config(db: AsyncSession, config_id: int) -> Optional[TrafficConfig]:
    result = await db.execute(select(TrafficConfig).where(TrafficConfig.id == config_id))
    return result.scalar_one_or_none()


async def list_traffic_configs(db: AsyncSession) -> List[TrafficConfig]:
    result = await db.execute(select(TrafficConfig))
    return list(result.scalars().all())


async def delete_traffic_config(db: AsyncSession, config_id: int) -> bool:
    obj = await get_traffic_config(db, config_id)
    if obj is None:
        return False
    await db.delete(obj)
    await db.commit()
    return True


# ---------------------------------------------------------------------------
# Experiments
# ---------------------------------------------------------------------------

async def create_experiment(db: AsyncSession, data: ExperimentCreate) -> Experiment:
    dump = data.model_dump()
    dump.pop("sim_time", None)
    obj = Experiment(**dump, created_at=datetime.utcnow().isoformat(), status="pending")
    db.add(obj)
    await db.commit()
    await db.refresh(obj)
    return obj


async def get_experiment(db: AsyncSession, experiment_id: int) -> Optional[Experiment]:
    result = await db.execute(
        select(Experiment)
        .where(Experiment.id == experiment_id)
        .options(selectinload(Experiment.network_config), selectinload(Experiment.traffic_config))
    )
    return result.scalar_one_or_none()


async def list_experiments(db: AsyncSession) -> List[Experiment]:
    result = await db.execute(select(Experiment))
    return list(result.scalars().all())


async def delete_experiment(db: AsyncSession, experiment_id: int) -> bool:
    obj = await get_experiment(db, experiment_id)
    if obj is None:
        return False
    await db.delete(obj)
    await db.commit()
    return True


async def run_experiment(db: AsyncSession, experiment_id: int) -> SimulationResult:
    """Run the simulation for an experiment and persist results."""
    exp = await get_experiment(db, experiment_id)
    if exp is None:
        raise ValueError(f"Experiment {experiment_id} not found")

    # Build config dict for the simulation
    nc = exp.network_config
    tc = exp.traffic_config
    engine = getattr(exp, "engine", "ns3") or "ns3"
    sim_config = {
        "experiment_id": exp.id,
        "scheduler": exp.scheduler,
        "simulation_time": exp.simulation_time,
        "num_devices": nc.num_devices,
        "data_rate": nc.data_rate_mbps,
        "traffic_mode": tc.traffic_mode,
        "burst_ratio": tc.burst_ratio,
        "room_width": nc.room_width,
        "room_height": nc.room_height,
        "ap_power": nc.ap_power,
        "half_angle": nc.half_angle,
        "packet_size": tc.packet_size,
        "normal_rate": tc.normal_rate,
        "burst_rate": tc.burst_rate,
        "network": {
            "num_devices": nc.num_devices,
            "room_width": nc.room_width,
            "room_height": nc.room_height,
            "ap_power": nc.ap_power,
            "half_angle": nc.half_angle,
            "data_rate_mbps": nc.data_rate_mbps,
        },
        "traffic": {
            "traffic_mode": tc.traffic_mode,
            "normal_rate": tc.normal_rate,
            "burst_rate": tc.burst_rate,
            "burst_ratio": tc.burst_ratio,
            "packet_size": tc.packet_size,
        },
    }

    # Mark as running
    exp.status = "running"
    await db.commit()

    try:
        raw = await _runner.run(sim_config, engine=engine)
        parsed = _parser.parse(raw)

        per_device = parsed.pop("per_device_stats", [])
        time_series = parsed.pop("time_series", [])

        result_obj = SimulationResult(
            experiment_id=exp.id,
            avg_latency_ms=parsed.get("avg_latency_ms"),
            throughput_mbps=parsed.get("throughput_mbps"),
            packet_delivery_ratio=parsed.get("packet_delivery_ratio"),
            packet_loss=parsed.get("packet_loss"),
            deadline_misses=parsed.get("deadline_misses"),
            fairness_index=parsed.get("fairness_index"),
            simulation_duration_s=parsed.get("simulation_duration_s"),
            raw_json=json.dumps({"per_device_stats": per_device, "time_series": time_series}),
            created_at=datetime.utcnow().isoformat(),
        )
        db.add(result_obj)

        exp.status = "completed"
        exp.completed_at = datetime.utcnow().isoformat()
        await db.commit()
        await db.refresh(result_obj)
        return result_obj

    except Exception as exc:
        logger.exception("Simulation error for experiment %s", experiment_id)
        exp.status = "failed"
        exp.error_msg = str(exc)[:500]
        exp.completed_at = datetime.utcnow().isoformat()
        await db.commit()
        raise


# ---------------------------------------------------------------------------
# Results
# ---------------------------------------------------------------------------

async def get_result(db: AsyncSession, experiment_id: int) -> Optional[SimulationResult]:
    result = await db.execute(
        select(SimulationResult).where(SimulationResult.experiment_id == experiment_id)
    )
    return result.scalar_one_or_none()


async def list_results(db: AsyncSession) -> List[SimulationResult]:
    result = await db.execute(select(SimulationResult))
    return list(result.scalars().all())


async def compare_results(db: AsyncSession, ids: List[int]) -> List[SimulationResult]:
    result = await db.execute(
        select(SimulationResult).where(SimulationResult.experiment_id.in_(ids))
    )
    return list(result.scalars().all())
