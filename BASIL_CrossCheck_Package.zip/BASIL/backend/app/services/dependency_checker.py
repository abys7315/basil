"""
BASIL Runtime Dependency Validation Service.
Inspects system prerequisites for running the BASIL desktop application,
FastAPI backend, WSL2 environment, and ns-3.42 Li-Fi simulation engine.

Strictly separates:
1. Core Runtime Dependencies (Host GUI, Python 3.10+, Core Backend Packages, Storage)
2. Optional Simulation Dependencies (WSL2, Ubuntu Distribution, ns-3.42 Li-Fi binary)
3. Development and Testing Tools (pytest, Rust/Cargo compiler)
"""

import importlib.util
import importlib.metadata
import os
import platform
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any, Dict, List

from app.database import get_basil_data_dir


def check_webview2() -> Dict[str, Any]:
    """Check Microsoft Edge WebView2 runtime on Windows."""
    if platform.system() != "Windows":
        return {
            "name": "WebView2 Runtime",
            "category": "core_runtime",
            "deployment_nature": "Host OS Feature",
            "status": "not_applicable",
            "version": None,
            "details": f"Platform is {platform.system()}; WebView2 is Windows-specific.",
            "action_required": None,
        }

    import winreg

    reg_paths = [
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}"),
        (winreg.HKEY_CURRENT_USER, r"Software\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}"),
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}"),
    ]

    for root, subkey in reg_paths:
        try:
            with winreg.OpenKey(root, subkey) as key:
                pv, _ = winreg.QueryValueEx(key, "pv")
                if pv and pv != "0.0.0.0":
                    return {
                        "name": "WebView2 Runtime",
                        "category": "core_runtime",
                        "deployment_nature": "Host System Prerequisite (Installed separately)",
                        "status": "installed",
                        "version": str(pv),
                        "details": f"Microsoft Edge WebView2 Runtime is installed (v{pv}).",
                        "action_required": None,
                    }
        except OSError:
            continue

    return {
        "name": "WebView2 Runtime",
        "category": "core_runtime",
        "deployment_nature": "Host System Prerequisite (Installed separately)",
        "status": "missing",
        "version": None,
        "details": "Microsoft Edge WebView2 Runtime was not detected in Windows registry.",
        "action_required": "Download and install Evergreen Bootstrapper from https://developer.microsoft.com/en-us/microsoft-edge/webview2/ (Required for Tauri desktop UI).",
    }


def check_python_runtime() -> Dict[str, Any]:
    """Check Python version (requires >= 3.10)."""
    major, minor, micro = sys.version_info.major, sys.version_info.minor, sys.version_info.micro
    v_str = f"{major}.{minor}.{micro}"

    if major == 3 and minor >= 10:
        return {
            "name": "Python Runtime",
            "category": "core_runtime",
            "deployment_nature": "Host System Prerequisite (Installed separately)",
            "status": "installed",
            "version": v_str,
            "details": f"Python {v_str} ({platform.architecture()[0]}) is operational.",
            "action_required": None,
        }
    elif major == 3 and minor < 10:
        return {
            "name": "Python Runtime",
            "category": "core_runtime",
            "deployment_nature": "Host System Prerequisite (Installed separately)",
            "status": "incompatible",
            "version": v_str,
            "details": f"Python {v_str} is installed, but BASIL requires Python 3.10 or newer.",
            "action_required": "Upgrade Python to 3.10+ from python.org or via winget (winget install Python.Python.3.10).",
        }
    else:
        return {
            "name": "Python Runtime",
            "category": "core_runtime",
            "deployment_nature": "Host System Prerequisite (Installed separately)",
            "status": "incompatible",
            "version": v_str,
            "details": f"Incompatible Python version: {v_str}.",
            "action_required": "Install Python 3.10+ from python.org.",
        }


def check_core_backend_packages() -> List[Dict[str, Any]]:
    """Verify presence and versions of all critical backend Python libraries."""
    core_packages = [
        ("fastapi", "0.100.0"),
        ("uvicorn", "0.20.0"),
        ("sqlalchemy", "2.0.0"),
        ("aiosqlite", "0.18.0"),
        ("pydantic", "2.0.0"),
        ("pandas", "2.0.0"),
        ("numpy", "1.24.0"),
        ("scipy", "1.10.0"),
        ("highspy", "1.5.0"),
    ]

    results = []
    for pkg, min_ver in core_packages:
        spec = importlib.util.find_spec(pkg)
        if spec is None:
            results.append({
                "name": f"Python Package: {pkg}",
                "category": "core_runtime",
                "deployment_nature": "Python Environment Dependency",
                "status": "missing",
                "version": None,
                "details": f"Required package '{pkg}' is not installed.",
                "action_required": f"Run 'pip install {pkg}' or 'pip install -r backend/requirements.txt'.",
            })
            continue

        try:
            installed_ver = importlib.metadata.version(pkg)
            results.append({
                "name": f"Python Package: {pkg}",
                "category": "core_runtime",
                "deployment_nature": "Python Environment Dependency",
                "status": "installed",
                "version": installed_ver,
                "details": f"Package '{pkg}' v{installed_ver} installed (min required: {min_ver}).",
                "action_required": None,
            })
        except Exception as e:
            results.append({
                "name": f"Python Package: {pkg}",
                "category": "core_runtime",
                "deployment_nature": "Python Environment Dependency",
                "status": "installed",
                "version": "unknown",
                "details": f"Package '{pkg}' is importable ({e}).",
                "action_required": None,
            })
    return results


def check_dev_packages() -> List[Dict[str, Any]]:
    """
    Check development & testing libraries (pytest).
    Explicitly categorized as development; NOT required to run or launch BASIL desktop app.
    """
    spec = importlib.util.find_spec("pytest")
    if spec is None:
        return [{
            "name": "Python Package: pytest (Testing)",
            "category": "development_tools",
            "deployment_nature": "Development/Test Tool (Optional)",
            "status": "missing",
            "version": None,
            "details": "Pytest is not installed. Note: Pytest is strictly for running automated test suites and is NOT required to launch or use the BASIL application.",
            "action_required": "Install only if running development tests: 'pip install pytest'.",
        }]

    try:
        ver = importlib.metadata.version("pytest")
        return [{
            "name": "Python Package: pytest (Testing)",
            "category": "development_tools",
            "deployment_nature": "Development/Test Tool (Optional)",
            "status": "installed",
            "version": ver,
            "details": f"Pytest v{ver} is installed for unit/regression testing (Optional for end users).",
            "action_required": None,
        }]
    except Exception:
        return [{
            "name": "Python Package: pytest (Testing)",
            "category": "development_tools",
            "deployment_nature": "Development/Test Tool (Optional)",
            "status": "installed",
            "version": "unknown",
            "details": "Pytest is available.",
            "action_required": None,
        }]


def check_runtime_rust() -> Dict[str, Any]:
    """
    Verify that Rust/Cargo is NOT required at runtime for end users.
    BASIL ships as a compiled native Windows binary.
    """
    has_cargo = shutil.which("cargo") is not None
    return {
        "name": "Rust Toolchain (Build-time only)",
        "category": "development_tools",
        "deployment_nature": "Compiler Toolchain (Build-time only)",
        "status": "not_required",
        "version": "Not Needed for End Users",
        "details": (
            "Rust and Cargo are build-time compiler dependencies only. "
            f"The compiled BASIL desktop executable and installer run without Rust installed on host machine. "
            f"(Dev system cargo present: {has_cargo})."
        ),
        "action_required": None,
    }


def check_wsl2() -> Dict[str, Any]:
    """Verify WSL2 availability and health on Windows."""
    if platform.system() != "Windows":
        return {
            "name": "WSL2 Subsystem",
            "category": "simulation_runtime",
            "deployment_nature": "Optional Feature (Native Linux Host)",
            "status": "not_applicable",
            "version": None,
            "details": "Non-Windows system; ns-3 runs natively.",
            "action_required": None,
        }

    try:
        proc = subprocess.run(
            ["wsl", "--status"],
            capture_output=True,
            text=True,
            timeout=5,
            creationflags=0x08000000 if hasattr(subprocess, "CREATE_NO_WINDOW") else 0,
        )
        if proc.returncode == 0 or "Default Version" in (proc.stdout + proc.stderr):
            return {
                "name": "WSL2 Subsystem",
                "category": "simulation_runtime",
                "deployment_nature": "Windows Feature (Installed separately by user)",
                "status": "installed",
                "version": "WSL2",
                "details": "WSL2 subsystem is installed and operational for hybrid ns-3 simulations.",
                "action_required": None,
            }
        else:
            return {
                "name": "WSL2 Subsystem",
                "category": "simulation_runtime",
                "deployment_nature": "Windows Feature (Installed separately by user)",
                "status": "missing",
                "version": None,
                "details": f"WSL returned non-zero exit code: {proc.stderr.strip()}",
                "action_required": "Enable WSL2 via 'wsl --install' in an administrator PowerShell prompt (Optional: required for ns-3.42; standalone C++ fallback available).",
            }
    except Exception as exc:
        return {
            "name": "WSL2 Subsystem",
            "category": "simulation_runtime",
            "deployment_nature": "Windows Feature (Installed separately by user)",
            "status": "missing",
            "version": None,
            "details": f"Failed to execute wsl: {str(exc)}",
            "action_required": "Run 'wsl --install' in an administrator PowerShell prompt.",
        }


def check_ubuntu_distro() -> Dict[str, Any]:
    """Verify Ubuntu distribution exists inside WSL."""
    if platform.system() != "Windows":
        return {
            "name": "Ubuntu WSL Distribution",
            "category": "simulation_runtime",
            "deployment_nature": "Optional Feature (Native Linux Host)",
            "status": "not_applicable",
            "version": None,
            "details": "Non-Windows host.",
            "action_required": None,
        }

    try:
        proc = subprocess.run(
            ["wsl", "-d", "Ubuntu", "--", "bash", "-c", "cat /etc/os-release | grep PRETTY_NAME"],
            capture_output=True,
            text=True,
            timeout=15,
            creationflags=0x08000000 if hasattr(subprocess, "CREATE_NO_WINDOW") else 0,
        )
        if proc.returncode == 0 and "Ubuntu" in proc.stdout:
            distro_name = proc.stdout.split("=")[-1].strip().strip('"')
            return {
                "name": "Ubuntu WSL Distribution",
                "category": "simulation_runtime",
                "deployment_nature": "WSL Guest OS (Installed separately by user)",
                "status": "installed",
                "version": distro_name,
                "details": f"Ubuntu distribution is accessible: {distro_name}.",
                "action_required": None,
            }
        else:
            return {
                "name": "Ubuntu WSL Distribution",
                "category": "simulation_runtime",
                "deployment_nature": "WSL Guest OS (Installed separately by user)",
                "status": "missing",
                "version": None,
                "details": "WSL did not find a running 'Ubuntu' distribution.",
                "action_required": "Install Ubuntu inside WSL via 'wsl --install -d Ubuntu'.",
            }
    except Exception as exc:
        return {
            "name": "Ubuntu WSL Distribution",
            "category": "simulation_runtime",
            "deployment_nature": "WSL Guest OS (Installed separately by user)",
            "status": "missing",
            "version": None,
            "details": f"Error querying WSL Ubuntu: {str(exc)}",
            "action_required": "Run 'wsl --install -d Ubuntu' in PowerShell.",
        }


def check_ns3_executable() -> Dict[str, Any]:
    """Verify ns-3.42 Li-Fi simulation binary in WSL Ubuntu or local prototype fallback."""
    # 1. Primary: ns-3.42 inside WSL Ubuntu
    ns3_bin_wsl = "/opt/ns3/ns-allinone-3.42/ns-3.42/build/scratch/ns3.42-basil-ns3-sim"
    if platform.system() == "Windows":
        try:
            proc = subprocess.run(
                ["wsl", "-d", "Ubuntu", "--", "bash", "-c", f"test -f {ns3_bin_wsl} && echo FOUND"],
                capture_output=True,
                text=True,
                timeout=5,
                creationflags=0x08000000 if hasattr(subprocess, "CREATE_NO_WINDOW") else 0,
            )
            if "FOUND" in proc.stdout:
                return {
                    "name": "ns-3.42 Li-Fi Simulator",
                    "category": "simulation_runtime",
                    "deployment_nature": "Simulation Engine (Built in WSL Ubuntu)",
                    "status": "installed",
                    "version": "ns-3.42 (Hybrid Li-Fi PHY/MAC)",
                    "details": f"Found compiled ns-3 binary at {ns3_bin_wsl} in Ubuntu.",
                    "action_required": None,
                }
        except Exception:
            pass

    # 2. Secondary fallback: check bundled or local C++ prototype
    candidates = [
        Path(__file__).resolve().parent.parent.parent.parent / "ns3-lifi" / "scratch" / "basil-sim.exe",
        Path(__file__).resolve().parent.parent.parent / "ns3-lifi" / "scratch" / "basil-sim.exe",
        Path.cwd() / "resources" / "ns3-lifi" / "scratch" / "basil-sim.exe",
    ]
    for local_sim in candidates:
        if local_sim.exists():
            return {
                "name": "ns-3.42 Li-Fi Simulator",
                "category": "simulation_runtime",
                "deployment_nature": "Simulation Engine (Bundled C++ Prototype Fallback)",
                "status": "installed",
                "version": "Standalone C++ Prototype",
                "details": f"Found standalone C++ prototype simulator at {local_sim}.",
                "action_required": None,
            }

    return {
        "name": "ns-3.42 Li-Fi Simulator",
        "category": "simulation_runtime",
        "deployment_nature": "Simulation Engine (Built in WSL Ubuntu)",
        "status": "missing",
        "version": None,
        "details": f"ns-3.42 binary not found at {ns3_bin_wsl} inside Ubuntu WSL.",
        "action_required": "Build ns-3 inside WSL: cd /opt/ns3/ns-allinone-3.42/ns-3.42 && ./ns3 build",
    }


def check_filesystem_writability() -> Dict[str, Any]:
    """Verify Windows application data storage directory has read/write permissions."""
    data_dir = get_basil_data_dir()

    try:
        with tempfile.NamedTemporaryFile(dir=data_dir, prefix="basil_rw_test_", delete=True) as tmp:
            tmp.write(b"BASIL_RW_CHECK_OK")
            tmp.flush()
        return {
            "name": "Filesystem Writability",
            "category": "core_runtime",
            "deployment_nature": "Application Data Storage",
            "status": "installed",
            "version": "R/W OK",
            "details": f"Application data directory '{data_dir}' is writable for SQLite database and simulation artifacts.",
            "action_required": None,
        }
    except Exception as exc:
        return {
            "name": "Filesystem Writability",
            "category": "core_runtime",
            "deployment_nature": "Application Data Storage",
            "status": "incompatible",
            "version": "Read-Only / Denied",
            "details": f"Cannot write to '{data_dir}': {str(exc)}",
            "action_required": f"Ensure write permissions for '{data_dir}'.",
        }


def run_all_dependency_checks() -> Dict[str, Any]:
    """Run full diagnostic suite and return structured summary by tier."""
    checks: List[Dict[str, Any]] = []

    # 1. Core Runtime (Required for application & backend launch)
    checks.append(check_webview2())
    checks.append(check_python_runtime())
    checks.extend(check_core_backend_packages())
    checks.append(check_filesystem_writability())

    # 2. Simulation Runtime (Required for full ns-3.42 simulations)
    checks.append(check_wsl2())
    checks.append(check_ubuntu_distro())
    checks.append(check_ns3_executable())

    # 3. Development Tools (Optional; NOT required to launch or use BASIL)
    checks.extend(check_dev_packages())
    checks.append(check_runtime_rust())

    core_checks = [c for c in checks if c["category"] == "core_runtime"]
    sim_checks = [c for c in checks if c["category"] == "simulation_runtime"]
    dev_checks = [c for c in checks if c["category"] == "development_tools"]

    core_ready = all(c["status"] in ("installed", "not_required", "not_applicable") for c in core_checks)
    sim_ready = all(c["status"] in ("installed", "not_required", "not_applicable") for c in sim_checks)
    dev_ready = all(c["status"] in ("installed", "not_required", "not_applicable") for c in dev_checks)

    # all_ready evaluates operational readiness of the platform
    all_ready = core_ready and sim_ready

    missing_count = sum(1 for c in checks if c["status"] == "missing")
    incompatible_count = sum(1 for c in checks if c["status"] == "incompatible")

    return {
        "core_runtime_ready": core_ready,
        "simulation_runtime_ready": sim_ready,
        "development_ready": dev_ready,
        "all_ready": all_ready,
        "summary": {
            "total_checks": len(checks),
            "passed": sum(1 for c in checks if c["status"] in ("installed", "not_required", "not_applicable")),
            "core_runtime_passed": sum(1 for c in core_checks if c["status"] in ("installed", "not_required", "not_applicable")),
            "core_runtime_total": len(core_checks),
            "simulation_runtime_passed": sum(1 for c in sim_checks if c["status"] in ("installed", "not_required", "not_applicable")),
            "simulation_runtime_total": len(sim_checks),
            "missing": missing_count,
            "incompatible": incompatible_count,
        },
        "dependencies": checks,
    }
