import os
import shutil
from pathlib import Path
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from sqlalchemy.orm import DeclarativeBase


def get_basil_data_dir() -> Path:
    """
    Returns the designated application data directory for SQLite database,
    simulation artifacts, and experiment logs.
    Priority:
    1. Explicit BASIL_DATA_DIR environment variable
    2. Test environment override (BASIL_ENV == 'test') -> repo experiments/
    3. Production Windows AppData: %LOCALAPPDATA%/BASIL/data
    4. Fallback to ~/.basil/data
    """
    if "BASIL_DATA_DIR" in os.environ and os.environ["BASIL_DATA_DIR"].strip():
        d = Path(os.environ["BASIL_DATA_DIR"].strip())
        d.mkdir(parents=True, exist_ok=True)
        return d

    if os.environ.get("BASIL_ENV") == "test":
        repo_exp = Path(__file__).resolve().parent.parent.parent / "experiments"
        if repo_exp.exists():
            return repo_exp

    local_app_data = os.environ.get("LOCALAPPDATA")
    # If explicitly marked as installed mode or outside source repo
    is_installed = os.environ.get("BASIL_INSTALLED_MODE") == "1"
    repo_exp = Path(__file__).resolve().parent.parent.parent / "experiments"

    if not is_installed and repo_exp.exists():
        return repo_exp
    elif local_app_data:
        d = Path(local_app_data) / "BASIL" / "data"
        d.mkdir(parents=True, exist_ok=True)
        return d
    else:
        d = Path.home() / ".basil" / "data"
        d.mkdir(parents=True, exist_ok=True)
        return d


_data_dir = get_basil_data_dir()
_db_path = _data_dir / "basil.db"

# Seed initial database from packaged template if starting in a fresh AppData location
if not _db_path.exists():
    candidates = [
        Path(__file__).resolve().parent.parent / "basil.db",
        Path(__file__).resolve().parent.parent.parent / "experiments" / "basil.db",
    ]
    for c in candidates:
        if c.exists() and c.is_file():
            try:
                shutil.copy2(c, _db_path)
                break
            except Exception:
                pass

DATABASE_URL = f"sqlite+aiosqlite:///{_db_path}"

engine = create_async_engine(DATABASE_URL, echo=False)

AsyncSessionLocal = async_sessionmaker(
    bind=engine,
    class_=AsyncSession,
    expire_on_commit=False,
)


class Base(DeclarativeBase):
    pass


async def get_db():
    async with AsyncSessionLocal() as session:
        try:
            yield session
        finally:
            await session.close()


async def init_db():
    from app.models import Base as ModelBase  # noqa: F401 – ensures models registered
    async with engine.begin() as conn:
        await conn.run_sync(ModelBase.metadata.create_all)
