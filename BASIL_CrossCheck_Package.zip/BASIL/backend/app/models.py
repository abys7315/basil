from datetime import datetime
from sqlalchemy import (
    Column, Integer, Text, Float, ForeignKey, String,
)
from sqlalchemy.orm import relationship
from app.database import Base


class NetworkConfig(Base):
    __tablename__ = "network_configs"

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(Text, nullable=False)
    num_devices = Column(Integer, nullable=False)
    room_width = Column(Float, nullable=False)
    room_height = Column(Float, nullable=False)
    ap_power = Column(Float, nullable=False)
    half_angle = Column(Float, nullable=False)
    data_rate_mbps = Column(Float, nullable=False)
    created_at = Column(Text, default=lambda: datetime.utcnow().isoformat())

    experiments = relationship("Experiment", back_populates="network_config")


class TrafficConfig(Base):
    __tablename__ = "traffic_configs"

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(Text, nullable=False)
    traffic_mode = Column(Text, nullable=False)
    normal_rate = Column(Float, nullable=False)
    burst_rate = Column(Float, nullable=False)
    burst_ratio = Column(Float, nullable=False)
    packet_size = Column(Integer, nullable=False)
    created_at = Column(Text, default=lambda: datetime.utcnow().isoformat())

    experiments = relationship("Experiment", back_populates="traffic_config")


class Experiment(Base):
    __tablename__ = "experiments"

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(Text, nullable=False)
    network_config_id = Column(Integer, ForeignKey("network_configs.id"), nullable=False)
    traffic_config_id = Column(Integer, ForeignKey("traffic_configs.id"), nullable=False)
    scheduler = Column(Text, nullable=False)
    simulation_time = Column(Float, nullable=False)
    engine = Column(Text, default="ns3")
    status = Column(Text, default="pending")
    created_at = Column(Text, default=lambda: datetime.utcnow().isoformat())
    completed_at = Column(Text, nullable=True)
    error_msg = Column(Text, nullable=True)

    network_config = relationship("NetworkConfig", back_populates="experiments")
    traffic_config = relationship("TrafficConfig", back_populates="experiments")
    result = relationship("SimulationResult", back_populates="experiment", uselist=False)


class SimulationResult(Base):
    __tablename__ = "simulation_results"

    id = Column(Integer, primary_key=True, autoincrement=True)
    experiment_id = Column(Integer, ForeignKey("experiments.id"), unique=True, nullable=False)
    avg_latency_ms = Column(Float, nullable=True)
    throughput_mbps = Column(Float, nullable=True)
    packet_delivery_ratio = Column(Float, nullable=True)
    packet_loss = Column(Float, nullable=True)
    deadline_misses = Column(Integer, nullable=True)
    fairness_index = Column(Float, nullable=True)
    simulation_duration_s = Column(Float, nullable=True)
    raw_json = Column(Text, nullable=True)
    created_at = Column(Text, default=lambda: datetime.utcnow().isoformat())

    experiment = relationship("Experiment", back_populates="result")
