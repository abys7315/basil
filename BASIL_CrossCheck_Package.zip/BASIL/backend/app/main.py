import logging

from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.database import init_db
from app.api.network import router as network_router
from app.api.traffic import router as traffic_router
from app.api.experiments import router as experiments_router
from app.api.simulate import router as simulate_router
from app.api.results import router as results_router
from app.api.algorithms import router as algorithms_router
from app.api.system import router as system_router

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Starting up – initialising database …")
    await init_db()
    logger.info("Database ready.")
    yield
    logger.info("Shutting down.")


app = FastAPI(
    title="BASIL API",
    description="Backend API for the BASIL Li-Fi scheduling simulator",
    version="0.1.0",
    lifespan=lifespan,
)

# CORS – allow all origins for development
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Routers
app.include_router(network_router, prefix="/api")
app.include_router(traffic_router, prefix="/api")
app.include_router(experiments_router, prefix="/api")
app.include_router(simulate_router, prefix="/api")
app.include_router(results_router, prefix="/api")
app.include_router(algorithms_router, prefix="/api")
app.include_router(system_router, prefix="/api")


@app.get("/")
async def root():
    return {"message": "BASIL API", "version": "0.1.0"}


@app.get("/health")
@app.get("/api/health")
async def health():
    return {"status": "ok"}
