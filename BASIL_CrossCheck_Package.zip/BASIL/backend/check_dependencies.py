#!/usr/bin/env python3
"""
BASIL Runtime Dependency & Environment Validation CLI (v4.2.0).
Usage:
    python check_dependencies.py
    python check_dependencies.py --json
"""

import json
import sys
from pathlib import Path

# Ensure app package is importable
backend_root = Path(__file__).resolve().parent
if str(backend_root) not in sys.path:
    sys.path.insert(0, str(backend_root))

from app.services.dependency_checker import run_all_dependency_checks


def main():
    as_json = "--json" in sys.argv
    results = run_all_dependency_checks()

    if as_json:
        print(json.dumps(results, indent=2))
        sys.exit(0 if results["core_runtime_ready"] else 1)

    print("=" * 78)
    print("BASIL Runtime Dependency & Deployment Audit (v4.2.0)")
    print("=" * 78)

    categories = {
        "core_runtime": (
            "1. CORE APPLICATION RUNTIME (Required to launch desktop app & backend API)",
            "All components below must be installed on the host machine to run BASIL."
        ),
        "simulation_runtime": (
            "2. SIMULATION ENGINE RUNTIME (Optional / Recommended for ns-3.42 Li-Fi)",
            "Enables the official hybrid ns-3.42 simulation engine via WSL2 Ubuntu."
        ),
        "development_tools": (
            "3. DEVELOPMENT & TESTING TOOLS (Optional; NOT required for end users)",
            "Used only for building from source or running automated pytest test suites."
        ),
    }

    by_cat = {}
    for dep in results["dependencies"]:
        cat = dep.get("category", "other")
        by_cat.setdefault(cat, []).append(dep)

    for cat_key, (cat_title, cat_desc) in categories.items():
        deps = by_cat.get(cat_key, [])
        if not deps:
            continue
        print(f"\n{cat_title}")
        print(f"  Note: {cat_desc}")
        print("-" * 78)
        for dep in deps:
            status = dep["status"].upper()
            mark = "✓" if status in ("INSTALLED", "NOT_REQUIRED", "NOT_APPLICABLE") else "✗"
            ver = f" (v{dep['version']})" if dep.get("version") and dep['version'] != "Not Needed for End Users" else ""
            nature = f" [{dep.get('deployment_nature', '')}]" if dep.get("deployment_nature") else ""
            print(f"  [{mark}] {dep['name']}{ver} — {status}{nature}")
            print(f"      Details: {dep['details']}")
            if dep.get("action_required"):
                print(f"      --> ACTION: {dep['action_required']}")

    summary = results["summary"]
    print("\n" + "=" * 78)
    print(f"Deployment Summary: {summary['passed']}/{summary['total_checks']} checks passed. "
          f"Missing: {summary['missing']}, Incompatible: {summary['incompatible']}.")
    print(f"  • Core Runtime Ready:       {'YES' if results['core_runtime_ready'] else 'NO'} ({summary['core_runtime_passed']}/{summary['core_runtime_total']})")
    print(f"  • Simulation Runtime Ready: {'YES' if results['simulation_runtime_ready'] else 'NO'} ({summary['simulation_runtime_passed']}/{summary['simulation_runtime_total']})")
    print(f"  • Development Tools Ready:  {'YES' if results['development_ready'] else 'NO'}")
    
    if results["core_runtime_ready"]:
        print("Status: CORE RUNTIME OPERATIONAL. Application is ready to launch.")
        print("=" * 78)
        sys.exit(0)
    else:
        print("Status: CORE RUNTIME PREREQUISITES MISSING. See required actions above.")
        print("=" * 78)
        sys.exit(1)


if __name__ == "__main__":
    main()
