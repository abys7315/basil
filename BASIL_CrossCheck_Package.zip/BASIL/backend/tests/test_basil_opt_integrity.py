"""
BASIL Phase 3.1: Mathematical & Benchmark Integrity Regression Tests
Validates solver correctness, known analytical optima, boundary infeasibilities,
heterogeneous packet sizes, channel PER weighting, and single-resource exclusivity.
"""

import pytest
import numpy as np
from app.algorithms.basil_opt import BasilOptSolver, HAS_HIGHS

@pytest.mark.skipif(not HAS_HIGHS, reason="HiGHS solver required")
def test_integrity_known_optimal_single_slot_contention():
    """Verify that when 2 packets contend for 1 slot, the solver selects the higher semantic value."""
    solver = BasilOptSolver(time_limit_s=5.0)
    pkts = [
        {"id": 1, "device_id": 0, "size_bytes": 1024, "arrive_time_s": 0.0, "deadline_s": 0.001, "semantic_importance": 1.0},
        {"id": 2, "device_id": 0, "size_bytes": 1024, "arrive_time_s": 0.0, "deadline_s": 0.001, "semantic_importance": 0.2},
    ]
    # At 15 Mbps, 1024 bytes requires 0.000546s. A simulation of 0.0006s offers exactly 1 slot.
    res = solver.solve_slotted(
        pkts, num_devices=1, simulation_time_s=0.0006, data_rate_mbps=15.0, packet_size_bytes=1024, device_per=[0.0]
    )
    assert res["status"] == "Optimal"
    assert res["is_optimal"] is True
    assert len(res["schedule"]) == 1
    assert res["schedule"][0]["packet_id"] == 1
    assert res["total_deadline_misses"] == 1

@pytest.mark.skipif(not HAS_HIGHS, reason="HiGHS solver required")
def test_integrity_infeasible_tight_deadline():
    """Verify that packets whose transmission cannot finish before deadline are rejected."""
    solver = BasilOptSolver(time_limit_s=5.0)
    pkts = [
        {"id": 1, "device_id": 0, "size_bytes": 1024, "arrive_time_s": 0.0, "deadline_s": 0.0002, "semantic_importance": 1.0},
    ]
    res = solver.solve_slotted(
        pkts, num_devices=1, simulation_time_s=0.001, data_rate_mbps=15.0, packet_size_bytes=1024, device_per=[0.0]
    )
    assert res["status"] == "InfeasibleOrEmpty"
    assert len(res["schedule"]) == 0
    assert res["total_deadline_misses"] == 1
    assert res["pdr"] == 0.0

@pytest.mark.skipif(not HAS_HIGHS, reason="HiGHS solver required")
def test_integrity_channel_per_exploitation():
    """Verify that channel reliability (1 - PER) directly weights scheduling decisions."""
    solver = BasilOptSolver(time_limit_s=5.0)
    pkts = [
        {"id": 101, "device_id": 0, "size_bytes": 1024, "arrive_time_s": 0.0, "deadline_s": 0.001, "semantic_importance": 1.0},
        {"id": 102, "device_id": 1, "size_bytes": 1024, "arrive_time_s": 0.0, "deadline_s": 0.001, "semantic_importance": 1.0},
    ]
    # Device 0 is clean (PER=0.0); Device 1 is degraded (PER=0.85).
    # Only 1 transmission slot is available.
    res = solver.solve_slotted(
        pkts, num_devices=2, simulation_time_s=0.0006, data_rate_mbps=15.0, packet_size_bytes=1024, device_per=[0.0, 0.85]
    )
    assert res["status"] == "Optimal"
    assert len(res["schedule"]) == 1
    assert res["schedule"][0]["packet_id"] == 101
    assert res["schedule"][0]["device_id"] == 0

@pytest.mark.skipif(not HAS_HIGHS, reason="HiGHS solver required")
def test_integrity_continuous_heterogeneous_packet_sizes():
    """Verify continuous-time formulation with differing packet sizes enforces non-overlapping intervals."""
    solver = BasilOptSolver(time_limit_s=5.0)
    pkts = [
        {"id": 1, "device_id": 0, "size_bytes": 512, "arrive_time_s": 0.0, "deadline_s": 0.010, "semantic_importance": 1.0},
        {"id": 2, "device_id": 1, "size_bytes": 1024, "arrive_time_s": 0.0, "deadline_s": 0.010, "semantic_importance": 0.5},
    ]
    res = solver.solve_continuous(
        pkts, simulation_time_s=0.010, data_rate_mbps=15.0, packet_size_bytes=1024
    )
    assert res["is_optimal"] is True
    sch = res["schedule"]
    assert len(sch) == 2
    # Verify non-overlapping intervals
    for i in range(len(sch) - 1):
        assert sch[i]["scheduled_end_s"] <= sch[i + 1]["scheduled_start_s"] + 1e-9
    # Verify duration of each packet matches its actual size
    p1 = next(p for p in sch if p["packet_id"] == 1)
    p2 = next(p for p in sch if p["packet_id"] == 2)
    dur1 = p1["scheduled_end_s"] - p1["scheduled_start_s"]
    dur2 = p2["scheduled_end_s"] - p2["scheduled_start_s"]
    expected_dur1 = (512 * 8.0) / (15.0 * 1e6)
    expected_dur2 = (1024 * 8.0) / (15.0 * 1e6)
    assert abs(dur1 - expected_dur1) < 1e-8
    assert abs(dur2 - expected_dur2) < 1e-8

@pytest.mark.skipif(not HAS_HIGHS, reason="HiGHS solver required")
def test_integrity_single_resource_exclusivity():
    """Verify that multiple simultaneous arrivals never share a slot or overlap in time."""
    solver = BasilOptSolver(time_limit_s=5.0)
    pkts = [
        {"id": i, "device_id": i % 4, "size_bytes": 1024, "arrive_time_s": 0.001, "deadline_s": 0.015, "semantic_importance": 1.0 - 0.05 * i}
        for i in range(12)
    ]
    res = solver.solve_slotted(
        pkts, num_devices=4, simulation_time_s=0.015, data_rate_mbps=15.0, packet_size_bytes=1024, device_per=[0.0]*4
    )
    assert res["status"] == "Optimal"
    slots = [p["slot_index"] for p in res["schedule"]]
    # All slot indices must be strictly unique
    assert len(slots) == len(set(slots))
    # Arrival causality check: all scheduled start times >= packet arrive time
    for p in res["schedule"]:
        orig = next(orig for orig in pkts if orig["id"] == p["packet_id"])
        assert p["scheduled_start_s"] >= orig["arrive_time_s"] - 1e-9
        assert p["scheduled_end_s"] <= orig["deadline_s"] + 1e-9

@pytest.mark.skipif(not HAS_HIGHS, reason="HiGHS solver required")
def test_integrity_objective_value_formula_verification():
    """Verify that the reported objective value matches the mathematical definition."""
    solver = BasilOptSolver(time_limit_s=5.0)
    pkts = [
        {"id": 1, "device_id": 0, "size_bytes": 1024, "arrive_time_s": 0.0, "deadline_s": 0.005, "semantic_importance": 0.80},
    ]
    res = solver.solve_slotted(
        pkts, num_devices=1, simulation_time_s=0.005, data_rate_mbps=15.0, packet_size_bytes=1024, device_per=[0.0]
    )
    assert res["status"] == "Optimal"
    assert res["mip_gap"] == 0.0
    p = res["schedule"][0]
    expected_bits = 0.80 * (1024 * 8.0) * (1.0 - 0.0)
    latency_s = p["scheduled_end_s"] - pkts[0]["arrive_time_s"]
    expected_obj = expected_bits - 1e-6 * latency_s
    assert abs(res["objective_value"] - expected_obj) < 1e-3
