import pytest
import numpy as np
from app.algorithms.basil_opt import BasilOptSolver, packet_channel_draw

def test_packet_parity_optical_channel_loss_consistency():
    """
    Verify that BASIL-OPT with stochastic channel replay correctly accounts
    for physical optical channel losses when scheduling packets to devices with non-zero PER,
    rather than falsely reporting zero channel losses.
    """
    solver = BasilOptSolver(time_limit_s=5.0)
    
    # 4 packets: 2 to reliable device 0 (PER=0.0), 2 to degraded device 1 (PER=0.50)
    packets = [
        {"id": 1, "device_id": 0, "size_bytes": 1024, "arrive_time_s": 0.000, "deadline_s": 0.010, "priority": 1, "semantic_importance": 0.8},
        {"id": 2, "device_id": 0, "size_bytes": 1024, "arrive_time_s": 0.001, "deadline_s": 0.010, "priority": 1, "semantic_importance": 0.8},
        {"id": 3, "device_id": 1, "size_bytes": 1024, "arrive_time_s": 0.002, "deadline_s": 0.010, "priority": 1, "semantic_importance": 0.8},
        {"id": 4, "device_id": 1, "size_bytes": 1024, "arrive_time_s": 0.003, "deadline_s": 0.010, "priority": 1, "semantic_importance": 0.8},
    ]
    dev_per = [0.0, 0.50]
    
    # Solve with replay seed 42
    res = solver.solve_slotted(
        packets=packets,
        num_devices=2,
        simulation_time_s=0.010,
        data_rate_mbps=10.0,
        packet_size_bytes=1024,
        device_per=dev_per,
        replay_seed=42,
    )
    
    # All 4 packets are scheduled because q_1 = 0.50 > 0 gives positive reward
    assert res["scheduled_packets_count"] == 4
    assert res["scheduling_coverage_pct"] == 100.0
    
    # Analytical expected delivery: 2 * 1.0 + 2 * 0.50 = 3.0 packets
    assert abs(res["expected_delivered_packets"] - 3.0) < 1e-6
    assert abs(res["expected_received_pdr_pct"] - 75.0) < 1e-4
    
    # Check individual SplitMix64 draws for packet 3 and 4 on device 1:
    draw3 = packet_channel_draw(42, 3, 1)
    draw4 = packet_channel_draw(42, 4, 1)
    success3 = bool(draw3 >= 0.50)
    success4 = bool(draw4 >= 0.50)
    exp_lost = (1 if not success3 else 0) + (1 if not success4 else 0)
    
    # Realized channel losses must match individual packet outcomes exactly
    assert res["realized_lost_channel"] == exp_lost
    assert res["realized_delivered_on_time"] == (4 - exp_lost)
    assert res["realized_received_pdr"] == (4 - exp_lost) / 4.0
    
    # Expected PDR and Realized PDR are separate calculations and NOT forced to match
    assert "expected_received_pdr" in res
    assert "realized_received_pdr" in res


def test_independent_pdr_calculations_divergence():
    """
    Verify that expected received PDR and realized received PDR are computed
    independently and reflect natural Bernoulli variance rather than being hardcoded/copied.
    """
    solver = BasilOptSolver(time_limit_s=5.0)
    # Generate 10 packets to a channel with PER = 0.30
    packets = [
        {"id": i, "device_id": 1, "size_bytes": 1024, "arrive_time_s": i * 0.001, "deadline_s": 0.050, "priority": 1, "semantic_importance": 0.5}
        for i in range(1, 11)
    ]
    dev_per = [0.0, 0.30]
    
    res = solver.solve_slotted(
        packets=packets,
        num_devices=2,
        simulation_time_s=0.020,
        data_rate_mbps=10.0,
        packet_size_bytes=1024,
        device_per=dev_per,
        replay_seed=123,
    )
    
    # Expected PDR is mathematically exact: 10 * (1 - 0.30) / 10 = 0.70 (70.0%)
    assert abs(res["expected_received_pdr"] - 0.70) < 1e-6
    
    # Realized PDR is integer successes / 10
    realized_succ = res["realized_delivered_on_time"]
    assert res["realized_received_pdr"] == realized_succ / 10.0
    
    # Verify exact mutually exclusive 5-way conservation:
    assert res["total_packets_generated"] == (
        res["realized_delivered_on_time"] +
        res["delivered_late"] +
        res["realized_lost_channel"] +
        res["dropped_queue"] +
        res["pending_queue"]
    )


def test_optimizer_information_boundary():
    """
    Verify that BASIL-OPT objective only uses expected reliability q_d = 1 - PER_d,
    and does not access realized channel draws during decision making.
    """
    solver = BasilOptSolver(time_limit_s=5.0)
    # Two competing packets for 1 slot
    packets = [
        {"id": 1, "device_id": 0, "size_bytes": 1024, "arrive_time_s": 0.0, "deadline_s": 0.002, "priority": 2, "semantic_importance": 0.8},
        {"id": 2, "device_id": 1, "size_bytes": 1024, "arrive_time_s": 0.0, "deadline_s": 0.002, "priority": 2, "semantic_importance": 0.8},
    ]
    # Device 0 has higher reliability (q=0.9), Device 1 has lower reliability (q=0.5)
    dev_per = [0.10, 0.50]
    
    # Suppose by random draw, packet 1 would fail (draw < 0.10) while packet 2 would succeed
    # An oracle that peeks at realizations would pick packet 2.
    # An expectation-based optimizer MUST pick packet 1 because 0.8 * 0.9 = 0.72 > 0.8 * 0.5 = 0.40!
    res = solver.solve_slotted(
        packets=packets,
        num_devices=2,
        simulation_time_s=0.0015,  # Only 1 slot available!
        data_rate_mbps=10.0,
        packet_size_bytes=1024,
        device_per=dev_per,
        replay_seed=999,
    )
    
    sched = res["schedule"]
    assert len(sched) == 1
    # Must choose packet 1 due to higher expected reliability
    assert sched[0]["packet_id"] == 1
    assert sched[0]["device_id"] == 0
