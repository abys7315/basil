import pytest
import numpy as np
from app.algorithms.basil_opt import BasilOptSolver

def test_accounting_minimal_deterministic_scenario():
    """
    Deterministic 2-device, 4-packet scenario with hand-calculated ground truth.
    - Device 0: PER = 0.0 (clean channel, reliability = 1.0)
    - Device 1: PER = 1.0 (dead channel, reliability = 0.0)
    
    Data rate: 10.0 Mbps, Packet size: 1024 bytes (8192 bits).
    Slot duration tau = 8192 / 1e7 = 0.0008192 s (0.8192 ms).
    Simulation time: 0.0016384 s (M = 2 slots: [0, 0.0008192], [0.0008192, 0.0016384]).
    
    Packets:
      P0: Dev 0, arr=0.0, ddl=0.0008192, w=1.0 (eligible for Slot 0)
      P1: Dev 1, arr=0.0, ddl=0.0008192, w=1.0 (competes for Slot 0, but PER=1.0 => 0 bits reward)
      P2: Dev 0, arr=0.0, ddl=0.0004000, w=1.0 (unachievable deadline < tau => 0 eligible slots)
      P3: Dev 0, arr=0.0005, ddl=0.0016384, w=0.5 (eligible for Slot 1)
      
    Analytical Ground Truth:
      - Slot 0: P0 scheduled (reward = 8192 bits vs P1's 0 bits)
      - Slot 1: P3 scheduled (reward = 4096 bits)
      - P1 intentionally unscheduled (dead channel)
      - P2 unscheduled (deadline impossible)
      - Generated K = 4
      - Delivered on time = 2 (P0, P3)
      - Pending queue = 2 (P1, P2)
      - Deadline misses = 2 (P1, P2 both had deadlines > 0 and were not delivered)
      - Deadline success rate = 2 / 4 = 50.0%
      - Scheduled PDR = 2 / 4 = 50.0%
      - Expected PDR = (1.0 + 1.0) / 4 = 50.0%
      - Semantic Goodput = (8192*1.0 + 8192*0.5) / (0.0016384 * 1e6) = 12288 / 1638.4 = 7.50 Mbps
      - Raw Goodput = (8192*1.0 + 8192*1.0) / (0.0016384 * 1e6) = 16384 / 1638.4 = 10.00 Mbps
    """
    tau = (1024 * 8.0) / 10e6 # 0.0008192 s
    packets = [
        {"id": 1, "device_id": 0, "arrive_time_s": 0.0, "deadline_s": tau, "semantic_importance": 1.0, "size_bytes": 1024, "priority": 3},
        {"id": 2, "device_id": 1, "arrive_time_s": 0.0, "deadline_s": tau, "semantic_importance": 1.0, "size_bytes": 1024, "priority": 3},
        {"id": 3, "device_id": 0, "arrive_time_s": 0.0, "deadline_s": 0.0004, "semantic_importance": 1.0, "size_bytes": 1024, "priority": 3},
        {"id": 4, "device_id": 0, "arrive_time_s": 0.0005, "deadline_s": 2 * tau, "semantic_importance": 0.5, "size_bytes": 1024, "priority": 2},
    ]

    solver = BasilOptSolver(time_limit_s=5.0)
    res = solver.solve_slotted(
        packets=packets,
        num_devices=2,
        simulation_time_s=2 * tau,
        data_rate_mbps=10.0,
        packet_size_bytes=1024,
        device_per=[0.0, 1.0]
    )

    assert res["is_optimal"] is True
    assert res["status"] in ["Optimal", "kOptimal"]

    # 1. Schedule correctness
    scheduled = res["schedule"]
    assert len(scheduled) == 2
    assert scheduled[0]["packet_id"] == 1
    assert scheduled[0]["slot_index"] == 0
    assert scheduled[1]["packet_id"] == 4
    assert scheduled[1]["slot_index"] == 1

    # 2. Denominator and conservation accounting
    assert res["total_packets_generated"] == 4
    assert res["total_packets_sent"] == 4
    assert res["delivered_on_time"] == 2
    assert res["delivered_late"] == 0
    assert res["lost_channel"] == 0
    assert res["dropped_queue"] == 0
    assert res["pending_queue"] == 2
    # Mutually exclusive sum must equal generated denominator exactly
    assert (res["delivered_on_time"] + res["delivered_late"] +
            res["lost_channel"] + res["dropped_queue"] + res["pending_queue"]) == res["total_packets_generated"]

    # 3. Deadline miss accounting
    assert res["total_deadline_misses"] == 2
    assert abs(res["deadline_success_rate"] - 0.50) < 1e-5

    # 4. PDR metrics
    assert abs(res["pdr"] - 0.50) < 1e-5
    assert abs(res["expected_pdr"] - 0.50) < 1e-5
    assert abs(res["expected_delivered_packets"] - 2.0) < 1e-5

    # 5. Goodput metrics
    assert abs(res["goodput_semantic_mbps"] - 7.50) < 1e-4
    assert abs(res["goodput_raw_mbps"] - 10.00) < 1e-4

def test_accounting_best_effort_unscheduled_does_not_count_as_deadline_miss():
    """
    Verify that unscheduled Best-Effort packets (deadline <= 0):
    1. Remain in the total_packets_generated denominator.
    2. Are counted in pending_queue.
    3. Do NOT increment total_deadline_misses (because they have no deadline to miss).
    """
    tau = (1024 * 8.0) / 10e6
    packets = [
        # 2 Clean deadline packets for Dev 0 (will be scheduled)
        {"id": 1, "device_id": 0, "arrive_time_s": 0.0, "deadline_s": tau, "semantic_importance": 1.0, "size_bytes": 1024, "priority": 3},
        {"id": 2, "device_id": 0, "arrive_time_s": 0.0005, "deadline_s": 2 * tau, "semantic_importance": 1.0, "size_bytes": 1024, "priority": 3},
        # 2 Best-Effort packets for Dev 1 (PER = 1.0 => refused)
        {"id": 3, "device_id": 1, "arrive_time_s": 0.0, "deadline_s": -1.0, "semantic_importance": 0.25, "size_bytes": 1024, "priority": 0},
        {"id": 4, "device_id": 1, "arrive_time_s": 0.0, "deadline_s": -1.0, "semantic_importance": 0.25, "size_bytes": 1024, "priority": 0},
    ]

    solver = BasilOptSolver(time_limit_s=5.0)
    res = solver.solve_slotted(
        packets=packets,
        num_devices=2,
        simulation_time_s=2 * tau,
        data_rate_mbps=10.0,
        packet_size_bytes=1024,
        device_per=[0.0, 1.0]
    )

    # Denominator must remain K = 4
    assert res["total_packets_generated"] == 4
    # Only 2 scheduled
    assert res["delivered_on_time"] == 2
    # Unscheduled BE packets must be in pending_queue
    assert res["pending_queue"] == 2
    # CRITICAL: Deadline misses must be 0, not 2! (P1 and P2 met deadlines, P3 and P4 had no deadlines)
    assert res["total_deadline_misses"] == 0
    assert abs(res["deadline_success_rate"] - 1.0) < 1e-5
    # PDR denominator is 4, so PDR is 2/4 = 50%
    assert abs(res["pdr"] - 0.50) < 1e-5

def test_accounting_bad_channel_refusal_mechanism():
    """
    Verify channel-aware refusal under contention:
    When 1 slot is contested by a low-priority clean packet vs high-nominal-weight dead-channel packet,
    BASIL-OPT chooses the clean channel packet to avoid 0-bit throughput waste.
    """
    tau = (1024 * 8.0) / 10e6
    packets = [
        # Dead channel packet (Dev 1, PER=1.0) with very high nominal semantic importance (1.0)
        {"id": 1, "device_id": 1, "arrive_time_s": 0.0, "deadline_s": tau, "semantic_importance": 1.0, "size_bytes": 1024, "priority": 3},
        # Clean channel packet (Dev 0, PER=0.0) with low nominal semantic importance (0.1)
        {"id": 2, "device_id": 0, "arrive_time_s": 0.0, "deadline_s": tau, "semantic_importance": 0.1, "size_bytes": 1024, "priority": 1},
    ]

    solver = BasilOptSolver(time_limit_s=5.0)
    res = solver.solve_slotted(
        packets=packets,
        num_devices=2,
        simulation_time_s=tau,
        data_rate_mbps=10.0,
        packet_size_bytes=1024,
        device_per=[0.0, 1.0]
    )

    scheduled = res["schedule"]
    assert len(scheduled) == 1
    # Packet 2 (clean channel) must win over Packet 1 (dead channel)
    assert scheduled[0]["packet_id"] == 2
    assert res["total_packets_generated"] == 2
    assert res["pending_queue"] == 1
    # Packet 1 missed its deadline because it wasn't scheduled
    assert res["total_deadline_misses"] == 1

def test_accounting_expected_vs_monte_carlo_convergence():
    """
    Verify analytical expectation vs empirical Monte Carlo relationship:
    Analytical expected delivery = sum(1 - PER_d).
    Empirical Bernoulli realizations over finite seeds deviate by O(sigma / sqrt(N)),
    explaining why online schedulers in finite seeds can occasionally exceed analytical expectation by <= 0.4%.
    """
    per = 0.59
    num_packets = 151
    expected_success = num_packets * (1.0 - per) # 61.91 packets
    std_dev = np.sqrt(num_packets * (1.0 - per) * per) # ~6.03 packets

    # Monte Carlo simulation of 5000 independent seeds of 151 Bernoulli trials
    rng = np.random.default_rng(42)
    trials = rng.binomial(n=num_packets, p=(1.0 - per), size=5000)

    # 1. Theoretical mean must match within sample error
    sample_mean = np.mean(trials)
    assert abs(sample_mean - expected_success) < 0.2

    # 2. Maximum empirical realization in finite seeds can easily exceed expected by several packets
    max_trial = np.max(trials)
    min_trial = np.min(trials)
    assert max_trial > expected_success + 2 * std_dev
    assert min_trial < expected_success - 2 * std_dev

    # In terms of percentage, max trial can exceed expectation by > 10% on finite sample
    max_exceed_pct = (max_trial - expected_success) / expected_success * 100.0
    assert max_exceed_pct > 15.0
