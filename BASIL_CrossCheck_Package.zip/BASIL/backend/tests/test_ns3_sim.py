import asyncio
import os
import json
from pathlib import Path
import pytest
from app.simulation.runner import SimulationRunner

def test_ns3_simulation_execution():
    """Verify that the official ns-3.42 Li-Fi simulator executes and outputs authentic ns-3 telemetry."""
    runner = SimulationRunner()
    
    config = {
        "num_devices": 3,
        "simulation_time": 1.0,
        "data_rate": 20.0,
        "scheduler": "BASIL_PSA",
        "traffic_mode": "burst",
        "burst_ratio": 0.2,
        "room_width": 5.0,
        "room_height": 3.0,
        "ap_power": 100.0,
        "half_angle": 60.0,
        "packet_size": 1024,
        "normal_rate": 100.0,
        "burst_rate": 400.0,
    }
    
    # Run using the ns3 engine inside WSL Ubuntu
    res = asyncio.run(runner.run(config, engine="ns3"))
    
    # 1. Assert engine is identified as ns3 with version 3.42
    assert res.get("engine") == "ns3", f"Expected engine 'ns3', got {res.get('engine')}"
    assert res.get("ns3_version") == "3.42", f"Expected ns3_version '3.42', got {res.get('ns3_version')}"
    assert res.get("scheduler") == "BASIL_PSA"
    
    # 2. Assert genuine packet counts and latency
    assert res.get("total_packets_sent", 0) > 0
    assert res.get("total_packets_delivered", 0) > 0
    assert res.get("packet_delivery_ratio", 0) > 0.0
    assert res.get("avg_latency_ms", 0) > 0.0
    assert res.get("throughput_mbps", 0) > 0.0
    assert 0.0 <= res.get("fairness_index", 0) <= 1.0
    
    # 3. Assert per-device physical optical telemetry
    devs = res.get("per_device_stats", [])
    assert len(devs) == 3
    # Check that SNR decreases with distance
    assert devs[0]["distance_m"] < devs[1]["distance_m"] < devs[2]["distance_m"]
    assert devs[0]["snr_db"] > devs[1]["snr_db"] > devs[2]["snr_db"]

def test_custom_simulation_execution():
    """Verify that the custom C++ prototype simulator remains available as an alternative engine."""
    runner = SimulationRunner()
    
    config = {
        "num_devices": 4,
        "simulation_time": 1.0,
        "data_rate": 10.0,
        "scheduler": "FIFO",
        "traffic_mode": "normal",
        "burst_ratio": 0.2,
        "room_width": 5.0,
        "room_height": 3.0,
        "ap_power": 100.0,
        "half_angle": 60.0,
        "packet_size": 1024,
        "normal_rate": 100.0,
        "burst_rate": 400.0,
    }
    
    res = asyncio.run(runner.run(config, engine="custom"))
    assert res.get("total_packets_sent", 0) > 0
    assert res.get("avg_latency_ms", 0) > 0.0

def test_burst_prediction_error_metrics():
    """Verify that BASIL-PSA computes and exports burst prediction MAE and RMSE metrics."""
    runner = SimulationRunner()
    config = {
        "num_devices": 4,
        "simulation_time": 1.5,
        "data_rate": 10.0,
        "scheduler": "BASIL_PSA",
        "traffic_mode": "burst",
        "burst_ratio": 0.3,
        "burst_rate": 400.0,
        "normal_rate": 80.0,
        "seed": 42
    }
    res = asyncio.run(runner.run(config, engine="ns3"))
    assert "burst_prediction_mae" in res, "Telemetry must include burst_prediction_mae"
    assert "burst_prediction_rmse" in res, "Telemetry must include burst_prediction_rmse"
    assert res["burst_prediction_mae"] >= 0.0
    assert res["burst_prediction_rmse"] >= 0.0
    assert res["burst_prediction_rmse"] >= res["burst_prediction_mae"], "RMSE must be >= MAE"

def test_semantic_importance_scheduling_impact():
    """Verify that semantic importance configuration alters scheduling and deadline behavior."""
    runner = SimulationRunner()
    base_config = {
        "num_devices": 4,
        "simulation_time": 1.5,
        "data_rate": 10.0,
        "scheduler": "BASIL_PSA",
        "traffic_mode": "burst",
        "burst_ratio": 0.35,
        "burst_rate": 350.0,
        "normal_rate": 80.0,
        "seed": 101
    }
    # With full semantic weighting enabled
    res_semantic = asyncio.run(runner.run(base_config, engine="ns3"))
    
    # With semantic weighting disabled via ablation
    config_no_sem = dict(base_config)
    config_no_sem["ablation_no_semantic"] = 1.0
    res_no_sem = asyncio.run(runner.run(config_no_sem, engine="ns3"))
    
    # Both runs should complete cleanly and report valid metrics
    assert res_semantic["avg_latency_ms"] > 0
    assert res_no_sem["avg_latency_ms"] > 0
    assert "p95_latency_ms" in res_semantic
    assert "p99_latency_ms" in res_semantic

def test_ablation_flags():
    """Verify that all ablation flags are accepted and executed properly."""
    runner = SimulationRunner()
    base_config = {
        "num_devices": 4,
        "simulation_time": 1.0,
        "data_rate": 10.0,
        "scheduler": "BASIL_PSA",
        "traffic_mode": "burst",
        "burst_ratio": 0.25,
        "burst_rate": 300.0,
        "normal_rate": 80.0,
        "seed": 777,
        "ablation_no_prediction": 1.0,
        "ablation_no_channel": 1.0,
        "ablation_no_fairness": 1.0
    }
    res = asyncio.run(runner.run(base_config, engine="ns3"))
    assert res["engine"] == "ns3"
    assert res["total_packets_sent"] > 0
    assert res["packet_delivery_ratio"] > 0.0

def test_5way_packet_accounting_conservation():
    """Verify the conservation law: total_generated == on_time + late + lost_channel + dropped_queue + pending_queue."""
    runner = SimulationRunner()
    config = {
        "num_devices": 4,
        "simulation_time": 1.5,
        "data_rate": 10.0,
        "scheduler": "BASIL_PSA",
        "traffic_mode": "burst",
        "burst_ratio": 0.3,
        "burst_rate": 400.0,
        "normal_rate": 80.0,
        "seed": 2024
    }
    res = asyncio.run(runner.run(config, engine="ns3"))
    gen = res["total_packets_generated"]
    on_time = res["delivered_on_time"]
    late = res["delivered_late"]
    lost_chan = res["lost_channel"]
    drop_q = res["dropped_queue"]
    pend_q = res["pending_queue"]
    
    assert gen > 0
    assert gen == (on_time + late + lost_chan + drop_q + pend_q), "Conservation law violated: sum does not match generated!"
    assert pytest.approx(res["pdr"], abs=1e-4) == (on_time + late) / gen, "PDR must equal total delivered / total generated"
    assert pytest.approx(res["packet_loss_rate"], abs=1e-4) == 1.0 - res["pdr"]

def test_semantic_goodput_and_per_class_metrics():
    """Verify that semantic goodput and 4-tier class performance are correctly recorded."""
    runner = SimulationRunner()
    config = {
        "num_devices": 4,
        "simulation_time": 1.5,
        "data_rate": 10.0,
        "scheduler": "BASIL_PSA",
        "traffic_mode": "burst",
        "burst_ratio": 0.3,
        "burst_rate": 400.0,
        "normal_rate": 80.0,
        "seed": 42
    }
    res = asyncio.run(runner.run(config, engine="ns3"))
    assert "goodput_semantic_mbps" in res
    assert "goodput_raw_mbps" in res
    assert res["goodput_semantic_mbps"] > 0.0
    assert res["goodput_raw_mbps"] >= res["goodput_semantic_mbps"]
    
    classes = res["per_class_stats"]
    assert len(classes) == 4
    # Class 3 (Emergency) should achieve lower latency than Class 0 (Best-effort)
    c3 = next(c for c in classes if c["class_id"] == 3)
    c0 = next(c for c in classes if c["class_id"] == 0)
    assert c3["avg_latency_ms"] < c0["avg_latency_ms"], "Emergency class must experience lower latency than best-effort!"

def test_burst_prediction_baselines_comparison():
    """Verify that EWMA predictor is benchmarked against Persistence and Static baselines."""
    runner = SimulationRunner()
    config = {
        "num_devices": 4,
        "simulation_time": 1.5,
        "data_rate": 10.0,
        "scheduler": "BASIL_PSA",
        "traffic_mode": "burst",
        "burst_ratio": 0.3,
        "burst_rate": 400.0,
        "normal_rate": 80.0,
        "seed": 101
    }
    res = asyncio.run(runner.run(config, engine="ns3"))
    assert "burst_prediction_mae" in res
    assert "persistence_baseline_mae" in res
    assert "static_baseline_mae" in res
    assert res["persistence_baseline_mae"] >= 0.0
    assert res["static_baseline_mae"] >= 0.0

def test_cusum_predictor_execution():
    """Verify CUSUM change-point detector execution and bounded RMSE."""
    runner = SimulationRunner()
    config = {
        "num_devices": 4,
        "simulation_time": 1.5,
        "data_rate": 10.0,
        "scheduler": "BASIL_PSA",
        "predictor_type": "cusum",
        "traffic_mode": "burst",
        "burst_ratio": 0.3,
        "burst_rate": 400.0,
        "normal_rate": 80.0,
        "seed": 42
    }
    res = asyncio.run(runner.run(config, engine="ns3"))
    assert "burst_prediction_mae" in res
    assert "burst_prediction_rmse" in res
    # CUSUM RMSE should be strictly bounded (well below 25, eliminating the old 118 error)
    assert res["burst_prediction_rmse"] < 25.0
    assert res["burst_prediction_mae"] < 20.0

def test_coverage_mode_viable_disentanglement():
    """Verify that viable coverage mode maintains high Jain fairness and high PDR on 16 devices."""
    runner = SimulationRunner()
    config = {
        "num_devices": 16,
        "simulation_time": 1.0,
        "data_rate": 10.0,
        "scheduler": "BASIL_PSA",
        "traffic_mode": "burst",
        "coverage_mode": "viable",
        "burst_ratio": 0.25,
        "burst_rate": 120.0,
        "normal_rate": 30.0,
        "seed": 42
    }
    res = asyncio.run(runner.run(config, engine="ns3"))
    assert res["pdr"] > 0.95, f"Expected viable coverage PDR > 0.95, got {res['pdr']}"
    assert res["jain_fairness_index"] > 0.95, f"Expected viable coverage Jain fairness > 0.95, got {res['jain_fairness_index']}"

def test_controlled_semantic_experiments():
    """Verify controlled traffic modes: semantic_equal_deadlines and semantic_conflict_urgency."""
    runner = SimulationRunner()
    for mode in ["semantic_equal_deadlines", "semantic_conflict_urgency"]:
        config = {
            "num_devices": 4,
            "simulation_time": 1.0,
            "data_rate": 10.0,
            "scheduler": "BASIL_PSA",
            "traffic_mode": mode,
            "seed": 101
        }
        res = asyncio.run(runner.run(config, engine="ns3"))
        assert res["total_packets_sent"] > 0
        assert "per_class_stats" in res
        assert len(res["per_class_stats"]) == 4

def test_experiment_manifest_reconciliation():
    """Verify that the Phase 2.2 experiment manifest exists and records hundreds of successful runs."""
    manifest_path = Path(__file__).resolve().parent.parent.parent / "experiments" / "phase2_2_experiment_manifest.json"
    assert manifest_path.exists(), "Experiment manifest must exist"
    with open(manifest_path, "r") as f:
        data = json.load(f)
    assert data["total_runs"] >= 600
    assert data["failed_runs"] == 0
    assert data["successful_runs"] == data["total_runs"]


