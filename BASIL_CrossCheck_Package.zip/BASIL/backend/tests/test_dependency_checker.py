"""
Tests for BASIL Runtime Dependency Validation Service & Endpoint (Phase 4.2).
Verifies tiered dependency checks, core vs simulation runtime, and REST API.
"""

import pytest
from fastapi.testclient import TestClient

from app.main import app
from app.services.dependency_checker import (
    check_webview2,
    check_python_runtime,
    check_core_backend_packages,
    check_dev_packages,
    check_runtime_rust,
    check_wsl2,
    check_ubuntu_distro,
    check_ns3_executable,
    check_filesystem_writability,
    run_all_dependency_checks,
)

client = TestClient(app, raise_server_exceptions=True)


def test_dependency_checker_unit_checks():
    """Verify individual unit check structures conform to specification."""
    # WebView2
    wv = check_webview2()
    assert "name" in wv
    assert wv["category"] in ("runtime", "core_runtime")
    assert wv["status"] in ("installed", "missing", "not_applicable")

    # Python
    py = check_python_runtime()
    assert py["category"] in ("runtime", "core_runtime")
    assert py["status"] in ("installed", "incompatible")
    assert py["version"] is not None

    # Core Backend packages (fastapi, uvicorn, sqlalchemy, etc.)
    pkgs = check_core_backend_packages()
    assert len(pkgs) >= 9
    for p in pkgs:
        assert p["category"] in ("python_package", "core_runtime")
        assert p["status"] in ("installed", "missing")

    # Dev packages (pytest) - separated from core runtime
    dev_pkgs = check_dev_packages()
    assert len(dev_pkgs) >= 1
    assert dev_pkgs[0]["category"] == "development_tools"

    # Runtime Rust
    rust = check_runtime_rust()
    assert rust["category"] in ("runtime", "development_tools")
    assert rust["status"] == "not_required"

    # WSL2
    wsl = check_wsl2()
    assert wsl["category"] in ("wsl_ns3", "simulation_runtime")
    assert wsl["status"] in ("installed", "missing", "not_applicable")

    # Ubuntu
    ub = check_ubuntu_distro()
    assert ub["category"] in ("wsl_ns3", "simulation_runtime")
    assert ub["status"] in ("installed", "missing", "not_applicable")

    # ns3
    ns3 = check_ns3_executable()
    assert ns3["category"] in ("wsl_ns3", "simulation_runtime")
    assert ns3["status"] in ("installed", "missing")

    # Filesystem
    fs = check_filesystem_writability()
    assert fs["category"] in ("storage", "core_runtime")
    assert fs["status"] in ("installed", "incompatible")


def test_run_all_dependency_checks_aggregation():
    """Verify full aggregation summary format and tier separation."""
    res = run_all_dependency_checks()
    assert "core_runtime_ready" in res
    assert "simulation_runtime_ready" in res
    assert "development_ready" in res
    assert "all_ready" in res
    assert "summary" in res
    assert "dependencies" in res
    assert res["summary"]["total_checks"] == len(res["dependencies"])
    assert res["summary"]["total_checks"] >= 17
    assert isinstance(res["core_runtime_ready"], bool)
    assert isinstance(res["all_ready"], bool)


def test_system_dependencies_endpoint():
    """Verify GET /api/system/dependencies endpoint returns 200 with structured JSON."""
    response = client.get("/api/system/dependencies")
    assert response.status_code == 200
    data = response.json()
    assert "core_runtime_ready" in data
    assert "simulation_runtime_ready" in data
    assert "all_ready" in data
    assert "summary" in data
    assert "dependencies" in data
    assert data["summary"]["total_checks"] >= 17
    # Verify each dependency specifies deployment_nature and category
    for dep in data["dependencies"]:
        assert "category" in dep
        assert "deployment_nature" in dep
        if dep["status"] in ("missing", "incompatible"):
            assert dep["action_required"] is not None
