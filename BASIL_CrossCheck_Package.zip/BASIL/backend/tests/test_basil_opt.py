import asyncio
import pytest
import numpy as np
from app.algorithms.basil_opt import BasilOptSolver
from app.simulation.runner import SimulationRunner

def test_basil_opt_solver_feasibility_manual_instance():
    """Verify that BasilOptSolver finds the optimal schedule for a known 3-packet scenario."""
    solver = BasilOptSolver()
    
    # 3 packets:
    # Slot size: 1024 * 8 / (10e6) = 0.0008192s (~0.8192 ms)
    # Packet 0 arrives at 0.000s, deadline at 0.002s, weight 0.9 (Device 0)
    # Packet 1 arrives at 0.000s, deadline at 0.001s, weight 0.3 (Device 1)
    # Packet 2 arrives at 0.001s, deadline at 0.003s, weight 0.7 (Device 0)
    packets = [
        {"id": 1, "device_id": 0, "arrive_time_s": 0.000, "deadline_s": 0.002, "semantic_importance": 0.9, "priority": 3, "size_bytes": 1024},
        {"id": 2, "device_id": 1, "arrive_time_s": 0.000, "deadline_s": 0.001, "semantic_importance": 0.3, "priority": 1, "size_bytes": 1024},
        {"id": 3, "device_id": 0, "arrive_time_s": 0.001, "deadline_s": 0.003, "semantic_importance": 0.7, "priority": 2, "size_bytes": 1024},
    ]
    
    res = solver.solve_slotted(
        packets=packets,
        num_devices=2,
        simulation_time_s=0.01,
        data_rate_mbps=10.0,
        packet_size_bytes=1024,
        device_per=[0.0, 0.0]
    )
    
    assert res["status"] in ["Optimal", "Optimization terminated successfully"]
    assert res["is_optimal"] is True
    assert res["mip_gap"] <= 1e-4
    assert res["delivered_on_time"] == 3
    assert len(res["schedule"]) == 3
    
    # Check causality and deadline for each scheduled item
    pkt_dict = {p["id"]: p for p in packets}
    for item in res["schedule"]:
        orig = pkt_dict[item["packet_id"]]
        assert item["scheduled_start_s"] >= orig["arrive_time_s"] - 1e-9
        assert item["scheduled_end_s"] <= orig["deadline_s"] + 1e-9

def test_basil_opt_uniqueness_and_exclusivity():
    """Verify packet uniqueness and single-channel exclusivity constraints."""
    solver = BasilOptSolver()
    
    # 5 packets arriving simultaneously at t=0, each needing 1 slot
    # Total time allows 3 slots (t=0.0024576s)
    # All have deadline t=0.0025s
    packets = [
        {"id": i, "device_id": i % 2, "arrive_time_s": 0.0, "deadline_s": 0.0025, "semantic_importance": (i + 1) * 0.1, "priority": i, "size_bytes": 1024}
        for i in range(1, 6)
    ]
    
    res = solver.solve_slotted(
        packets=packets,
        num_devices=2,
        simulation_time_s=0.0025,
        data_rate_mbps=10.0,
        packet_size_bytes=1024,
        device_per=[0.0, 0.0]
    )
    
    assert res["is_optimal"] is True
    # At most 3 slots available in 0.0025s (0.0025 / 0.0008192 = 3.05)
    assert res["delivered_on_time"] == 3
    assert len(res["schedule"]) == 3
    
    # Check uniqueness: each packet scheduled at most once
    scheduled_ids = [item["packet_id"] for item in res["schedule"]]
    assert len(scheduled_ids) == len(set(scheduled_ids))
    
    # Check slot exclusivity: each slot occupied at most once
    slots_used = [item["slot_index"] for item in res["schedule"]]
    assert len(slots_used) == len(set(slots_used))
    
    # Because solver maximizes semantic goodput, it should pick the top 3 highest weights: id=5 (0.5), id=4 (0.4), id=3 (0.3)
    assert set(scheduled_ids) == {3, 4, 5}

def test_basil_opt_channel_reliability_weighting():
    """Verify that the solver accounts for channel reliability (PER) when prioritizing."""
    solver = BasilOptSolver()
    
    # 2 packets competing for 1 available slot:
    # Packet 1 (Device 0, PER = 0.0 -> reliability = 1.0): weight 0.8
    # Packet 2 (Device 1, PER = 0.7 -> reliability = 0.3): weight 0.9
    # Expected semantic bit delivery:
    # Pkt 1: 0.8 * 8192 * 1.0 = 6553.6
    # Pkt 2: 0.9 * 8192 * 0.3 = 2211.84
    # The solver should choose Packet 1 despite Packet 2 having higher raw semantic weight!
    packets = [
        {"id": 1, "device_id": 0, "arrive_time_s": 0.0, "deadline_s": 0.001, "semantic_importance": 0.8, "priority": 1, "size_bytes": 1024},
        {"id": 2, "device_id": 1, "arrive_time_s": 0.0, "deadline_s": 0.001, "semantic_importance": 0.9, "priority": 2, "size_bytes": 1024},
    ]
    
    res = solver.solve_slotted(
        packets=packets,
        num_devices=2,
        simulation_time_s=0.001,
        data_rate_mbps=10.0,
        packet_size_bytes=1024,
        device_per=[0.0, 0.7] # Device 1 has heavy PER
    )
    
    assert res["is_optimal"] is True
    assert res["delivered_on_time"] == 1
    assert res["schedule"][0]["packet_id"] == 1 # Correctly chose Packet 1

def test_basil_opt_continuous_formulation():
    """Verify that solve_continuous produces an optimal schedule matching solve_slotted."""
    solver = BasilOptSolver()
    
    packets = [
        {"id": 1, "device_id": 0, "arrive_time_s": 0.000, "deadline_s": 0.002, "semantic_importance": 0.9, "priority": 3, "size_bytes": 1024},
        {"id": 2, "device_id": 1, "arrive_time_s": 0.001, "deadline_s": 0.003, "semantic_importance": 0.6, "priority": 2, "size_bytes": 1024},
    ]
    
    res_cont = solver.solve_continuous(
        packets=packets,
        simulation_time_s=0.01,
        data_rate_mbps=10.0,
        packet_size_bytes=1024,
        device_per=[0.0, 0.0]
    )
    
    assert res_cont["status"] in ["Optimal", "Optimization terminated successfully"]
    assert res_cont["is_optimal"] is True
    assert res_cont["delivered_on_time"] == 2
    
    # Verify causality and non-overlap
    s0 = res_cont["schedule"][0]
    s1 = res_cont["schedule"][1]
    assert s0["scheduled_start_s"] >= packets[s0["packet_id"] - 1]["arrive_time_s"]
    assert s1["scheduled_start_s"] >= packets[s1["packet_id"] - 1]["arrive_time_s"]
    # Check non-overlap: min difference >= tx_duration (0.0008192s)
    assert abs(s1["scheduled_start_s"] - s0["scheduled_start_s"]) >= 0.0008192 - 1e-6

def test_simulation_runner_basil_opt_integration():
    """Verify end-to-end execution of BASIL_OPT via SimulationRunner."""
    runner = SimulationRunner()
    
    config = {
        "num_devices": 3,
        "simulation_time": 0.5,
        "data_rate": 20.0,
        "scheduler": "BASIL_OPT",
        "traffic_mode": "burst",
        "burst_ratio": 0.3,
        "packet_size": 1024,
        "normal_rate": 80.0,
        "burst_rate": 300.0,
        "seed": 42
    }
    
    res = asyncio.run(runner.run(config, engine="ns3"))
    
    assert res["scheduler"] == "BASIL_OPT"
    assert res["status"] in ["Optimal", "Optimization terminated successfully"]
    assert res["is_optimal"] is True
    assert res["mip_gap"] <= 1e-4
    assert res["total_packets_delivered"] > 0
    assert res["goodput_semantic_mbps"] > 0.0
    assert res["execution_time_s"] > 0.0
    
    # Check packet conservation law
    assert (
        res["delivered_on_time"]
        + res["delivered_late"]
        + res["lost_channel"]
        + res["dropped_queue"]
        + res["pending_queue"]
    ) == res["total_packets_generated"]
