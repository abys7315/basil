"""
Tests for the BASIL FastAPI backend.
Run with: pytest tests/test_api.py -v
"""
import asyncio
import pytest
from fastapi.testclient import TestClient

from app.database import init_db
from app.main import app


@pytest.fixture(scope="session", autouse=True)
def setup_db():
    """Create all tables before any tests run (sync wrapper for async init_db)."""
    asyncio.get_event_loop().run_until_complete(init_db())


client = TestClient(app, raise_server_exceptions=True)


def test_health():
    """GET /health should return 200 and status ok."""
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


def test_create_network_config(setup_db):
    """POST /api/network-configs should create a config and return 201."""
    payload = {
        "name": "Test Network",
        "num_devices": 4,
        "room_width": 5.0,
        "room_height": 3.0,
        "ap_power": 10.0,
        "half_angle": 60.0,
        "data_rate_mbps": 100.0,
    }
    response = client.post("/api/network-configs", json=payload)
    assert response.status_code == 201
    data = response.json()
    assert data["name"] == "Test Network"
    assert data["num_devices"] == 4
    assert "id" in data


def test_create_traffic_config(setup_db):
    """POST /api/traffic-configs should create a config and return 201."""
    payload = {
        "name": "Test Traffic",
        "traffic_mode": "mixed",
        "normal_rate": 1.0,
        "burst_rate": 5.0,
        "burst_ratio": 0.2,
        "packet_size": 1024,
    }
    response = client.post("/api/traffic-configs", json=payload)
    assert response.status_code == 201
    data = response.json()
    assert data["name"] == "Test Traffic"
    assert data["traffic_mode"] == "mixed"
    assert "id" in data


def test_create_experiment(setup_db):
    """POST /api/experiments should create an experiment referencing valid configs."""
    # Create prerequisite network config
    nc = client.post(
        "/api/network-configs",
        json={
            "name": "ExpNet",
            "num_devices": 2,
            "room_width": 4.0,
            "room_height": 3.0,
            "ap_power": 8.0,
            "half_angle": 45.0,
            "data_rate_mbps": 50.0,
        },
    ).json()

    # Create prerequisite traffic config
    tc = client.post(
        "/api/traffic-configs",
        json={
            "name": "ExpTraffic",
            "traffic_mode": "constant",
            "normal_rate": 2.0,
            "burst_rate": 4.0,
            "burst_ratio": 0.1,
            "packet_size": 512,
        },
    ).json()

    payload = {
        "name": "My Experiment",
        "network_config_id": nc["id"],
        "traffic_config_id": tc["id"],
        "scheduler": "FIFO",
        "simulation_time": 10.0,
    }
    response = client.post("/api/experiments", json=payload)
    assert response.status_code == 201
    data = response.json()
    assert data["name"] == "My Experiment"
    assert data["status"] == "pending"
    assert "id" in data


def test_list_algorithms():
    """GET /api/algorithms should return a non-empty list of algorithm descriptors."""
    response = client.get("/api/algorithms")
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, list)
    assert len(data) >= 1
    ids = [item["id"] for item in data]
    assert "FIFO" in ids
    assert "BASIL_PSA" in ids


def test_simulation_workflow_and_export(setup_db):
    """End-to-end test: create configs, experiment, simulate, and export CSV/JSON."""
    nc = client.post(
        "/api/network-configs",
        json={
            "name": "E2ENet",
            "num_devices": 2,
            "room_width": 4.0,
            "room_height": 3.0,
            "ap_power": 100.0,
            "half_angle": 60.0,
            "data_rate_mbps": 10.0,
        },
    ).json()

    tc = client.post(
        "/api/traffic-configs",
        json={
            "name": "E2ETraffic",
            "traffic_mode": "normal",
            "normal_rate": 50.0,
            "burst_rate": 50.0,
            "burst_ratio": 0.0,
            "packet_size": 1024,
        },
    ).json()

    exp = client.post(
        "/api/experiments",
        json={
            "name": "E2E Experiment",
            "network_config_id": nc["id"],
            "traffic_config_id": tc["id"],
            "scheduler": "FIFO",
            "simulation_time": 0.5,
            "engine": "custom",
        },
    ).json()
    exp_id = exp["id"]

    # Run simulation
    sim_res = client.post(f"/api/simulate/{exp_id}")
    assert sim_res.status_code == 200
    res_data = sim_res.json()
    assert res_data["experiment_id"] == exp_id
    assert "avg_latency_ms" in res_data
    assert "throughput_mbps" in res_data

    # Test GET /api/results/{exp_id}
    res_get = client.get(f"/api/results/{exp_id}")
    assert res_get.status_code == 200
    assert res_get.json()["experiment_id"] == exp_id

    # Test CSV export
    csv_resp = client.get(f"/api/results/{exp_id}/export")
    assert csv_resp.status_code == 200
    assert "text/csv" in csv_resp.headers["content-type"]
    assert f"filename=experiment_{exp_id}.csv" in csv_resp.headers["content-disposition"]
    assert len(csv_resp.text) > 0

    # Test JSON export via /export/json
    json_resp = client.get(f"/api/results/{exp_id}/export/json")
    assert json_resp.status_code == 200
    assert "application/json" in json_resp.headers["content-type"]
    assert f"filename=experiment_{exp_id}.json" in json_resp.headers["content-disposition"]
    json_data = json_resp.json()
    assert json_data["experiment_id"] == exp_id

    # Test JSON export via /export?format=json
    json_fmt_resp = client.get(f"/api/results/{exp_id}/export?format=json")
    assert json_fmt_resp.status_code == 200
    assert "application/json" in json_fmt_resp.headers["content-type"]
