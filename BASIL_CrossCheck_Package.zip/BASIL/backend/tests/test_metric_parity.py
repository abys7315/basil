import pytest
import numpy as np
from app.algorithms.basil_opt import BasilOptSolver

def test_metric_parity_five_invariants():
    """
    Test proving all five core research-integrity invariants:
    1. A packet transmitted before its deadline but lost due to PER is NOT a scheduling deadline miss.
    2. The same packet IS an end-to-end deadline failure.
    3. A packet never transmitted before its deadline IS a scheduling deadline miss.
    4. An unscheduled best-effort packet without a deadline is NOT counted as a deadline miss.
    5. Generated-packet conservation is maintained across both expected and realized quantities.
    """
    data_rate_mbps = 10.0
    packet_size_bytes = 1024
    tau = (packet_size_bytes * 8.0) / (data_rate_mbps * 1e6) # 0.0008192 s
    
    # 2 Slots available: [0, tau], [tau, 2tau]
    sim_time_s = 2 * tau

    # Device 0: clean channel (PER = 0.0, rel = 1.0)
    # Device 1: lossy channel (PER = 0.999, rel = 0.001)
    packets = [
        # P1: Dev 0 (PER=0.0), arr=0.0, ddl=tau, w=1.0. Fits in Slot 0. Clean reception.
        {"id": 1, "device_id": 0, "arrive_time_s": 0.0, "deadline_s": tau, "semantic_importance": 1.0, "size_bytes": 1024, "priority": 3},
        
        # P2: Dev 1 (PER=0.999), arr=tau, ddl=2*tau, w=1.0.
        # Transmitted in Slot 1 before its deadline 2*tau! But lost on channel due to PER.
        {"id": 2, "device_id": 1, "arrive_time_s": tau, "deadline_s": 2 * tau, "semantic_importance": 1.0, "size_bytes": 1024, "priority": 2},
        
        # P3: Dev 0 (PER=0.0), arr=0.0, ddl=0.0002.
        # Infeasible deadline (ddl < tau). Cannot be scheduled before deadline.
        {"id": 3, "device_id": 0, "arrive_time_s": 0.0, "deadline_s": 0.0002, "semantic_importance": 1.0, "size_bytes": 1024, "priority": 3},
        
        # P4: Dev 1 (PER=0.999), arr=tau, ddl=-1.0 (Best Effort, NO deadline).
        # Competing with P2 for Slot 1; P2 has higher weight (1.0 vs 0.25), so P4 is left unscheduled.
        {"id": 4, "device_id": 1, "arrive_time_s": tau, "deadline_s": -1.0, "semantic_importance": 0.25, "size_bytes": 1024, "priority": 0},
    ]

    solver = BasilOptSolver(time_limit_s=5.0)
    res = solver.solve_slotted(
        packets=packets,
        num_devices=2,
        simulation_time_s=sim_time_s,
        data_rate_mbps=data_rate_mbps,
        packet_size_bytes=packet_size_bytes,
        device_per=[0.0, 0.999],
        replay_seed=42
    )

    # Schedule inspection
    scheduled_ids = {p["packet_id"] for p in res["schedule"]}
    assert 1 in scheduled_ids # P1 scheduled in Slot 0
    assert 2 in scheduled_ids # P2 scheduled in Slot 1 (transmitted before deadline 2*tau)
    assert 3 not in scheduled_ids # P3 unachievable deadline
    assert 4 not in scheduled_ids # P4 unscheduled best-effort

    # --- INVARIANT 1: P2 transmitted before deadline is NOT a scheduling deadline miss ---
    # Only P3 missed scheduling deadline. P1 and P2 were scheduled before their deadlines.
    assert res["scheduling_deadline_misses"] == 1, (
        f"Expected exactly 1 scheduling deadline miss (P3), got {res['scheduling_deadline_misses']}"
    )

    # --- INVARIANT 2: P2 is an end-to-end deadline failure due to PER ---
    # Expected e2e failures: P3 (unscheduled, 1.0) + P2 (scheduled with PER=0.999 => 0.999) + P1 (PER=0.0 => 0.0) = 1.999
    assert abs(res["expected_end_to_end_deadline_failures"] - 1.999) < 1e-3
    # Realized e2e failures (Seed 42 Monte Carlo replay):
    # P3 unscheduled (1) + P2 lost on channel (1) = 2 realized failures
    assert res["realized_end_to_end_deadline_failures"] == 2
    assert res["realized_lost_channel"] == 1

    # --- INVARIANT 3: P3 never transmitted before deadline IS a scheduling deadline miss ---
    # Verified by scheduling_deadline_misses == 1 above.

    # --- INVARIANT 4: Unscheduled Best-Effort P4 is NOT counted as a deadline miss ---
    # Total packets generated = 4. Packets with deadline = 3 (P1, P2, P3).
    # If P4 had been counted, misses would be 2. Since misses == 1, P4 is NOT counted.
    assert res["total_packets_generated"] == 4
    assert res["pending_queue"] == 2 # P3 and P4 in pending queue
    assert res["scheduling_deadline_misses"] == 1

    # --- INVARIANT 5: Generated-Packet Conservation is maintained ---
    # Total generated denominator = 4
    N_gen = res["total_packets_generated"]
    assert N_gen == 4
    # Realized conservation: Delivered On-Time (1: P1) + Channel Lost (1: P2) + Pending (2: P3, P4) = 4
    assert res["realized_delivered_on_time"] + res["realized_lost_channel"] + res["pending_queue"] == N_gen
    # Expected conservation: Expected Delivered (1.001) + Expected Channel Loss (0.999) + Pending (2) = 4
    assert abs(res["expected_delivered_packets"] + res["expected_channel_losses"] + res["pending_queue"] - N_gen) < 1e-5


def test_metric_parity_distinction_labels():
    """
    Verify that BASIL-OPT outputs distinct, unambiguous labels for:
    - scheduling_deadline_misses (integer)
    - expected_end_to_end_deadline_failures (float)
    - realized_end_to_end_deadline_failures (integer)
    - expected_channel_losses (float)
    - realized_lost_channel (integer)
    - scheduled_packets_count vs expected_delivered_packets
    """
    tau = (1024 * 8.0) / 10e6
    packets = [
        {"id": 1, "device_id": 0, "arrive_time_s": 0.0, "deadline_s": tau, "semantic_importance": 1.0, "size_bytes": 1024, "priority": 3},
        {"id": 2, "device_id": 1, "arrive_time_s": tau, "deadline_s": 2*tau, "semantic_importance": 0.5, "size_bytes": 1024, "priority": 2},
    ]

    solver = BasilOptSolver(time_limit_s=5.0)
    res = solver.solve_slotted(
        packets=packets,
        num_devices=2,
        simulation_time_s=2 * tau,
        data_rate_mbps=10.0,
        packet_size_bytes=1024,
        device_per=[0.0, 0.40],
        replay_seed=123
    )

    # Verify all expected and realized parity keys exist
    expected_keys = [
        "scheduling_deadline_misses",
        "end_to_end_deadline_failures",
        "expected_end_to_end_deadline_failures",
        "optical_channel_losses",
        "expected_optical_channel_losses",
        "expected_channel_losses",
        "scheduled_packets_count",
        "scheduled_pdr",
        "expected_delivered_packets",
        "expected_pdr",
        "realized_delivered_on_time",
        "realized_lost_channel",
        "realized_end_to_end_deadline_failures",
        "realized_pdr",
    ]
    for key in expected_keys:
        assert key in res, f"Missing parity key: {key}"

    # Check data types
    assert isinstance(res["scheduling_deadline_misses"], int)
    assert isinstance(res["expected_end_to_end_deadline_failures"], float)
    assert isinstance(res["realized_end_to_end_deadline_failures"], int)
    assert isinstance(res["expected_channel_losses"], float)
    assert isinstance(res["realized_lost_channel"], int)
    assert isinstance(res["scheduled_packets_count"], int)

    # Expected channel losses for 1 packet on Dev 1 with PER=0.40 should be 0.40
    assert abs(res["expected_channel_losses"] - 0.40) < 1e-5
    # Expected delivered packets: 1.0 (Dev 0) + 0.60 (Dev 1) = 1.60
    assert abs(res["expected_delivered_packets"] - 1.60) < 1e-5
    # Both scheduled on time => scheduling deadline misses == 0
    assert res["scheduling_deadline_misses"] == 0
    # Expected e2e deadline failures = 0 (unscheduled) + 0.40 (channel loss) = 0.40
    assert abs(res["expected_end_to_end_deadline_failures"] - 0.40) < 1e-5


import asyncio

def test_metric_parity_cross_algorithm_ns3_and_opt():
    """
    End-to-end integration test verifying that both ns-3 (StrictPriority) and
    BASIL-OPT report identical metric parity keys and consistent semantics.
    """
    from app.simulation.runner import SimulationRunner
    runner = SimulationRunner()
    
    cfg_base = {
        "num_devices": 4,
        "simulation_time": 0.5,
        "data_rate": 15.0,
        "traffic_mode": "burst",
        "burst_ratio": 0.30,
        "room_width": 6.0,
        "room_height": 3.0,
        "ap_power": 60.0,
        "half_angle": 60.0,
        "packet_size": 1024,
        "normal_rate": 80.0,
        "burst_rate": 350.0,
        "seed": 42,
    }

    # 1. Run ns-3 StrictPriority
    cfg_sp = dict(cfg_base, scheduler="StrictPriority")
    res_sp = asyncio.run(runner.run(cfg_sp, engine="ns3"))

    assert "scheduling_deadline_misses" in res_sp
    assert "end_to_end_deadline_failures" in res_sp
    assert "optical_channel_losses" in res_sp
    assert res_sp["scheduling_deadline_misses"] == 0
    # End-to-end failures must equal deadline packets lost on channel
    assert res_sp["end_to_end_deadline_failures"] > 0
    assert res_sp["end_to_end_deadline_failures"] == (
        res_sp["total_packets_with_deadline"] - res_sp["delivered_on_time"]
    )

    # 2. Run BASIL-OPT on the same scenario
    cfg_opt = dict(cfg_base, scheduler="BASIL_OPT")
    res_opt = asyncio.run(runner.run(cfg_opt, engine="ns3"))

    assert "scheduling_deadline_misses" in res_opt
    assert "expected_end_to_end_deadline_failures" in res_opt
    assert "realized_end_to_end_deadline_failures" in res_opt
    assert "optical_channel_losses" in res_opt

    # PARITY ASSERTION:
    # Both algorithms must achieve 0 scheduling deadline misses
    assert res_sp["scheduling_deadline_misses"] == 0
    assert res_opt["scheduling_deadline_misses"] == 0

    # PARITY ASSERTION:
    # Realized e2e failures of BASIL-OPT must closely match ns-3 SP within Monte Carlo tolerance
    assert abs(res_opt["realized_end_to_end_deadline_failures"] - res_sp["end_to_end_deadline_failures"]) <= 5
