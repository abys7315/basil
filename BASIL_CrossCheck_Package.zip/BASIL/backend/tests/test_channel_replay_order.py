import pytest
import numpy as np
from app.algorithms.basil_opt import BasilOptSolver, packet_channel_draw

def test_splitmix64_test_vectors():
    """
    Verify exact bit-level test vectors for packet_channel_draw.
    Matches C++ lifi::packet_channel_draw(seed, packet_id, device_id)
    compiled and verified in WSL2 Ubuntu GCC.
    """
    seed = 42
    dev_id = 1
    expected_vectors = {
        0: 0.22726424559835756,
        1: 0.9473649833063068,
        2: 0.4750182445648927,
        3: 0.778805679032851,
        4: 0.8325479892421324,
    }
    for pid, exp_val in expected_vectors.items():
        val = packet_channel_draw(seed, pid, dev_id)
        assert abs(val - exp_val) < 1e-15, f"Vector mismatch for pid {pid}: got {val}, exp {exp_val}"


def test_channel_draw_scheduler_order_invariance():
    """
    Prove that channel outcome for any given packet is invariant to the
    scheduler execution order (e.g. forward vs reverse vs random permutation).
    
    Sequential PRNGs (like dist(rng)) produce order-dependent outcomes:
    if packet 1 is scheduled first vs last, it gets different draws.
    Keyed PRNG (SplitMix64) guarantees identical draws for packet 1.
    """
    seed = 42
    packets = [
        {"id": 101, "device_id": 0, "size_bytes": 1024, "priority": 1, "semantic_importance": 0.8},
        {"id": 102, "device_id": 1, "size_bytes": 1024, "priority": 2, "semantic_importance": 0.6},
        {"id": 103, "device_id": 2, "size_bytes": 1024, "priority": 3, "semantic_importance": 1.0},
        {"id": 104, "device_id": 0, "size_bytes": 1024, "priority": 0, "semantic_importance": 0.2},
        {"id": 105, "device_id": 1, "size_bytes": 1024, "priority": 2, "semantic_importance": 0.7},
    ]
    per_map = {0: 0.10, 1: 0.35, 2: 0.60}

    # Order A: Original order [101, 102, 103, 104, 105]
    order_a = list(packets)
    draws_a = {p["id"]: packet_channel_draw(seed, p["id"], p["device_id"]) for p in order_a}
    success_a = {p["id"]: (draws_a[p["id"]] >= per_map[p["device_id"]]) for p in order_a}

    # Order B: Reversed order [105, 104, 103, 102, 101]
    order_b = list(reversed(packets))
    draws_b = {p["id"]: packet_channel_draw(seed, p["id"], p["device_id"]) for p in order_b}
    success_b = {p["id"]: (draws_b[p["id"]] >= per_map[p["device_id"]]) for p in order_b}

    # Order C: Permuted order
    order_c = [packets[2], packets[0], packets[4], packets[1], packets[3]]
    draws_c = {p["id"]: packet_channel_draw(seed, p["id"], p["device_id"]) for p in order_c}
    success_c = {p["id"]: (draws_c[p["id"]] >= per_map[p["device_id"]]) for p in order_c}

    # Keyed draws MUST be 100% invariant across all execution orders
    for p in packets:
        pid = p["id"]
        assert draws_a[pid] == draws_b[pid] == draws_c[pid], f"Draw not invariant for packet {pid}"
        assert success_a[pid] == success_b[pid] == success_c[pid], f"Outcome not invariant for packet {pid}"

    # Contrast with sequential stream PRNG: sequential draws diverge when order changes
    seq_rng_a = np.random.default_rng(seed)
    seq_draws_a = {p["id"]: seq_rng_a.uniform(0.0, 1.0) for p in order_a}

    seq_rng_b = np.random.default_rng(seed)
    seq_draws_b = {p["id"]: seq_rng_b.uniform(0.0, 1.0) for p in order_b}

    # In sequential PRNG, packet 101 got the 1st draw in order A, but the 5th draw in order B!
    assert seq_draws_a[101] != seq_draws_b[101], "Sequential PRNG should differ across orders"


def test_basil_opt_canonical_terminology_and_units():
    """
    Verify that BASIL-OPT outputs canonical Phase 3.4 terminology:
    - scheduling_coverage and scheduling_coverage_pct
    - expected_received_pdr and expected_received_pdr_pct
    - realized_received_pdr and realized_received_pdr_pct (under replay)
    - ap_power_unit == 'mW'
    """
    solver = BasilOptSolver(time_limit_s=5.0)
    tau = 0.001
    packets = [
        {"id": 1, "device_id": 0, "size_bytes": 1024, "arrive_time_s": 0.000, "deadline_s": 0.010, "priority": 3, "semantic_importance": 1.0},
        {"id": 2, "device_id": 1, "size_bytes": 1024, "arrive_time_s": 0.000, "deadline_s": 0.010, "priority": 0, "semantic_importance": 0.2},
    ]
    device_per = {0: 0.05, 1: 0.80}

    # Solve with replay
    res = solver.solve_slotted(
        packets=packets,
        num_devices=2,
        simulation_time_s=0.005,
        data_rate_mbps=10.0,
        packet_size_bytes=1024,
        device_per=device_per,
        replay_seed=42,
    )

    # Verify canonical keys exist
    assert "scheduling_coverage" in res
    assert "scheduling_coverage_pct" in res
    assert "expected_received_pdr" in res
    assert "expected_received_pdr_pct" in res
    assert "realized_received_pdr" in res
    assert "realized_received_pdr_pct" in res
    assert "ap_power_unit" in res
    assert res["ap_power_unit"] == "mW"

    # Verify values and definitions
    # Both packets scheduled: scheduling_coverage = 2/2 = 1.0 (100%)
    assert res["scheduling_coverage"] == 1.0
    assert res["scheduling_coverage_pct"] == 100.0
    assert res["scheduled_pdr"] == 1.0  # backward compatibility alias

    # Expected PDR = ((1 - 0.05) + (1 - 0.80)) / 2 = (0.95 + 0.20) / 2 = 0.575
    assert abs(res["expected_received_pdr"] - 0.575) < 1e-6
    assert abs(res["expected_received_pdr_pct"] - 57.5) < 1e-4

    # Realized PDR is an integer count divided by N_gen
    assert res["realized_received_pdr"] in [0.0, 0.5, 1.0]
    assert res["realized_received_pdr_pct"] == res["realized_received_pdr"] * 100.0
