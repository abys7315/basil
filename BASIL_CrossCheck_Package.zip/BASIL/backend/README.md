# BASIL Backend API

High-performance asynchronous backend service powering the **BASIL** (Burst-Aware Semantic Intelligence for Li-Fi) platform. Built with **FastAPI**, **SQLAlchemy** (asyncio with `aiosqlite`), and **Pydantic v2**.

---

## Prerequisites

- **Python**: >= 3.10
- Active virtual environment or system Python configured with pip.

---

## Installation

```bash
# Navigate to the backend directory
cd backend

# Install required packages
pip install -r requirements.txt
```

---

## Running the Server

### Using start script:
```cmd
start.bat
```

### Or using uvicorn directly:
```bash
python -m uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

- **Base URL**: `http://localhost:8000`
- **Interactive Swagger Docs**: `http://localhost:8000/docs`
- **ReDoc Documentation**: `http://localhost:8000/redoc`

---

## API Endpoints Reference

### Health & System
| Method | Endpoint | Description |
| :--- | :--- | :--- |
| `GET` | `/health` | Service status check |
| `GET` | `/` | API welcome banner and link to documentation |

### Network Configurations (`/api/networks`)
| Method | Endpoint | Description |
| :--- | :--- | :--- |
| `GET` | `/api/networks` | List all saved Li-Fi room network topologies |
| `POST` | `/api/networks` | Create a new network configuration |
| `GET` | `/api/networks/{id}` | Retrieve details for a specific network configuration |

### Traffic Configurations (`/api/traffic`)
| Method | Endpoint | Description |
| :--- | :--- | :--- |
| `GET` | `/api/traffic` | List all traffic profiles |
| `POST` | `/api/traffic` | Create a new traffic profile |
| `GET` | `/api/traffic/{id}` | Retrieve details for a specific traffic profile |

### Experiments (`/api/experiments`)
| Method | Endpoint | Description |
| :--- | :--- | :--- |
| `GET` | `/api/experiments` | List all queued and completed experiments |
| `POST` | `/api/experiments` | Create and automatically execute an experiment |
| `GET` | `/api/experiments/{id}` | Retrieve status and configuration of an experiment |
| `POST` | `/api/experiments/{id}/run` | Re-run an existing experiment |

### Simulation Results (`/api/results`)
| Method | Endpoint | Description |
| :--- | :--- | :--- |
| `GET` | `/api/results/{experiment_id}` | Retrieve parsed simulation metrics and time-series data |
| `GET` | `/api/results/{experiment_id}/csv` | Download experiment results as CSV |

### Scheduling Algorithms (`/api/algorithms`)
| Method | Endpoint | Description |
| :--- | :--- | :--- |
| `GET` | `/api/algorithms` | List available scheduling algorithms (`fifo`, `rr`, `sp`, `basil-psa`) |

---

## Database Architecture

Experiments and configurations are stored in an asynchronous SQLite database located at `experiments/basil.db` relative to the workspace root. Schema migrations are automatically executed upon application startup.
